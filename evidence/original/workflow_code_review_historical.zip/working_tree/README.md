# SPRA Paper Experiments

This repository snapshot contains the experiment code and frozen results used in
the SPRA paper evaluation.

## Repository layout

```text
src/
  experiments/final/       Final E1-E4 + diagnostic experiment drivers
  experiments/supporting/  Tuning, baseline adaptation, and runtime utilities
  experiments/archive/     Older/diagnostic SPRA scripts retained for provenance
  simulator/               Frozen simulator implementation used by E1-E4
  runtime/joint_e1/        Real-vLLM hook/runtime used by E5-E6

configs/                    Frozen runtime/configuration files
data/
  processed/                Plot-ready summaries and flattened per-case tables
  real_gpu/                 Real-GPU runs/workflows and filtered backend telemetry
  raw_archives/             Exact frozen result directories as tar.gz archives
  support_archives/         Tuning/calibration result archives

metadata/
  experiments.csv           Experiment index and original frozen paths
  environment/              Environment snapshots
  archive_manifest.csv      Archive sizes / SHA256 / split information

SHA256SUMS                  Integrity hashes for repository files
```

## Final evaluation set

- **E1 – Workflow × Load:** Sequential, ParallelRAG, and AsymmetricAgent across
  four arrival rates, comparing RR, EFT, Preble, Ayo, and Ours.
- **E2 – KV locality:** prefix-sharing mechanism study.
- **E3 – Adaptive batching:** temporal-composition study with a fixed global
  P-heavy/D-heavy profile multiset.
- **E4 – Component ablation:** No-DAG, No-KV, FixedBatch, Core, Ours.
- **E5 – Real GPU mechanism validation:** two real workloads × two token budgets
  × two routing policies × three repeats = 24 real runs.
- **E6 – Real scheduler overhead:** extracted from the real vLLM backend traces.

`D1_core_replay` is retained as a diagnostic replay and should not be confused
with a separate primary-paper experiment.

## Plotting

For plotting, start with `data/processed/`.  Each experiment folder contains:
- copied aggregate CSV/TXT summaries from the frozen run;
- `case_summaries.jsonl`, a uniform stream of per-case `summary.json` records;
- `case_summaries.csv`, a flattened table of those records.

The exact original result trees are preserved under `data/raw_archives/`.

## Real-GPU data

E5 is **8 unique conditions × 3 repeats = 24 runs**, not 24 unique conditions.
The real-GPU run uses Qwen2.5-1.5B-Instruct on four RTX 3080 GPUs with vLLM,
prefix caching and chunked prefill.  The frozen asymmetric KV layout uses
1024 blocks on even replicas and 4096 blocks on odd replicas.

`mean_kv_usage_pct` in the E6 extraction is KV-block occupancy, **not** a
cache-hit or KV-reuse ratio.

## Reproducibility

1. Verify files:
   `sha256sum -c SHA256SUMS`
2. Review `metadata/experiments.csv`.
3. Inspect frozen configuration and tuning dependencies in `configs/` and
   `data/support_archives/`.
4. Re-run only in a matching environment; exact historical raw outputs are
   already preserved in `data/raw_archives/`.

## Large raw archives

GitHub has a 100 MB per-file hard limit.  Archives larger than 90 MiB are split
into `.partNNN` files. Reconstruct with:

```bash
cat NAME.tar.gz.part* > NAME.tar.gz
```

For a long-lived public repository, Git LFS or a release asset / Zenodo archive
is preferable for large raw artifacts.
