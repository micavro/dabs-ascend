"""New selected-case executions, not reuse of the favorable historical observation."""
from __future__ import annotations
import argparse,asyncio,contextlib,copy,fcntl,json,multiprocessing,os,shutil,zipfile
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from . import REVISION,RUNTIME_REVISION
from .common import atomic,load,sha,digest,files,verify_files,stamp,jsonl,compact
from .dependency import ROOT,activate,own_identity
activate()
from case23 import CHECKER_REVISION
from .design import protocol,make_design,cells_for,config_for,external_identity,arrival_metadata

from . import evidence,report
from batching20 import experiment as old
from batching20.dependency import SOURCE,TYPED
from semantic19.dataset import load_public
from typed19.workflow import ServerTokenizer,compile_packets,instantiate
from typed19.quality import evaluate as quality_evaluate
from . import event_client as live
from joint18v2.common import token_hash
DEFAULT_RUNTIME=Path('/home/wmy/sci/spra_core_exp/joint_e1')


def export_text(out):
    path=Path(out)/'RESULTS_FOR_CHAT.txt'
    if path.exists():report.write_text(ROOT/'RESULTS_FOR_CHAT.txt',path.read_text(encoding='utf-8'))
    report.write_text(ROOT/'LATEST_RUN.txt',str(Path(out).resolve())+'\n')


def console_row(row):
    s=row['summary']
    keys=('mean_jct_ms','p95_jct_ms','mean_request_ttft_ms','p95_request_ttft_ms',
          'mean_node_time_to_first_content_ms','mean_client_tpot_proxy_ms','p95_client_tpot_proxy_ms',
          'cohort_workflows_s','cohort_tokens_s','output_tokens','requests','request_correlation',
          'independent_batch_matches','independent_batch_checked','commit_fallbacks',
          'routing_deviations_from_snapshot_affinity','cap_restriction_plans_committed',
          'opportunity_replica_decisions','D0_schedule_integrity','semantic_quality','v2_mechanism')
    return {**{k:v for k,v in row.items() if k!='summary'},**{k:s.get(k) for k in keys}}


def prepare():
    deps=activate();frozen,mf,model,priors=old.load_frozen()
    records,dm=load_public(Path(mf['dataset']),'pilot')
    expected=load(ROOT/'configs/block1_ids.json');selected=records[:16]
    if [p['id'] for p in selected]!=expected or sum(len(p['steps']) for p in selected)!=53:
        raise ValueError('not the historical Block1 16 questions / 53 original LLM nodes')
    cf=copy.deepcopy(mf['D0_configuration'])
    for k,v in {'replicas':4,'workflow_count':16,'base_cap':4096,'hard_total':4096,'max_model_len':4096,
               'block_size':16,'max_num_seqs':64,'epoch_s':.2,'arrival_shape':'wave','max_output_tokens':96}.items():
        if cf.get(k)!=v:raise ValueError('D0 checkpoint configuration differs: '+k)
    design=make_design()
    p={'revision':REVISION,'checker_revision':CHECKER_REVISION,'protocol':protocol(),'design':design,
       'adapter_identity':own_identity(),'dependency_identity':deps,'config':cf,
       'original_frozen':str(Path(frozen).resolve()),'original_manifest_sha256':sha(Path(frozen)/'manifest.json'),
       'dataset':mf['dataset'],'dataset_files':mf['dataset_files'],'dataset_manifest_sha256':mf['dataset_manifest_sha256'],
       'original_model_sha256':mf['files']['model.json'],'original_priors_sha256':mf['files']['priors.json'],
       'selected_ids':expected,'selected_public_digest':digest(selected),'selected_original_llm_nodes':53,
       'history_in_new_repeats':False,'new_GPU_generation_requests':0,'new_model_fit':False}
    ptr=ROOT/'records/latest.json'
    if ptr.exists():
        out=Path(load(ptr)['directory']);prev,_,_,_=check(out)
        keys=[k for k in p if k!='original_frozen']
        if any(prev[k]!=p[k] for k in keys):raise ValueError('existing case study has different frozen identity; do not overwrite it')
        print('V2_PREPARED_REUSED='+str(out),flush=True);return out
    out=ROOT/'runs'/stamp('DAG_BATCH_V2');out.mkdir(parents=True)
    (out/'frozen').mkdir()
    for n in ('model.json','priors.json'):
        shutil.copyfile(Path(frozen)/n,out/'frozen'/n)
    atomic(out/'frozen/original_D0_manifest.json',mf)
    atomic(out/'frozen/selected.public.json',selected)
    atomic(out/'frozen/dataset_manifest.json',dm)
    atomic(out/'frozen/runtime_revision.json',{'revision':RUNTIME_REVISION,'history_not_pooled':True})
    p['frozen_files']=files(out/'frozen')
    atomic(out/'protocol.json',p);atomic(out/'protocol_receipt.json',{'sha256':sha(out/'protocol.json')})
    atomic(out/'index.json',[]);atomic(out/'suite_status.json',{'status':'prepared','expected':len(design)})
    atomic(ptr,{'directory':str(out.resolve())})
    report.write(out,[],design);export_text(out)
    print('V2_PREPARED='+json.dumps({'directory':str(out),'case':'MuSiQue-B1-16',
      'questions':16,'requests_per_condition':53,'core_conditions':48,'regression_conditions':24,
      'frozen_main':'DAG-Batch-v2 (same-library full-workflow net selection)','GPU_REQUESTS':0,'model_refitted':False}),flush=True)
    return out


def check(out):
    out=Path(out);p=load(out/'protocol.json')
    if sha(out/'protocol.json')!=load(out/'protocol_receipt.json')['sha256']:raise ValueError('protocol changed')
    if p['adapter_identity']!=own_identity() or p['dependency_identity']!=activate():raise ValueError('source changed after preparation')
    if p['protocol']!=protocol() or p['design']!=make_design():raise ValueError('frozen experiment design changed')
    verify_files(out/'frozen',p['frozen_files'],exact=True)
    oldp=Path(p['original_frozen'])
    if sha(oldp/'manifest.json')!=p['original_manifest_sha256']:raise ValueError('old D0 freeze changed')
    for n,k in [('model.json','original_model_sha256'),('priors.json','original_priors_sha256')]:
        if sha(oldp/n)!=p[k] or sha(out/'frozen'/n)!=p[k]:raise ValueError('original model/priors changed')
    data=Path(p['dataset']);verify_files(data,p['dataset_files'])
    if sha(data/'manifest.json')!=p['dataset_manifest_sha256']:raise ValueError('dataset manifest changed')
    selected=load(out/'frozen/selected.public.json')
    if digest(selected)!=p['selected_public_digest'] or [r['id'] for r in selected]!=p['selected_ids']:raise ValueError('case cohort changed')
    return p,load(out/'frozen/model.json'),load(out/'frozen/priors.json'),selected


def environment_same(current,first):
    fields=('pod','hook_source_sha256','scheduler_source_sha256','nvidia_visible_devices','hard_total',
       'max_model_len','max_num_seqs','block_size','num_gpu_blocks','num_scheduler_steps',
       'prefix_caching','chunked_prefill','native_cache_allocator')
    if len(current)!=4 or len(first)!=4:raise ValueError('four distinct dedicated instances required')
    for a,b in zip(current,first):
        for k in fields:
            if k not in a or k not in b or a[k]!=b[k]:raise ValueError('runtime hardware/config changed: '+k)
    return {'same_hardware_and_resource_config':True,
      'old_processes':[{k:s.get(k) for k in ('pod','pid','boot_id','launch_id')} for s in first],
      'current_processes':[{k:s.get(k) for k in ('pod','pid','boot_id','launch_id')} for s in current]}


async def all_gate(client,runtime):
    ss=await live.gate(client,runtime,4)
    if any(s.get('hook_source_sha256')!=old.HOOK for s in ss):raise ValueError('expected existing native hook; no redeployment performed')
    return ss


def inactive_offsets(runtime,R):
    return {r:(Path(runtime)/'joint18v2'/f'spra-vllm-{r}.events.jsonl').stat().st_size
       if (Path(runtime)/'joint18v2'/f'spra-vllm-{r}.events.jsonl').exists() else 0 for r in range(R,4)}


def inactive_proof(runtime,offsets):
    bad=[];partial=0
    for r,off in offsets.items():
        path=Path(runtime)/'joint18v2'/f'spra-vllm-{r}.events.jsonl'
        if not path.exists():continue
        if path.stat().st_size<off:raise ValueError('inactive event log truncated')
        with path.open('rb') as f:f.seek(off);data=f.read()
        for line in data.splitlines():
            if not line.strip():continue
            try:e=json.loads(line)
            except (ValueError,UnicodeDecodeError):partial+=1;continue
            if e.get('event')=='accept' or (e.get('event')=='iteration' and e.get('scheduled')):bad.append({'replica':r,'event':e})
    if bad or partial:raise ValueError('inactive replica received workload or evidence incomplete: '+str({'events':bad[:3],'partial':partial}))
    return {'pass':True,'inactive_replicas':list(offsets),'extra_generation_events':0,
            'all_pods_remain_running':True,'not_an_energy_or_gpu_power_measurement':True}


async def warmup(client,runtime,initial,cfg,out,tok):
    from tools.experiment import warm_nodes,FixedWarmup,salt
    R=len(initial);pool=await live.token_pool(client,cfg['model'])
    with contextlib.nullcontext():
        for i,profile in enumerate(((512,32),(3328,64)),1):
            # The inherited generator constructs4; filter BEFORE any generation.
            ns={k:n for k,n in warm_nodes(cfg,pool,profile,salt(pool)).items() if n['warm_replica']<R}
            s,_=await live.execute(client,runtime,initial,cfg,ns,out/f'P{i}','Forced',None,mechanism=FixedWarmup())
            if not s['condition_valid'] or s['native_next_batch_matches']!=s['native_next_batch_checked']:raise ValueError('ordinary warmup correctness failure')
        ns={k:n for k,n in warm_nodes(cfg,pool,(512,32),salt(pool)).items() if n['warm_replica']<R}
        from uuid import uuid4
        system='Run '+uuid4().hex+'. Return only a JSON object with string key answer.'
        for n in ns.values():
            tokens=await tok.chat_tokens(system+' Replica '+str(n['warm_replica'])+'.','Return {"answer":"READY"}.')
            n.update(tokens=tokens,prompt=len(tokens),hash=token_hash(tokens),prefix_hash=None,share=0,
                output=8,output_is_estimate=True,max_output_tokens=cfg['max_output_tokens'],semantic_mode=True,typed_answer_mode=True)
        s,_=await live.execute(client,runtime,initial,cfg,ns,out/'GUIDED_JSON','Forced',None,mechanism=FixedWarmup())
        counts={str(r):sum(n['replica']==r for n in ns.values()) for r in range(R)}
        if list(counts.values())!=[1]*R or any(n['answer_contract']['status']=='format_error' for n in ns.values()):raise ValueError('guided warmup failed')
        if not s['condition_valid'] or s['native_next_batch_matches']!=s['native_next_batch_checked']:raise ValueError('guided warmup native mismatch')
    rec={'replicas':R,'ordinary_requests':2*R,'guided_requests':R,'total_requests':3*R,'measured':False,
         'fixed_count_not_repeated_by_latency':True}
    atomic(out/'warmup_receipt.json',rec)
    print('V2_WARMUP='+json.dumps(rec),flush=True)


def worker_ready(): return os.getpid()


def attempt_dir(out,cell,number):
    # The inherited executor derives case from raw.parent.name/raw.name.
    # Include condition + suite nonce in that parent, not plain attempt_001.
    name=f"attempt_{number:03d}_{cell['label']}_{Path(out).name.rsplit('_',1)[-1]}"
    return Path(out)/'attempts'/cell['label']/name


def units(out,label):
    base=Path(out)/'attempts'/label
    return sorted(p for p in base.glob('attempt_*') if p.is_dir())


def index(out,design):
    rows=[]
    for c in design:
        good=[evidence.accepted_row(u) for u in units(out,c['label']) if (u/'accepted.json').exists()]
        if len(good)>1:raise ValueError('more than one accepted attempt for '+c['label'])
        if good:rows.append(good[0])
    atomic(Path(out)/'index.json',rows);return rows


def raw_complete(unit):
    f=Path(unit)/'raw/nodes.json'
    if not f.exists():return False
    ns=load(f);return bool(ns) and all(n.get('state')=='done' for n in ns.values())


def finalize(unit,cell,cfg,packets,model,dataset):
    unit=Path(unit)
    if (unit/'accepted.json').exists():return evidence.accepted_row(unit)
    if not (unit/'raw/summary.json').exists():raise ValueError('completed requests but missing native summary; retain evidence, do not regenerate automatically')
    proof=load(unit/'input_proof.json');off=evidence.validate(unit/'raw',cell,cfg,packets,proof,model)
    atomic(unit/'validation.json',off)
    if not off.get('accepted'):raise ValueError('native correspondence unresolved; see '+str(unit/'validation.json'))
    if not load(unit/'inactive_proof.json').get('pass'):raise ValueError('replica isolation proof missing')
    derived=unit/'derived';derived.mkdir(exist_ok=True)
    s=load(unit/'raw/summary.json');ns=load(unit/'raw/nodes.json')
    t=evidence.mechanisms(unit/'raw',derived,cell)
    with (derived/'answers.log').open('w',encoding='utf-8') as answerlog,contextlib.redirect_stdout(answerlog):
        q=quality_evaluate(ns,Path(dataset),s['cohort_duration_s'])
    atomic(derived/'quality.json',q)
    s.update(t);s.update(q);s.update(case_name='MuSiQue-B1-16',public_method=cell['method'],
        implementation_origin=cell['routing'],public_executor_revision=RUNTIME_REVISION,
        selected_case_not_whole_dataset=True,history_pooled=False,
        independent_batch_matches=off['matches'],independent_batch_checked=off['iterations'],
        source_questions=proof['ids'],arrival_metadata=arrival_metadata(cell['rate'],proof['arrivals']))
    atomic(derived/'summary.json',s)
    row={**cell,'segment':load(unit/'origin.json')['segment'],'folder':str(unit.resolve()),
        'external_work_sha256':external_identity(packets,proof),'output_signature':evidence.output_signature(ns),'summary':compact(s)}
    atomic(unit/'row.json',row)
    checked_files={'row.json':sha(unit/'row.json'),'cell.json':sha(unit/'cell.json'),'input_proof.json':sha(unit/'input_proof.json'),
         'origin.json':sha(unit/'origin.json'),'inactive_proof.json':sha(unit/'inactive_proof.json'),'validation.json':sha(unit/'validation.json')}
    checked_files.update({'derived/'+k:v for k,v in files(derived).items()})
    if (unit/'execution_console.txt').exists():checked_files['execution_console.txt']=sha(unit/'execution_console.txt')
    atomic(unit/'accepted.json',{'measurement_accepted':True,'label':cell['label'],
       'raw_hashes':files(unit/'raw'),'derived_hashes':checked_files,'sign_not_used_for_acceptance':True})
    return row


def archive(out):
    out=Path(out);r=load(out/'result.json')
    if not load(out/'cleanup.json').get('backend_drained'):raise ValueError('cannot archive as clean before drain')
    a=ROOT/'archives';a.mkdir(exist_ok=True)
    dest=a/(out.name+'_'+str(r['accepted_conditions'])+'_'+stamp('SNAP')+'.zip')
    entries=[]
    for rel,h in files(out).items():entries.append((out/rel,'run/'+rel,h))
    for rel,h in own_identity().items():entries.append((ROOT/rel,'code/'+rel,h))
    for rel in ('README.md','docs/EXPERIMENT_CONTRACT.md','TEST_RESULTS.txt','TEST_SCOPE.json'):
        if (ROOT/rel).exists():entries.append((ROOT/rel,'code/'+rel,sha(ROOT/rel)))
    with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=4) as z:
        for p,n,h in entries:z.write(p,n)
        z.writestr('ARCHIVE_SHA256SUMS',''.join(h+'  '+n+'\n' for _,n,h in entries))
    receipt={'path':str(dest),'sha256':sha(dest),'accepted_conditions':r['accepted_conditions'],
       'core_complete':r['core_complete'],'regression_complete':r['regression_complete'],
       'partial_snapshot_not_claimed_complete':not r['complete']}
    atomic(out/'last_archive.json',receipt);print('V2_ARCHIVE='+json.dumps(receipt),flush=True)
    return receipt


async def run(out,runtime,phase,retry=False):
    import httpx
    out=Path(out);runtime=Path(runtime)
    if not runtime.is_dir():raise FileNotFoundError('runtime path missing; no fake native status created')
    p,model,priors,selected=check(out);wanted=cells_for(p['design'],phase)
    rows=index(out,p['design']);good={r['label']:r for r in rows}
    if all(c['label'] in good for c in wanted):
        report.write(out,rows,p['design']);export_text(out);print('V2_PHASE_ALREADY_COMPLETE='+phase+' GENERATION_REQUESTS=0');return
    with (runtime/'experiment.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        async with httpx.AsyncClient(timeout=httpx.Timeout(180,connect=5,pool=10),trust_env=False,
           limits=httpx.Limits(max_connections=192,max_keepalive_connections=64,keepalive_expiry=2)) as client:
            initial=await all_gate(client,runtime)
            ref=out/'first_environment.json'
            if not ref.exists():atomic(ref,initial)
            envcheck=environment_same(initial,load(ref))
            segment=out/'segments'/stamp('SEG');segment.mkdir(parents=True)
            atomic(segment/'environment.json',initial);atomic(segment/'environment_check.json',envcheck)
            atomic(segment/'requested_conditions.json',wanted)
            atomic(out/'suite_status.json',{'status':'running','requested_phase':phase,'accepted':len(rows),'planned':len(p['design'])})
            executor=None;warmed=set();complete=False
            try:
                tok=ServerTokenizer(client,p['config']['model']);packets,info=await compile_packets(selected,tok,p['config'])
                atomic(segment/'packet_preparation.json',info)
                atomic(segment/'packet_public_evidence.json',packets)
                executor=ProcessPoolExecutor(1,mp_context=multiprocessing.get_context('spawn'))
                await asyncio.get_running_loop().run_in_executor(executor,worker_ready)
                for cell in wanted:
                    if cell['label'] in good:continue
                    check(out);cfg=config_for(p['config'],priors,cell);prev=units(out,cell['label'])
                    unit=prev[-1] if prev else None
                    if unit and load(unit/'cell.json')!=cell:raise ValueError('old attempt belongs to other condition')
                    if unit and raw_complete(unit):
                        if not (unit/'inactive_proof.json').exists():
                            offsets=load(unit/'origin.json')['inactive_event_offsets']
                            atomic(unit/'inactive_proof.json',inactive_proof(runtime,{int(k):v for k,v in offsets.items()}))
                        row=finalize(unit,cell,cfg,packets,model,p['dataset']);rows.append(row);good[cell['label']]=row
                        atomic(out/'index.json',rows)
                        report.write(out,rows,p['design']);export_text(out)
                        print('V2_RECOVERED_COMPLETE='+cell['label'],flush=True);continue
                    if unit and not retry:raise ValueError('incomplete attempt retained; use --retry-incomplete explicitly, never for complete or bad-performance conditions')
                    R=cell['replicas'];ss=await all_gate(client,runtime);environment_same(ss,initial)
                    if R not in warmed:
                        wc=copy.deepcopy(p['config']);wc['replicas']=R;wc['dagv2_public_method']='WARMUP';wc['dagv2_min_decision_gap_s']=.01
                        await warmup(client,runtime,ss[:R],wc,segment/f'{segment.name}_WARM_R{R}',tok);warmed.add(R)
                        ss=await all_gate(client,runtime)
                    ns,materializer,proof=await instantiate(packets,tok,cfg,cell['seed'],priors)
                    if len(ns)!=53 or proof['ids']!=p['selected_ids']:raise ValueError('unexpected selected cohort')
                    unit=attempt_dir(out,cell,len(prev)+1);unit.mkdir(parents=True)
                    off=inactive_offsets(runtime,R)
                    atomic(unit/'cell.json',cell);atomic(unit/'input_proof.json',proof)
                    atomic(unit/'origin.json',{'segment':segment.name,'new_execution':True,'historical_result_reused':False,
                          'initial_statuses':ss,'inactive_event_offsets':off,'runtime':str(runtime.resolve())})
                    atomic(unit/'attempt_status.json',{'status':'started'})
                    print('V2_CONDITION_START='+json.dumps(cell),flush=True)
                    try:
                        with (unit/'execution_console.txt').open('w',encoding='utf-8') as ec,contextlib.redirect_stdout(ec):
                            await live.execute(client,runtime,ss[:R],cfg,ns,unit/'raw',cell['scheduler'],model,
                               executor=executor if cell['scheduler']!='A' else None,materializer=materializer)
                        atomic(unit/'input_proof.json',proof)
                        current=await all_gate(client,runtime);environment_same(current,ss)
                        atomic(unit/'inactive_proof.json',inactive_proof(runtime,off))
                        row=finalize(unit,cell,cfg,packets,model,p['dataset'])
                        atomic(unit/'attempt_status.json',{'status':'accepted'})
                    except BaseException as exc:
                        atomic(unit/'input_proof.json',proof)
                        atomic(unit/'attempt_status.json',{'status':'failed','error':repr(exc),'automatic_retry':False});raise
                    rows.append(row);good[cell['label']]=row;atomic(out/'index.json',rows)
                    atomic(out/'suite_status.json',{'status':'running','requested_phase':phase,'accepted':len(rows),'planned':len(p['design'])})
                    report.write(out,rows,p['design']);export_text(out)
                    print('V2_CONDITION_ACCEPTED='+json.dumps(console_row(row),ensure_ascii=False),flush=True)
                complete=True
                res=report.write(out,rows,p['design'])
                atomic(out/'suite_status.json',{'status':'complete' if res['complete'] else 'phase_complete',
                      'requested_phase':phase,'accepted':len(rows),'core_complete':res['core_complete'],
                      'regression_complete':res['regression_complete'],'pending':len(p['design'])-len(rows)})
                print('V2_RESULT='+json.dumps({k:v for k,v in res.items() if k not in ('aggregates','paired')},ensure_ascii=False),flush=True)
            except BaseException as exc:
                atomic(out/'suite_status.json',{'status':'interrupted','requested_phase':phase,'accepted':len(rows),
                     'error':repr(exc),'automatic_retry':False})
                report.write(out,rows,p['design']);export_text(out);raise
            finally:
                if executor:executor.shutdown(wait=True,cancel_futures=True)
                atomic(runtime/'joint18v2/control.json',{'enabled':False})
                try:drained=await live.wait_drained(runtime,initial)
                except Exception:drained=False
                unchanged=activate()==p['dependency_identity'] and own_identity()==p['adapter_identity']
                clean={'backend_drained':drained,'source_files_unchanged':unchanged,'backend_code_changed':False,
                       'old_results_overwritten':False,'no_profile_refit':True,'segment':segment.name}
                atomic(segment/'cleanup.json',clean);atomic(out/'cleanup.json',clean)
                report.write(out,rows,p['design']);export_text(out)
                print('CLEANUP='+json.dumps(clean),flush=True)
                if not drained or not unchanged:raise RuntimeError('cleanup/identity not complete; keep evidence and stop')
            if complete:archive(out)


def main():
    a=argparse.ArgumentParser(description='DAG-Batch-v2 same-runtime complete-workflow selection experiment')
    a.add_argument('command',choices=('plan','prepare','gate','run','report','archive'))
    a.add_argument('--phase',choices=('core','regression','all'),default='core')
    a.add_argument('--runtime',type=Path,default=DEFAULT_RUNTIME)
    a.add_argument('--resume',type=Path);a.add_argument('--retry-incomplete',action='store_true')
    args=a.parse_args()
    if args.command=='plan':
        print(json.dumps({'protocol':protocol(),'design':make_design()},indent=2,ensure_ascii=False));return
    (ROOT/'records').mkdir(exist_ok=True)
    with (ROOT/'records/runner.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        out=args.resume.resolve() if args.resume else prepare()
        if args.command=='prepare':return
        if args.command=='gate':
            async def gate_only():
                import httpx
                with (args.runtime/'experiment.lock').open('a') as runtime_lock:
                    fcntl.flock(runtime_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    async with httpx.AsyncClient(timeout=20,trust_env=False) as client:await all_gate(client,args.runtime)
                print('GATE_READY=True GENERATION_REQUESTS=0 BACKEND_CHANGED=False')
            asyncio.run(gate_only());return
        if args.command=='run':asyncio.run(run(out,args.runtime,args.phase,args.retry_incomplete));return
        p,_,_,_=check(out);report.write(out,index(out,p['design']),p['design'])
        export_text(out)
        if args.command=='archive':archive(out)
        else:print((out/'RESULTS_FOR_CHAT.txt').read_text(encoding='utf-8'))
