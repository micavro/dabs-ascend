"""Small complete-workflow placement x prefill neighborhood.

Candidate proposals use estimates, not future answers or outcome tables. Every
ranked action is evaluated to completion in the existing causal surrogate. The
surrogate is not a physical counterfactual or a real non-regression certificate.
"""
from __future__ import annotations
import copy
import math
import time
from collections import defaultdict
from .dependency import activate
activate()
from joint18v2.search import reference
from joint18v2.actions import resources
from joint18v2.common import action_key, validate_action
from joint18v2.model import predict
from semantic19.selector import schedule_alternative
from batching20.policy import choose_caps, process_plan as legacy_process
from core18v2.engine import evaluate

NEW_METHODS=('DAG-Fixed-v2','DAG-Decoupled-v2','DAG-Batch-v2')


def observed_cache(s, cfg):
    """Only fresh native evidence; an unknown is never certified cold/warm."""
    out={}
    for e in s.get('cache_evidence', []):
        age=e.get('observed_age_s',0.)
        if not e.get('known',True) or not math.isfinite(age) or not -.005<=age<=cfg['cache_evidence_max_age_s']:
            continue
        if e.get('state') in ('active_computed','reclaimable_computed'):
            out[(e['prefix_hash'],int(e['replica']))]=max(0,int(e.get('tokens',0)))
        elif e.get('state') in ('absent','evicted','resident_uncomputed'):
            out[(e['prefix_hash'],int(e['replica']))]=0
    return out


def estimate_work(s,model,cfg):
    """Cheap candidate-generation features, never used as the final objective.

Existing decode drain uses concurrent decode count/context and remaining output
estimates. Prefill work and cached query credit are separate from logical tokens.
No newly assigned cold sibling receives speculative immediate cache credit.
"""
    ns=s['nodes'];R=s['replicas'];cache=observed_cache(s,cfg);own={};dec=defaultdict(list);pre=defaultdict(list)
    for k,n in ns.items():
        for r in range(R):
            if n['state']=='done':own[k,r]=0.;continue
            done=max(0,int(n.get('output_done',0)))
            out=max(1,int(n['output'])-done)
            if n.get('phase')=='decode':
                own[k,r]=out*predict(model,r,0,1,n['prompt']+done,0,0)
            else:
                computed=max(0,int(n.get('computed',0)));p=max(0,int(n['prompt'])-computed)
                cached=min(int(n.get('share',0)),cache.get((n.get('prefix_hash'),r),0))
                credit=min(max(0,p-1),max(0,cached-computed))
                own[k,r]=(predict(model,r,p,0,0,computed,credit) if p else 0.)+max(0,out-1)*predict(model,r,0,1,n['prompt']+done,0,0)
        if n['state']=='submitted':
            (dec if n.get('phase')=='decode' else pre)[int(n['replica'])].append(k)
    load=[]
    for r in range(R):
        ds=dec[r];context=sum(ns[k]['prompt']+ns[k].get('output_done',0) for k in ds)
        step=predict(model,r,0,len(ds),context,0,0) if ds else 0.
        drain=max((max(1,ns[k]['output']-ns[k].get('output_done',0)) for k in ds),default=0)*step
        # Prefill drain approximation conservatively includes its subsequent output.
        prework=sum(own[k,r] for k in pre[r])
        inflight=max((float(x['remaining_ms']) for x in s.get('inflight_batches',[]) if x['replica']==r),default=0.)
        load.append(max(drain+prework,inflight))
    return own,load,cache


def graph_estimates(s,own,placement,load):
    """Proposal-only max-parent DAG calculation, with explicit slack.

The complete-workflow evaluator below is the only action ranking objective.
"""
    ns=s['nodes'];succ={k:[] for k in ns};fin={};duration={};color={};topo=[]
    for k,n in ns.items():
        for p in n.get('parents',[]):
            if p not in ns:raise ValueError('missing DAG parent')
            succ[p].append(k)
    def visit(k):
        if color.get(k)==1:raise ValueError('cycle in observed DAG')
        if color.get(k)==2:return fin[k]
        color[k]=1;n=ns[k]
        parent=max((visit(p) for p in n.get('parents',[])),default=0.)
        if n['state']=='done':duration[k]=0.;fin[k]=0.
        else:
            r=n.get('replica') if n['state']=='submitted' else placement.get(k)
            d=own[k,r] if r is not None else min(own[k,j] for j in range(s['replicas']))
            duration[k]=d
            queue=load[r] if n['state']=='ready' and r is not None else 0.
            fin[k]=max(parent,queue)+d
        color[k]=2;topo.append(k);return fin[k]
    for k in ns:visit(k)
    wf={}
    for k,n in ns.items():wf[n['wid']]=max(wf.get(n['wid'],0.),fin[k])
    latest={};slack={}
    for k in reversed(topo):
        latest[k]=min((latest[j]-duration[j] for j in succ[k]),default=wf[ns[k]['wid']])
        slack[k]=max(0.,latest[k]-fin[k])
    return {'finish':fin,'workflow':wf,'slack':slack,'duration':duration,'successors':succ}


def proposed_routes(s, model, cfg):
    """Affinity, work balancing, DAG bottleneck group, and old D0 alternative.

The same library is supplied to fixed-v2, decoupled-v2 and joint-v2. Labels and
source question IDs are never decision features. Resources project every action.
"""
    base=reference(s,cfg);base['family']='affinity'
    own,load,cache=estimate_work(s,model,cfg)
    gs=graph_estimates(s,own,base['placement'],load)
    ready=sorted(s['ready'],key=lambda k:(s['nodes'][k]['ready_at'],k))
    ns=s['nodes']
    orderable=[k for k,n in ns.items() if n['state'] in ('ready','submitted') and n.get('phase')!='decode']
    # Slack identifies which advancement can affect a join. Aging is the first key
    # only once the frozen maximum admission wait is reached.
    def priority(k):
        age=s['now']-(ns[k].get('ready_at') or s['now'])
        return (0 if age>=cfg['max_admission_wait_s'] else 1,gs['slack'][k],gs['workflow'][ns[k]['wid']],ns[k].get('ready_at') or s['now'],k)
    order=sorted(orderable,key=priority)
    balanced=copy.deepcopy(base);balanced['family']='remaining_work_balanced';balanced['order']=list(order)
    projected=list(load);used=list(s.get('reserved_blocks',[0]*s['replicas']));counts=[sum(n['state']=='submitted' and n.get('replica')==r for n in ns.values()) for r in range(s['replicas'])]
    capacity=[int(v*cfg['admission_reserve_fraction']) for v in s.get('capacity_blocks',[4096]*s['replicas'])]
    for k in sorted(ready,key=priority):
        n=ns[k];need=math.ceil((n['prompt']+n.get('max_output_tokens',n['output']))/cfg['block_size'])
        feasible=[r for r in range(s['replicas']) if counts[r]<cfg['max_num_seqs'] and used[r]+need<=capacity[r]]
        if not feasible:continue
        r=min(feasible,key=lambda r:(projected[r]+own[k,r],r!=base['placement'][k],r))
        balanced['placement'][k]=r;projected[r]+=own[k,r];used[r]+=need;counts[r]+=1
    balanced=resources(balanced,s,cfg)
    # One promising DAG modification, screened by a cheap graph/load proxy. It does
    # not acquire a final score until the capacity-conserving rollout completes.
    proposals=[];group_by=defaultdict(list)
    for k in ready:group_by[(ns[k]['wid'],ns[k].get('prefix_hash'))].append(k)
    for (_,h),g in group_by.items():
        ranked=sorted(g,key=priority)
        # A single blocker and a proper/all ready shared-prefix group are both
        # legitimate proposals. No hardcoded branch name or destination.
        subsets=[ranked[:1]]
        near=[k for k in ranked if gs['slack'][k]<=max(1.,min(gs['duration'].get(k,1.),10.))]
        if len(near)>1:subsets.append(near)
        if len(ranked)>2:subsets.append(ranked[:max(2,len(ranked)//2)])
        for subset in subsets:
            for r in range(s['replicas']):
                if all(base['placement'][k]==r for k in subset):continue
                a=copy.deepcopy(base);a.update(family='dag_bottleneck_group',order=list(order))
                a['placement'].update({k:r for k in subset});a=resources(a,s,cfg)
                if not set(subset)<=set(a['admit']):continue
                work=list(load)
                for k in ready:work[a['placement'][k]]+=own[k,a['placement'][k]]
                ag=graph_estimates(s,own,a['placement'],load)
                proxy=sum(ag['workflow'].values())+max(work,default=0.)
                a['proposal']={'moved_nodes':list(subset),'destination':r,'slacks_ms':{k:gs['slack'][k] for k in subset},'screening_proxy_only':proxy}
                proposals.append((proxy,a))
    dag=min(proposals,key=lambda x:(x[0],action_key(x[1])))[1] if proposals else copy.deepcopy(base)
    old=schedule_alternative(s,model,cfg,reference(s,cfg)) if ready else copy.deepcopy(base)
    old['family']='legacy_D0_proposal/'+old['family']
    candidates=[base,balanced,dag,old];unique={}
    for a in candidates:
        a['caps']=[4096]*s['replicas'];validate_action(a,s,cfg)
        unique.setdefault(action_key(a),a)
    result=list(unique.values())[:int(cfg.get('dagv2_max_routes',4))]
    return result,{'route_families':[a['family'] for a in result],
        'DAG_proposals_screened':len(proposals),'remaining_work_ms':load,
        'shared_candidate_library':True,'generation_uses_observed_cache':True,
        'unknown_cache_not_certified_cold':True,'future_truth_used':False}


def budget_response(s,a,model,cfg):
    caps,ev=choose_caps(s,a,model,cfg,'mixed_1024')
    b=copy.deepcopy(a);b['caps']=caps;b['family']=a['family']+'/conditional1024'
    validate_action(b,s,cfg)
    return b,ev


def choose(s,model,cfg,public_method,deadline=None):
    begin=time.monotonic();deadline=begin+cfg['planning_soft_limit_s'] if deadline is None else deadline
    base=reference(s,cfg);base['family']='affinity'
    result={'action':base,'model_selection':False,'evaluations':[],
       'complete_distinct_evaluations':0,'joint_cross_candidates_evaluated':0,'deadline_reached':False,
       'dagv2':{'method':public_method,'revision':'dag-batch-v2-1','objective':'sum remaining completion times of all arrived unfinished workflows',
           'reference':'Affinity plus all fixed-cap routes and corresponding old-D0-shaped cap response',
           'model_scores_are_not_GPU_measurements':True,'real_nonregression_guaranteed':False,
           'incomplete_candidates_ranked':False,'cache_state_reset_at_expiry':False}}
    info=result['dagv2']
    def end(action=None,reason=None):
        if action is not None:result['action']=copy.deepcopy(action)
        if reason is not None:info['reason']=reason
        result['wall_ms']=(time.monotonic()-begin)*1000
        result['deadline_reached']=time.monotonic()>=deadline
        info['selected_action_key']=action_key(result['action'])
        validate_action(result['action'],s,cfg);return result
    if public_method not in NEW_METHODS:raise ValueError('unknown v2 method '+public_method)
    if not s['ready'] and not any(n['state']=='submitted' and n.get('phase')!='decode' for n in s['nodes'].values()):
        result['policy_equivalent_no_prefill']=True;return end(reason='no_prefill_control_opportunity')
    if time.monotonic()>=deadline:return end(reason='deadline_before_proposals')
    routes,coverage=proposed_routes(s,model,cfg);info.update(coverage)
    cfg_eval=dict(cfg);cfg_eval['continuation_period_ms']=0.
    info['surrogate_continuation']='event-ready common Affinity/FIFO; ignores future3ms coalescing and unknown HTTP-tail time'
    memo={};failed=set();high={};responses={}
    # The proposal matrix is identical across the three new methods. Fixed-v2
    # deliberately does not generate unused budget responses.
    if public_method!='DAG-Fixed-v2':
        for i,a in enumerate(routes):responses[i]=budget_response(s,a,model,cfg)
    def score(a,kind,i):
        key=action_key(a)
        if key in memo:return memo[key]
        if key in failed or time.monotonic()>=deadline:return None
        remaining=max(0.,deadline-time.monotonic())
        if remaining<=.0002:return None
        slice_end=min(deadline,time.monotonic()+float(cfg.get('dagv2_per_candidate_slice_s',.012)))
        z=evaluate(s,a,model,cfg_eval,deadline=slice_end)
        good=bool(z.get('rankable') and z.get('complete') and z.get('sum_remaining_jct_ms') is not None)
        record={'kind':kind,'route_index':i,'family':a['family'],'action':copy.deepcopy(a),'complete':good,
            'cost_ms':z.get('sum_remaining_jct_ms') if good else None,'reason':z.get('reason'),
            'cpu_wall_ms':z.get('cpu_wall_ms'),'workflow_completion_ms':z.get('workflow_prediction_ms'),
            'current_window_cost_ms':z.get('unfinished_area_to_horizon_ms'),
            'continuation_cost_ms':z.get('common_continuation_value_ms'),
            'cache_counts':z.get('cache_counters'),'apply_delay_ms':cfg_eval.get('apply_delay_ms')}
        result['evaluations'].append(record)
        if not good:failed.add(key);return None
        memo[key]=z;result['complete_distinct_evaluations']+=1
        if kind=='adaptive':result['joint_cross_candidates_evaluated']+=1
        return z
    # All methods compare the same high-cap route row first. This preserves a
    # complete fixed reference before exposing any low-cap tradeoff.
    for i,a in enumerate(routes):
        z=score(a,'fixed',i)
        if z is not None:high[i]=z
        elif i==0:return end(reason='reference_unrankable')
    ref=high[0];refcost=ref['sum_remaining_jct_ms']
    n_workflows=max(1,len(ref['workflow_prediction_ms']))
    margin=max(float(cfg.get('dagv2_minimum_mean_gain_ms',1.))*n_workflows,
               float(cfg.get('dagv2_minimum_relative_gain',.002))*refcost)
    def value(z):return z['sum_remaining_jct_ms']
    fixed_i=min(high,key=lambda i:(value(high[i]),i!=0,i))
    if refcost-value(high[fixed_i])<margin:fixed_i=0
    chosen=routes[fixed_i];chosen_z=high[fixed_i]
    info.update(fixed_route=chosen['family'],fixed_reference_cost_ms=value(chosen_z),
        affinity_cost_ms=refcost,minimum_predicted_saving_sum_ms=margin,
        guard_is_empirical_hysteresis_not_error_bound=True,complete_fixed_routes=len(high))
    if public_method=='DAG-Fixed-v2':
        result['model_selection']=True;info['selected_route_index']=fixed_i
        return end(chosen,'fixed_route_selected')
    # Decoupled commits its fixed-cap route logically before evaluating budget;
    # Joint evaluates the other complete rows too. The candidate library/model,
    # deadline and margin are identical; no artificial delay for Decoupled.
    order=[fixed_i]+[i for i in high if i!=fixed_i] if public_method=='DAG-Batch-v2' else [fixed_i]
    pair_rows=[]
    alternatives=[(value(high[fixed_i]),routes[fixed_i],high[fixed_i],fixed_i)]
    for i in order:
        a,ev=responses[i];z=score(a,'adaptive',i)
        complete=z is not None and i in high
        row={'route_index':i,'route':routes[i]['family'],'distinct_budget':action_key(a)!=action_key(routes[i]),
             'complete':complete,'opportunity':ev,'fixed_cost_ms':value(high[i]),
             'adaptive_cost_ms':value(z) if z is not None else None}
        if complete:
            delta={w:high[i]['workflow_prediction_ms'][w]-z['workflow_prediction_ms'][w] for w in high[i]['workflow_prediction_ms']}
            row['workflow_saving_ms']=delta;row['predicted_beneficiaries']=sum(v>0 for v in delta.values());row['predicted_harmed']=sum(v<0 for v in delta.values())
            # Always retain fixed routes; use low cap only if that row has positive
            # NET total workflow value beyond hysteresis (not just decode benefit).
            if value(high[i])-value(z)>margin:
                alternatives.append((value(z),a,z,i))
            if public_method=='DAG-Batch-v2':alternatives.append((value(high[i]),routes[i],high[i],i))
        pair_rows.append(row)
    info['pairs']=pair_rows;info['complete_pairs']=sum(r['complete'] for r in pair_rows)
    info['distinct_complete_pairs']=sum(r['complete'] and r['distinct_budget'] for r in pair_rows)
    cost,action,z,i=min(alternatives,key=lambda v:(v[0],sum(c!=4096 for c in v[1]['caps']),v[3]))
    # A new complete route/cap is not accepted for a numerically trivial benefit.
    if value(chosen_z)-cost<margin and action_key(action)!=action_key(chosen):action,z,i=chosen,chosen_z,fixed_i
    info.update(selected_route_index=i,selected_family=action['family'],selected_caps=action['caps'],
        selected_cost_ms=value(z),predicted_total_saving_vs_Affinity_ms=refcost-value(z),
        net_workflow_saving_vs_fixed_ms=value(chosen_z)-value(z),
        unchanged_fixed_selected=action_key(action)==action_key(chosen))
    result['model_selection']=True
    result['paired_packet_attempted']=public_method=='DAG-Batch-v2'
    result['paired_packet_complete']=bool(pair_rows and all(r['complete'] for r in pair_rows))
    result['paired_has_distinct_placement_and_budget']=len(high)>1 and any(r['distinct_budget'] for r in pair_rows)
    return end(action,'net_complete_workflow_choice')


def process_plan(snapshot,model,cfg,method,deadline):
    name=cfg['dagv2_public_method']
    if name=='DAG-Batch-v1':
        legacy_cfg={k:v for k,v in cfg.items() if not k.startswith('dagv2_')}
        return legacy_process(snapshot,model,legacy_cfg,'D',deadline)
    return choose(snapshot,model,cfg,name,deadline)
