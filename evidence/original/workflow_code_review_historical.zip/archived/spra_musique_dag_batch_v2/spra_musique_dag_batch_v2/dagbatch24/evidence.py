from __future__ import annotations
import math,statistics
from collections import Counter
from pathlib import Path
from .common import load,atomic,jsonl
from .dependency import activate
activate()
from case23.evidence import validate as inherited_validate, accepted_row, output_signature
from case23 import evidence as inherited
from joint18v2.common import action_key,quantile
from . import RUNTIME_REVISION

def validate(raw,cell,cfg,packets,proof,model):
    z=inherited_validate(raw,cell,cfg,packets,proof,model)
    if not z.get('accepted'):return z
    raw=Path(raw);contract=load(raw/'runtime_contract.json')
    if contract.get('revision')!=RUNTIME_REVISION or not contract.get('event_driven'):
        raise ValueError('not the shared event executor')
    ns=load(raw/'nodes.json');plans=list(jsonl(raw/'plans.jsonl'));anchor=contract['anchor_s'];period=contract['epoch_s']
    for p in plans:
        expires=p['action_expires_ns']/1e9
        ticks=(expires-anchor)/period
        if not math.isclose(ticks,round(ticks),abs_tol=1e-5):raise ValueError('action expiry slid away from absolute clock')
        if expires-p['begin_s']>period+1e-6:raise ValueError('event extended the control horizon')
        v=p.get('dagv2')
        if v and not p.get('commit_fallback'):
            if v.get('selected_action_key')!=action_key(p['action']):raise ValueError('emitted candidate differs from selected action')
        if cell['method'].endswith('v2') and p.get('dagv2') is not None:
            if p['dagv2'].get('incomplete_candidates_ranked'):raise ValueError('partial candidate was ranked')
    z.update(event_clock_anchored=True,shared_executor_revision=RUNTIME_REVISION)
    return z

def mechanisms(raw,derived,cell):
    # Reuse existing batch metrics; no claim that the new policies call D0.
    proxy=dict(cell)
    if proxy['policy']=='net_1024':proxy['policy']='mixed_1024'
    z=inherited.mechanisms(raw,derived,proxy)
    new=cell['method'].endswith('v2')
    if new:
        z['D0_schedule_integrity_applicable']=False
        z['D0_schedule_integrity']={'pass':None,'claim':'not applicable: NEW selector, not a frozen-D0 invocation'}
    plans=list(jsonl(Path(raw)/'plans.jsonl'));ns=load(Path(raw)/'nodes.json')
    rows=[p for p in plans if p.get('dagv2')]
    reasons=Counter(p['dagv2'].get('reason','missing') for p in rows)
    selected=Counter(p['action']['family'] for p in rows if not p.get('commit_fallback'))
    proposed=Counter(f for p in rows for f in p['dagv2'].get('route_families',[]))
    pair_rows=[q for p in rows for q in p['dagv2'].get('pairs',[])]
    saving=[p['dagv2'].get('net_workflow_saving_vs_fixed_ms') for p in rows]
    saving=[float(x) for x in saving if x is not None]
    commit=[p for p in rows if not p.get('commit_fallback')]
    selected_low=sum(any(c<4096 for c in p['action']['caps']) for p in commit)
    all_log=Counter(t for p in plans for t in p.get('event_trigger',{}).get('triggers',[]))
    before_request=[];after_materialized=[]
    for n in ns.values():
        if n.get('start') is not None and n.get('ready_at') is not None:
            before_request.append(1000*(n['start']-n['ready_at']))
            after_materialized.append(1000*(n['start']-max(n['ready_at'],n.get('input_prepare_end',n['ready_at']))))
    def dist(x):return {'n':len(x),'mean':statistics.mean(x) if x else None,'p95':quantile(x,.95) if x else None,'max':max(x,default=None)}
    z['v2_mechanism']={'new_selector_decisions':len(rows),'reason_counts':dict(reasons),
       'proposed_route_families':dict(proposed),'selected_committed_families':dict(selected),
       'fixed_route_evaluations_complete':sum(p['dagv2'].get('complete_fixed_routes',0) for p in rows),
       'budget_pairs_attempted':len(pair_rows),'budget_pairs_complete':sum(bool(q['complete']) for q in pair_rows),
       'distinct_budget_pairs_complete':sum(q['complete'] and q['distinct_budget'] for q in pair_rows),
       'cap_restriction_plans_committed':selected_low,'predicted_net_saving_sum_ms':dist(saving),
       'event_trigger_counts':dict(all_log),'ready_to_submit_ms':dist(before_request),'input_prepared_to_submit_ms':dist(after_materialized),
       'real_counterfactual_claimed':False,'incomplete_scores_ranked':False}
    if new:z['cap_restriction_plans_committed']=selected_low
    z['public_executor_revision']=RUNTIME_REVISION
    atomic(Path(derived)/'mechanisms.json',z)
    return z
