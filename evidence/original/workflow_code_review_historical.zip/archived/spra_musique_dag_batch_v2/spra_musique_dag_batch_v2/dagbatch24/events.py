"""Event wakeups with immutable absolute epoch boundaries.

A wakeup is not a lease extension. New plans replace old plans explicitly and
share the next already-defined200ms boundary. Heartbeats never change it.
"""
from __future__ import annotations
import asyncio
import math
import time

class DecisionClock:
    def __init__(self,anchor,epoch=.2,coalesce=.003,min_gap=.01,reserve=.025):
        if not 0<=coalesce<epoch or not 0<reserve<epoch or not 0<=min_gap<epoch:
            raise ValueError('invalid event scheduling envelope')
        self.anchor=float(anchor);self.epoch=float(epoch);self.coalesce=coalesce
        self.min_gap=min_gap;self.reserve=reserve;self.last=None;self.tick=float(anchor)
    def boundary(self,at):
        return self.anchor+(math.floor((at-self.anchor)/self.epoch)+1)*self.epoch
    async def next(self,event):
        wait_start=time.monotonic();triggers=[]
        while True:
            now=time.monotonic()
            if event.is_set():triggers.append('ready_or_completion')
            elif now>=self.tick:triggers.append('absolute_tick')
            else:
                try:
                    await asyncio.wait_for(event.wait(),timeout=max(0.,self.tick-now))
                    triggers.append('ready_or_completion')
                except asyncio.TimeoutError:triggers.append('absolute_tick')
            event.clear()  # no clear after planning: later events remain observable
            if self.last is not None:
                await asyncio.sleep(max(0.,self.last+self.min_gap-time.monotonic()))
            await asyncio.sleep(self.coalesce)
            now=time.monotonic();bound=self.boundary(now)
            if bound-now<self.reserve:
                # The old action still expires at bound; wait for a NEW epoch rather
                # than stretching its validity. No busy loop on a set Event.
                await asyncio.sleep(max(0.,bound-time.monotonic()))
                self.tick=bound;triggers.append('insufficient_window_waited_next_boundary')
                continue
            self.last=now;self.tick=bound
            return now,bound,{'triggers':triggers,'wait_started_s':wait_start,
                  'decision_started_s':now,'absolute_expire_s':bound,
                  'controller_wait_ms':(now-wait_start)*1000,
                  'event_is_not_lease_renewal':True}
