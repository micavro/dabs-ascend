from __future__ import annotations
import copy
from .common import load
from .dependency import ROOT
from case23.design import arrival_metadata, external_identity
METHODS={
 'RR':{'scheduler':'A','policy':'fixed_4096','routing':'request_round_robin'},
 'Affinity':{'scheduler':'A','policy':'fixed_4096','routing':'original_A'},
 'DAG-Batch-v1':{'scheduler':'D','policy':'mixed_1024','routing':'original_D0'},
 'DAG-Fixed-v2':{'scheduler':'Joint','policy':'fixed_4096','routing':'new_full_workflow'},
 'DAG-Decoupled-v2':{'scheduler':'Joint','policy':'net_1024','routing':'new_full_workflow_sequential'},
 'DAG-Batch-v2':{'scheduler':'Joint','policy':'net_1024','routing':'new_full_workflow_joint'},
}
ORDERS=((0,1,2,3,4,5),(5,4,3,2,1,0),(2,3,4,5,0,1),(1,0,5,4,3,2))
def protocol():return load(ROOT/'configs/protocol.json')
def make_design(p=None):
    p=p or protocol()
    if p['N']!=16 or p['repeats']!=4 or p['seed']!=200201:raise ValueError('case protocol changed')
    methods=list(METHODS);out=[]
    for phase,key in [('core','core_configs'),('regression','regression_configs')]:
        for rep in range(1,5):
            specs=list(p[key])
            if rep%2==0:specs.reverse()
            for spec in specs:
                R=spec['replicas'];rate=spec['rate']
                for pos,i in enumerate(ORDERS[rep-1],1):
                    name=methods[i]
                    out.append({'label':f'R{R}_L{int(rate)}_T{rep}_{name}','phase':phase,'replicas':R,'active_replica_ids':list(range(R)),
                        'rate':rate,'repeat':rep,'position':pos,'method':name,**METHODS[name],
                        'N':16,'seed':200201,'source_block':1,'packet_slice':[0,16]})
    if len(set(c['label'] for c in out))!=len(out):raise ValueError('duplicate condition identity')
    return out

def cells_for(design,phase):
    if phase=='all':return list(design)
    if phase not in ('core','regression'):raise ValueError('unknown phase')
    return [c for c in design if c['phase']==phase]

def config_for(base,priors,cell):
    c=copy.deepcopy(base);p=protocol();sel=p['selector']
    c.update(replicas=cell['replicas'],workflow_count=16,arrival_rate=cell['rate'],base_cap=4096,
        batching20_policy='mixed_1024' if cell['method']=='DAG-Batch-v1' else 'fixed_4096',
        batching20_output_priors=copy.deepcopy(priors),dagv2_public_method=cell['method'],
        dagv2_min_decision_gap_s=p['runtime']['minimum_decision_gap_s'],
        dagv2_max_routes=sel['max_route_candidates'],dagv2_per_candidate_slice_s=sel['per_candidate_slice_s'],
        dagv2_minimum_mean_gain_ms=sel['minimum_mean_gain_ms'],dagv2_minimum_relative_gain=sel['minimum_relative_gain'])
    # Old C keeps its old policy/model conventions. All physically execute under
    # the same event client. The three NEW selectors share event continuation.
    return c
