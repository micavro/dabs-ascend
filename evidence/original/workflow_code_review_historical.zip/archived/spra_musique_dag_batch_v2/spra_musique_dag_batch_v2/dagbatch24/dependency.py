"""Read-only dependency chain; no dependency installation or backend deployment."""
from __future__ import annotations
import os, sys
from pathlib import Path
from .common import load, sha
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path(os.environ.get('MUSIQUE_CASE_SOURCE',ROOT.parent/'spra_musique_b1_case_v1')).resolve()

def activate():
    sys.dont_write_bytecode=True
    for rel,h in load(ROOT/'dependency_identity.json').items():
        f=SOURCE/rel
        if not f.is_file() or f.is_symlink() or sha(f)!=h:
            raise RuntimeError('Existing case dependency missing/different: '+str(f)+'; do not edit hashes or rerun GPU profiling')
    if str(SOURCE) not in sys.path:sys.path.insert(0,str(SOURCE))
    from case23.dependency import activate as old_activate,own_identity as old_identity
    return {'case':old_identity(),'prior':old_activate()}

def own_identity():
    result={}
    for name in ('dagbatch24','configs','tests','tools'):
        for p in sorted((ROOT/name).rglob('*')):
            if p.is_file() and p.suffix in ('.py','.json','.sh') and '__pycache__' not in p.parts:
                result[str(p.relative_to(ROOT))]=sha(p)
    for p in [ROOT/'dependency_identity.json',*ROOT.glob('*.sh')]:result[p.name]=sha(p)
    return result
