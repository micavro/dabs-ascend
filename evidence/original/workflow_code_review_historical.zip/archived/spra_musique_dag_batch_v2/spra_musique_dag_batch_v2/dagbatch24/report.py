"""Outcome-independent text report; all accepted conditions, positive and negative."""
from __future__ import annotations
import csv,json,math,os,statistics,uuid
from collections import defaultdict,Counter
from pathlib import Path
from .common import atomic,load
from . import REVISION,RUNTIME_REVISION
METRICS=('mean_jct_ms','p95_jct_ms','mean_request_ttft_ms','p95_request_ttft_ms',
 'mean_node_time_to_first_content_ms','mean_client_tpot_proxy_ms','p95_client_tpot_proxy_ms',
 'cohort_workflows_s','cohort_tokens_s','cohort_duration_s','output_tokens','requests')
COMPARISONS=(('DAG-Batch-v2','Affinity'),('DAG-Batch-v2','RR'),('DAG-Batch-v2','DAG-Batch-v1'),
 ('DAG-Fixed-v2','Affinity'),('DAG-Decoupled-v2','DAG-Fixed-v2'),
 ('DAG-Batch-v2','DAG-Fixed-v2'),('DAG-Batch-v2','DAG-Decoupled-v2'))

def finite(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)
def stats(vals):
    v=[float(x) for x in vals if finite(x)]
    return {'n':len(v),'mean':statistics.mean(v) if v else None,'std':statistics.stdev(v) if len(v)>1 else None,
        'min':min(v) if v else None,'max':max(v) if v else None}
def gain(a,b,metric):
    if not finite(a) or not finite(b) or b<=0:return None
    return 100*(a/b-1) if metric in ('cohort_workflows_s','cohort_tokens_s') else 100*(1-a/b)

def write_text(path,text):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.tmp.'+uuid.uuid4().hex)
    try:
        with tmp.open('w',encoding='utf-8') as f:f.write(text);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if tmp.exists():tmp.unlink()

def write_csv(path,rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def build(rows,design):
    planned={c['label']:c for c in design};seen=set();by=defaultdict(list);pair=defaultdict(dict);flat=[]
    for r in rows:
        if r['label'] in seen:raise ValueError('duplicate accepted result')
        seen.add(r['label'])
        if r['label'] not in planned:raise ValueError('unplanned result')
        c=planned[r['label']]
        if any(r[k]!=c[k] for k in ('method','rate','replicas','repeat','phase')):raise ValueError('condition identity mismatch')
        key=(r['replicas'],r['rate']);by[key+(r['method'],)].append(r)
        pair[key+(r['repeat'],)][r['method']]=r
        flat.append({k:r[k] for k in ('label','phase','replicas','rate','repeat','position','method','segment')}|{k:r['summary'].get(k) for k in METRICS})
    aggregates=[]
    for (R,rate,m),seq in sorted(by.items()):
        q={'replicas':R,'rate':rate,'method':m,'conditions':len(seq),'metrics':{k:stats([r['summary'].get(k) for r in seq]) for k in METRICS}}
        q['quality']={k:stats([r['summary'].get('semantic_quality',{}).get(k) for r in seq]) for k in ('final_em','final_f1')}
        aggregates.append(q)
    paired=[]
    for (R,rate,rep),ms in sorted(pair.items()):
        if len({r['external_work_sha256'] for r in ms.values()})>1:raise ValueError('not identical external question/arrival protocol within paired group')
        for cand,ref in COMPARISONS:
            if cand not in ms or ref not in ms:continue
            a,b=ms[cand]['summary'],ms[ref]['summary']
            q={'replicas':R,'rate':rate,'repeat':rep,'candidate':cand,'reference':ref,
               'jct_saving_ms':b['mean_jct_ms']-a['mean_jct_ms'],
               'same_output_signature':ms[cand].get('output_signature')==ms[ref].get('output_signature')}
            for metric in METRICS:
                if metric in ('output_tokens','requests'):continue
                q[metric+'_gain_pct']=gain(a.get(metric),b.get(metric),metric)
            qa=a.get('semantic_quality',{});qb=b.get('semantic_quality',{})
            for k in ('final_em','final_f1'):
                q[k+'_delta_pp']=100*(qa[k]-qb[k]) if finite(qa.get(k)) and finite(qb.get(k)) else None
                q[k+'_relative_gain_pct']=100*(qa[k]/qb[k]-1) if finite(qa.get(k)) and finite(qb.get(k)) and qb[k]>0 else None
            paired.append(q)
    pg=defaultdict(list)
    for r in paired:pg[(r['replicas'],r['rate'],r['candidate'],r['reference'])].append(r)
    ps=[]
    for (R,rate,m,b),seq in sorted(pg.items()):
        ps.append({'replicas':R,'rate':rate,'candidate':m,'reference':b,'pairs':len(seq),
          'jct_positive_pairs':sum(r['mean_jct_ms_gain_pct']>0 for r in seq),
          'jct_over_10pct_pairs':sum(r['mean_jct_ms_gain_pct']>10 for r in seq),
          'metrics':{k:stats([r[k] for r in seq]) for k in seq[0] if k.endswith('_pct') or k=='jct_saving_ms'}})
    totals={k:sum(r['summary'].get(k,0) or 0 for r in rows) for k in ('requests','output_tokens','workflows','independent_batch_matches','independent_batch_checked')}
    totals.update(accepted_conditions=len(rows),warmup_excluded=True)
    return {'revision':REVISION,'public_executor_revision':RUNTIME_REVISION,'complete':len(seen)==len(planned),
      'core_complete':all(c['label'] in seen for c in design if c['phase']=='core'),
      'regression_complete':all(c['label'] in seen for c in design if c['phase']=='regression'),
      'expected_conditions':len(planned),'accepted_conditions':len(seen),'totals':totals,
      'pending_labels':[c['label'] for c in design if c['label'] not in seen],
      'scope':'post-selected Block1 case development, same16 questions repeated; not unseen holdout, not wholeMuSiQue',
      'no_metric_time_subtraction':True,'historical_runs_included':False,
      'partial_result_not_success_claim':len(seen)!=len(planned),'aggregates':aggregates,'paired':paired,'paired_aggregates':ps},flat

def write(out,rows,design):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);result,flat=build(rows,design)
    atomic(out/'result.json',result);write_csv(out/'conditions.csv',flat);write_csv(out/'paired_gains.csv',result['paired'])
    def dump(obj):return json.dumps(obj,ensure_ascii=False,allow_nan=False,separators=(',',':'))
    lines=['DAG-Batch v2 | MuSiQue-B1-16 | 可打印结果\n',
      '本报告包含全部已接受条件，负值不删除。相对增益按同次重复配对后平均。\n',
      '四次执行仍是同一事后选定的16题，不代表全MuSiQue；旧历史测量不进入本批。\n',
      '新旧方法共同使用事件执行器。不能把相对旧历史运行的改善全归给新策略。\n',
      'TPOT为客户端代理；P95汇总为每条件P95的平均，不是逐token ITL。\n',
      'FIXED4096是回归参照，不宣称各新配置最优；质量和其他性能指标不作为事后筛选。\n',
      'V2_STATUS='+dump({k:v for k,v in result.items() if k not in ('aggregates','paired','paired_aggregates')})+'\n']
    if (out/'protocol.json').exists():
        p=load(out/'protocol.json')
        lines.append('V2_PROTOCOL='+dump({k:p.get(k) for k in ('protocol','selected_ids','original_model_sha256','original_priors_sha256','config')})+'\n')
    if (out/'suite_status.json').exists():lines.append('V2_RUN_STATE='+dump(load(out/'suite_status.json'))+'\n')
    if (out/'cleanup.json').exists():lines.append('V2_CLEANUP='+dump(load(out/'cleanup.json'))+'\n')
    for status_file in sorted((out/'attempts').glob('*/*/attempt_status.json')):
        state=load(status_file)
        if state.get('status')!='accepted':
            detail={'folder':str(status_file.parent),'state':state}
            raw_status=status_file.parent/'raw/status.json'
            if raw_status.exists():detail['raw_execution']=load(raw_status)
            validation=status_file.parent/'validation.json'
            if validation.exists():
                v=load(validation);detail['validation']={k:v.get(k) for k in ('accepted','errors','iterations','matches','classification_counts')}
            lines.append('V2_FAILED_OR_INCOMPLETE_ATTEMPT='+dump(detail)+'\n')
    lines.append('\n=== 每条件实际指标 ===\n')
    for r in sorted(rows,key=lambda r:next(i for i,c in enumerate(design) if c['label']==r['label'])):
        s=r['summary'];x={k:r.get(k) for k in ('label','phase','replicas','rate','repeat','position','method','segment')}
        x.update({k:s.get(k) for k in METRICS})
        x.update({k:s.get(k) for k in ('public_executor_revision','request_correlation','independent_batch_matches','independent_batch_checked',
            'decision_wall_ms','worker_timeout_fallback','cache_unknown_fallback','commit_fallbacks','commit_fallback_reason_counts',
            'routing_deviations_from_snapshot_affinity','route_assignments','budget_switches_total','native_cap_binding_candidates',
            'cap_restriction_plans_committed','mean_critical_path_components_ms','semantic_quality','service_prediction_by_phase',
            'per_cap','iteration_phase_counts','v2_mechanism')})
        lines.append('V2_CONDITION='+dump(x)+'\n')
    lines.append('\n=== 按配置/方法汇总；单位ms、ms/token、workflow/s、token/s ===\n')
    for a in result['aggregates']:lines.append('V2_METHOD_SUMMARY='+dump(a)+'\n')
    lines.append('\n=== 逐次配对；百分比正值为改善 ===\n')
    for a in result['paired']:lines.append('V2_PAIRED='+dump(a)+'\n')
    lines.append('\n=== 配对汇总；std是重复间样本标准差，不是总体置信区间 ===\n')
    for a in result['paired_aggregates']:lines.append('V2_GAIN_SUMMARY='+dump(a)+'\n')
    lines.append('\nV2_REPORT_END='+dump({'accepted':len(rows),'expected':len(design),'complete':result['complete'],'no_auto_tuning':True})+'\n')
    write_text(out/'RESULTS_FOR_CHAT.txt',''.join(lines))
    return result
