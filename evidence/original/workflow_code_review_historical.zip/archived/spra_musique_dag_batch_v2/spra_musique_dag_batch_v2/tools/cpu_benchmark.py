#!/usr/bin/env python3
"""Synthetic CPU evidence only, optional; never touches native runtime or dataset."""
from __future__ import annotations
from pathlib import Path
import argparse,copy,json,statistics,sys,time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from dagbatch24.dependency import activate
activate()
from dagbatch24.selector import choose
from batching20.dependency import TYPED
from dagbatch24.common import load,atomic

def sample(R):
    now=time.monotonic();ns={}
    for i in range(16):
        width=4 if i<5 else 3;w=f'SYNTHETIC_{i}';keys=[f'{w}/{j}' for j in range(width)]
        for j,k in enumerate(keys):
            state='blocked' if j else 'submitted' if i<4 else 'ready';rep=i%R if state=='submitted' else None
            ns[k]={'name':k,'wid':w,'parents':[] if j==0 else [keys[j-1]],'state':state,'phase':'decode' if state=='submitted' else 'prefill',
                'replica':rep,'prompt':2800+16*i,'output':8+(i%5),'output_done':2 if state=='submitted' else 0,'computed':2800+16*i if state=='submitted' else 0,
                'ready_at':now-.02,'prefix_hash':w,'share':2048,'max_output_tokens':96,'compiled_successors':keys[j+1:j+2],'compiled_groups':[]}
    return {'replicas':R,'nodes':ns,'ready':[k for k,n in ns.items() if n['state']=='ready'],'pressure':[sum(n['state']=='submitted' and n['replica']==r for n in ns.values()) for r in range(R)],
         'reserved_blocks':[300]*R,'capacity_blocks':[4096]*R,'state_ages_s':[0.]*R,'cache_unknown_count':0,'current_caps':[4096]*R,'inflight_batches':[],
         'queue_order':{str(r):[k for k,n in ns.items() if n['state']=='submitted' and n['replica']==r] for r in range(R)},'now':now,'decision_index':1,
         'cache_evidence':[{'prefix_hash':f'SYNTHETIC_{i}','replica':r,'tokens':2048 if r==i%R else 0,'state':'active_computed' if r==i%R else 'absent','known':True,'observed_age_s':0.} for i in range(16) for r in range(R)]}

def main():
    model={'model_id':'SYNTHETIC_NOT_A_MEASURED_CURVE','models':{str(r):{'coef':[8.,10.,15.,2.,2.,.2]} for r in range(4)}}
    cfg=load(TYPED/'configs/semantic.json');cfg.update(base_cap=4096,dagv2_per_candidate_slice_s=.012)
    rows=[]
    for R in (2,3,4):
        for method in ('DAG-Fixed-v2','DAG-Decoupled-v2','DAG-Batch-v2'):
            records=[]
            for _ in range(5):
                s=sample(R);c=copy.deepcopy(cfg);c['replicas']=R;t=time.monotonic();z=choose(s,model,c,method,t+.06)
                records.append({'wall_ms':(time.monotonic()-t)*1000,'complete_scores':z['complete_distinct_evaluations'],
                   'complete_pairs':z['dagv2'].get('complete_pairs',0),'reason':z['dagv2'].get('reason'),'deadline_reached':z['deadline_reached']})
            rows.append({'replicas':R,'method':method,'nodes':53,'records':records,'mean_wall_ms':statistics.mean(r['wall_ms'] for r in records)})
    output={'scope':'53-node synthetic CPU-only snapshots, synthetic coefficients; NOT GPU policy efficacy, not a hardware timing guarantee','model_inference_requests':0,'network_requests':0,'live_runtime_reads':0,'rows':rows}
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path);args=parser.parse_args()
    if args.out:atomic(args.out,output)
    print(json.dumps(output,ensure_ascii=False))
if __name__=='__main__':main()
