# MuSiQue DAG-Batch v2 实验代码

独立客户端版本。保留原MuSiQue-B1-16、typed JSON真实父子交接、自然EOS、原服务模型与先验；新增有限放置×额度净JCT比较，以及所有方法共用的事件唤醒执行器。

**本包没有新的GPU结果，不保证超过10%。不覆盖旧实验、不部署hook、不重启Pod、不重新下载数据、不重拟合模型。**

## 依赖
在GPU39的同一目录下已有：

    spra_musique_dag_batch_v2/           # 本包
    spra_musique_b1_case_v1/             # 已完成案例的代码
    spra_musique_d0_batching_v1/         # 原D₀＋Mixed1024
    spra_stage19_typed_handoff_v1/       # 结构化实际父答案
    spra_stage19_musique_joint_v1/       # 原执行器/数据/因果模型

默认读取 `../spra_musique_d0_batching_v1/prepared/latest.json`指向的既有冻结模型/先验；公共运行路径仍为 `/home/wmy/sci/spra_core_exp/joint_e1`，现有四个服务实例，目标原hook哈希不变。缺文件/哈希不符时停止，不编辑哈希、不重新运行旧GPU标定来“补齐”。可在确实更换目录时通过MUSIQUE_CASE_SOURCE、MUSIQUE_BATCH_SOURCE、STAGE19_SOURCE、STAGE19_TYPED_SOURCE指定原目录，内容身份仍需一致。

## 最短操作
在GPU39激活原`spra-exp`环境，进入新目录，无其他实验运行：

```bash
set -euo pipefail
mkdir -p logs
bash run_checks.sh 2>&1 | tee logs/checks.log
bash run_prepare.sh 2>&1 | tee logs/prepare.log
python -B tools/run_v2.py gate
bash run_core.sh 2>&1 | tee logs/core.log
```

这是48个核心条件，不是重复旧136格。完成后先打印：

```bash
cat RESULTS_FOR_CHAT.txt
```

把这份文本复制或上传即可，不需要先传完整raw zip。每个接受条件后都会更新文本，运行中断也可打印同一文件。JSON行前缀是V2_STATUS、V2_PROTOCOL、V2_CONDITION、V2_METHOD_SUMMARY、V2_PAIRED、V2_GAIN_SUMMARY、V2_REPORT_END。

预声明3副本/4s退化点回归另外24格，无需等待主方法取得正收益才执行：

```bash
bash run_regression.sh 2>&1 | tee logs/regression.log
cat RESULTS_FOR_CHAT.txt
```

一次执行所有72格可用`bash run_all.sh`，已接受条件会跳过。

## 配置与方法
主配置：N16，2副本/4 workflow/s；N16，4副本/8 workflow/s。回归：N16，3副本/4 workflow/s。原wave形状不变；不是稳态服务容量测试。

六种方法共同使用新版事件运行时：

| 名称 | 决策 |
|---|---|
| RR | 原轮询规则＋fixed4096，无搜索 |
| Affinity | 原A＋fixed4096，无搜索 |
| DAG-Batch-v1 | 原D₀＋Mixed1024；旧策略在新公共运行时上执行 |
| DAG-Fixed-v2 | 新候选放置，fixed4096 |
| DAG-Decoupled-v2 | 新库同模型，先按4096选放置，再选该放置的额度 |
| DAG-Batch-v2 | 新库同模型，比较各放置自己的fixed/conditional1024完整代价 |

三类新方法最多4个完整放置候选；Joint最多8个完整动作评分。所有到达未完成workflow按一次最终完成计账，不重复加总平行分支。1024是候选，不是遇到竞争自动执行的命令。没有正净预测收益时保持4096。详细阈值、时间语义和限制见`docs/EXPERIMENT_CONTRACT.md`。

不把公共运行时改善算作主方法独占收益；旧历史136格不并入本批。4096为共同回归参照，不声称每个新配置最优。16题此前已经用于开发，结论限于该案例。

## 恢复
一般中断，重新执行相同脚本。程序读取本包records/latest.json，校验冻结身份后续跑，不重复已经接受的条件。

```bash
bash run_core.sh --resume runs/DAG_BATCH_V2_实际目录
```

真正未完成的请求attempt，保留旧记录并显式重试：

```bash
bash run_core.sh --resume runs/DAG_BATCH_V2_实际目录 --retry-incomplete
```

完整但验收失败的条件不能通过该开关绕过；完整但性能差的条件不能重跑。原始数据齐全、仅后处理未完成时，不新增生成。

## 输出与统计
- 根目录和run内的`RESULTS_FOR_CHAT.txt`：可直接cat的综合文本。
- `result.json`、`conditions.csv`、`paired_gains.csv`：机器可读完整主指标。
- `attempts/.../raw`：nodes、plans、controls、backend、action timing、JCT/TTFT/TPOT记录。
- `attempts/.../derived`：语义质量、机制计数、工作流逐题路径与输出量。
- `segments`：各执行段的服务身份、固定次数预热（每活跃副本2个普通请求＋1个JSON请求）、清理。
- `archives`：各完整阶段的全量zip，包含负结果和失败attempt，不覆盖旧归档。

最终报告采用同重复内配对百分比再求均值，同时保存绝对ms节省、标准差、范围和正向次数。质量仅辅助记录；输出不同仍保留，不强迫相同长度。TPOT代理N<=1或可见事件不足时为N/A，不填0。不从实测JCT扣除规划耗时。

打印已有报告而不生成新请求：

```bash
bash run_report.sh > logs/report_print.txt
# 或直接读取已经自动生成的文本
cat RESULTS_FOR_CHAT.txt
```

## 本地验证范围
测试记录在`TEST_RESULTS.txt`。CPU/mock包括六方法×1–4副本调用实际client/hook的假引擎、真实spawn、事件唤醒、租约边界、净收益选择逻辑、72格编排、断点恢复、负值保留及文本/归档。

没有原生vLLM/GPU推理测试、没有新服务器性能数字。`analysis/CPU_BENCHMARK.json`是53节点合成状态与合成系数下的CPU开销记录，不是实际GPU收益或GPU39时限承诺。`tools/cpu_benchmark.py`是可选离线工具，正常运行不需要它。
