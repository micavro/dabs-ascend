#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
sha256sum -c SHA256SUMS
python -B -m unittest discover -s tests -v
mkdir -p logs
python -B tools/run_v2.py plan > logs/declared_plan.json
echo "V2_PLAN_SAVED=logs/declared_plan.json"
