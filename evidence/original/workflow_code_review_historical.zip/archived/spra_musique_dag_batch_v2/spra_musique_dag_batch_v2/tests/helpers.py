"""Synthetic inputs ONLY. No test result is a MuSiQue measurement."""
from __future__ import annotations
import copy,sys,json,statistics
from pathlib import Path
from dagbatch24.dependency import activate
activate()
from batching20.dependency import TYPED,SOURCE
sys.path.insert(0,str(TYPED/'tests'));sys.path.insert(0,str(SOURCE/'tests'))
from test_typed_contract import fixture,FakeTokenizer
from semantic19.dataset import compile_record
from typed19.workflow import compile_packets,instantiate
from case23.common import atomic,load,sha
MODEL={'model_id':'SYNTHETIC_NOT_GPU','models':{str(r):{'coef':[1.,0.,0.,0.,0.,0.]} for r in range(4)}}
PRIORS={'3':{'p75':8},'4':{'p75':8}}
CFG=load(TYPED/'configs/semantic.json');CFG.update(base_cap=4096,workflow_count=16,document_tokens_budget=256)

def public_records(n=16):
    out=[];gold=[]
    for i in range(n):
        raw=fixture();raw['id']=f'SYNTHETIC_CASE_{i:03d}';raw['paragraphs'][0]['title']=f'City_{i:03d}'
        if i<5:raw['question_decomposition'].append({'id':100,'question':'Which city in #3?','answer':'Paris','paragraph_support_idx':0})
        p,g=compile_record(raw);out.append(p);gold.append(g)
    return out,gold

def dataset(root):
    root.mkdir(parents=True);ps,gs=public_records()
    (root/'pilot.public.jsonl').write_text(''.join(json.dumps(p)+'\n' for p in ps))
    (root/'evaluation_gold.jsonl').write_text(''.join(json.dumps(p)+'\n' for p in gs))
    m={'files':{p.name:sha(p) for p in root.iterdir() if p.is_file()},'counts':{'pilot':16}}
    atomic(root/'manifest.json',m);return ps,m

async def fake_complete(raw,nodes,materializer,cfg,method,initial,delay=1.):
    raw=Path(raw);raw.mkdir(parents=True)
    original=copy.deepcopy(nodes);case=raw.parent.name+'/raw';R=len(initial)
    atomic(raw/'manifest.json',{'case':case,'config':cfg,'method':method,'input_nodes':original,'model_id':MODEL['model_id'],
        'identities':[{'pod':s['pod'],'pid':s['pid'],'boot_id':s['boot_id']} for s in initial]})
    ctrl={'plan_id':'TEST','not_before_ns':0,'action_expires_ns':10**12,'caps':[cfg['base_cap']]*R,'totals':[4096]*R}
    events=[];i=0;iter_no=0
    for k,n in nodes.items():
        await materializer(k,nodes);i+=1;n['arrival']=100+n['arrival_offset']
        n['start']=max([100.+i*3.,n['arrival']]+[nodes[p]['finish'] for p in n['parents']])
        n.update(state='done',replica=(i-1)%R,finish=n['start']+delay,
            stream={'text':'{"answer":"Paris"}','finish_reason':'stop','usage':{'completion_tokens':8,'prompt_tokens':n['prompt']}})
        events.append({'event':'accept','prompt_hash':n['hash'],'request_id':k,'replica':n['replica']})
        computed=0
        while computed<n['prompt']:
            from case23.batchcheck import prefill_chunk
            take=prefill_chunk(n['prompt']-computed,cfg['base_cap']);iter_no+=1
            queue={'request_id':k,'prefill':True,'prompt':n['prompt'],'computed':computed}
            events.append({'event':'iteration','replica':n['replica'],'pid':initial[n['replica']]['pid'],'case':case,'iteration':iter_no,
              'plan_id':'TEST','plan_reason':'lease_ok','execution_phase':'current_action','begin_ns':iter_no+10,'effective_ns':iter_no+10,
              'total':4096,'prefill_cap':cfg['base_cap'],'ordered_before':{'running':[queue] if computed else [],
                'waiting':[] if computed else [queue],'swapped':[]},
              'scheduled':[{'request_id':k,'tokens':take,'prefill':True}],
              'prefill_logical_tokens':take,'decode_tokens':0,'preemptions':0,
              'remaining_prefill_in_before':n['prompt']-computed,'order':{}})
            computed+=take
    groups={}
    for n in nodes.values():groups.setdefault(n['wid'],[]).append(n)
    j=[1000*(max(n['finish'] for n in v)-v[0]['arrival']) for v in groups.values()]
    dur=max(n['finish'] for n in nodes.values())-min(n['arrival'] for n in nodes.values())
    s={'condition_valid':True,'requests':len(nodes),'workflows':len(groups),'output_tokens':len(nodes)*8,
       'mean_jct_ms':statistics.mean(j),'p95_jct_ms':max(j),'cohort_duration_s':dur,
       'cohort_workflows_s':len(groups)/dur,'cohort_tokens_s':len(nodes)*8/dur,
       'budget_invariants':True,'control_time_match':True,'request_correlation':f'{len(nodes)}/{len(nodes)}',
       'native_next_batch_matches':iter_no,'native_next_batch_checked':iter_no,
       'mean_critical_path_components_ms':{'content_receive':statistics.mean(j)},
       'mean_request_ttft_ms':100.,'p95_request_ttft_ms':110.,'mean_client_tpot_proxy_ms':20.,
       'p95_client_tpot_proxy_ms':25.,'mean_node_time_to_first_content_ms':120.}
    atomic(raw/'runtime_contract.json',{'revision':'dag-batch-event-runtime-1','anchor_s':100.,'epoch_s':cfg['epoch_s'],'event_driven':True})
    s.update(public_executor_revision='dag-batch-event-runtime-1',event_ready_handling=True)
    atomic(raw/'summary.json',s);atomic(raw/'nodes.json',nodes);atomic(raw/'controls.json',[ctrl])
    atomic(raw/'status.json',{'execution':'complete','error':None});atomic(raw/'trace_capture.json',{'partial_lines':0,'condition_failed':False})
    atomic(raw/'initial_cache.json',{'status':[{'cache':{'records':[]}} for _ in range(R)]})
    (raw/'plans.jsonl').write_text('');(raw/'backend.jsonl').write_text(''.join(json.dumps(e)+'\n' for e in events))
    return s,events
