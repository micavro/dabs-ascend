import copy,contextlib,io,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from helpers import CFG,FakeTokenizer
from dagbatch24.runner import warmup
from dagbatch24 import event_client as C

class WarmupTests(unittest.IsolatedAsyncioTestCase):
    async def run_size(self,R,bad=False):
        calls=[];cfg=copy.deepcopy(CFG);cfg['replicas']=R
        async def pool(*a):return list(range(100,130))
        async def execute(client,rt,initial,cf,ns,folder,method,model,**kw):
            self.assertEqual(len(ns),R);self.assertEqual(len(initial),R)
            self.assertEqual({n['warm_replica'] for n in ns.values()},set(range(R)))
            self.assertEqual(method,'Forced');self.assertIsNone(model)
            calls.append([n['prompt'] for n in ns.values()])
            for n in ns.values():
                n['replica']=n['warm_replica'];n['answer_contract']={'status':'format_error' if bad else 'answer'}
            return {'condition_valid':True,'native_next_batch_matches':R,'native_next_batch_checked':R,'output_tokens':8*R},[]
        with tempfile.TemporaryDirectory() as d,patch.object(C,'token_pool',side_effect=pool),patch.object(C,'execute',side_effect=execute),contextlib.redirect_stdout(io.StringIO()):
            await warmup(None,Path(d),[{} for _ in range(R)],cfg,Path(d)/'warm',FakeTokenizer())
            self.assertEqual(len(calls),3)
    async def test_one_replica_does_not_warm_four(self):await self.run_size(1)
    async def test_two_replicas_does_not_warm_four(self):await self.run_size(2)
    async def test_three_replicas_does_not_warm_four(self):await self.run_size(3)
    async def test_four_replicas_warmup(self):await self.run_size(4)
    async def test_guided_failure_not_retried(self):
        with self.assertRaisesRegex(ValueError,'guided warmup'):await self.run_size(2,True)
