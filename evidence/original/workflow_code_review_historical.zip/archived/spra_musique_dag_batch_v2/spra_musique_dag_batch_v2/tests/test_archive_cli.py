from __future__ import annotations
import contextlib,hashlib,io,json,os,subprocess,sys,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
from helpers import CFG
from dagbatch24 import runner as E
from dagbatch24.common import atomic
ROOT=Path(__file__).resolve().parents[1]

class ArchiveCLITests(unittest.TestCase):
    def test_archive_receipt_and_every_file_hash(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);run=root/'runs/test';run.mkdir(parents=True)
            atomic(run/'result.json',{'accepted_conditions':0,'core_complete':False,'regression_complete':False,'complete':False})
            atomic(run/'cleanup.json',{'backend_drained':True});(run/'RESULTS_FOR_CHAT.txt').write_text('SYNTHETIC TEST NOT GPU RESULT')
            with patch.object(E,'ROOT',root),patch.object(E,'own_identity',return_value={}),contextlib.redirect_stdout(io.StringIO()):receipt=E.archive(run)
            self.assertTrue(receipt['partial_snapshot_not_claimed_complete'])
            with zipfile.ZipFile(receipt['path']) as z:
                self.assertIsNone(z.testzip())
                for line in z.read('ARCHIVE_SHA256SUMS').decode().splitlines():
                    h,name=line.split('  ',1);self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(),h)
    def test_archive_not_clean_refused(self):
        with tempfile.TemporaryDirectory() as td:
            atomic(Path(td)/'result.json',{});atomic(Path(td)/'cleanup.json',{'backend_drained':False})
            with self.assertRaises(ValueError):E.archive(td)
    def test_plan_cli_does_not_create_run(self):
        # Reads frozen protocol only; does not invoke native gate or model.
        before=set((ROOT/'runs').glob('*')) if (ROOT/'runs').exists() else set()
        proc=subprocess.run([sys.executable,'-B',str(ROOT/'tools/run_v2.py'),'plan'],text=True,capture_output=True,timeout=15)
        self.assertEqual(proc.returncode,0,proc.stderr);data=json.loads(proc.stdout)
        self.assertEqual(len(data['design']),72)
        self.assertEqual(before,set((ROOT/'runs').glob('*')) if (ROOT/'runs').exists() else set())
