from __future__ import annotations
import asyncio,copy,json,statistics,tempfile,time,unittest
from pathlib import Path
from helpers import CFG,MODEL,PRIORS
from dagbatch24.events import DecisionClock
from dagbatch24 import design,report
from dagbatch24.event_client import Publisher,rr_reference
from joint18v2.common import action_key

class EventTests(unittest.IsolatedAsyncioTestCase):
    async def test_set_event_wakes_before_unrelated_periodic_wait(self):
        now=time.monotonic();e=asyncio.Event();c=DecisionClock(now,epoch=1.,reserve=.01,min_gap=0.,coalesce=0.)
        c.tick=now+1.
        task=asyncio.create_task(c.next(e));await asyncio.sleep(.001);self.assertFalse(task.done());e.set()
        start,end,trace=await asyncio.wait_for(task,.5)
        self.assertIn('ready_or_completion',trace['triggers']);self.assertAlmostEqual(end,now+1.,places=6)
    async def test_expiry_always_anchor_boundary(self):
        now=time.monotonic();c=DecisionClock(now,.1,.001,.003,.01);e=asyncio.Event()
        for i in range(4):
            e.set();start,end,_=await c.next(e)
            self.assertLessEqual(end-start,.1+1e-7)
            self.assertAlmostEqual((end-now)/.1,round((end-now)/.1),places=5)
    async def test_event_during_plan_not_cleared(self):
        now=time.monotonic();c=DecisionClock(now,.2,0.,0.,.01);e=asyncio.Event();e.set()
        await c.next(e);e.set() # represents a dependency completion during search
        _,_,trace=await c.next(e);self.assertIn('ready_or_completion',trace['triggers'])
    async def test_short_window_waits_boundary_instead_of_extending(self):
        now=time.monotonic();anchor=now-.045;c=DecisionClock(anchor,.05,0.,0.,.012);c.tick=anchor+.05
        e=asyncio.Event();e.set();begin,end,tr=await c.next(e)
        self.assertGreaterEqual(begin,anchor+.05)
        self.assertAlmostEqual((end-anchor)/.05,round((end-anchor)/.05),places=5)
    async def test_cancel_wait_does_not_clear_future_events(self):
        now=time.monotonic();c=DecisionClock(now,1.,0.,0.,.01);c.tick=now+1.;e=asyncio.Event()
        t=asyncio.create_task(c.next(e));await asyncio.sleep(.001);t.cancel()
        with self.assertRaises(asyncio.CancelledError):await t
        e.set();_,_,tr=await c.next(e);self.assertIn('ready_or_completion',tr['triggers'])
    async def test_heartbeat_keeps_algorithm_expiry(self):
        with tempfile.TemporaryDirectory() as td:
            initial=[{'pod':'spra-vllm-0','pid':1,'boot_id':'SYNTHETIC'}];p=Publisher(td,initial,'T',CFG)
            now=time.monotonic_ns();expiry=now+500000000
            await p.set([1024],[[]],now,expiry)
            await p.flush('heartbeat');self.assertEqual(p.record['action_expires_ns'],expiry)
            self.assertEqual(p.caps_at(expiry),[4096])
    def test_bad_clock_envelope(self):
        with self.assertRaises(ValueError):DecisionClock(0.,.2,reserve=.2)


def make_rows():
    ds=design.make_design();rows=[]
    for c in ds:
        base=1000.+10*c['repeat'];val=base+(200 if c['method']=='DAG-Batch-v2' else 0.)
        s={k:1. for k in report.METRICS};s.update(mean_jct_ms=val,p95_jct_ms=val+100.,workflows=16,requests=53,output_tokens=400,
          public_executor_revision='dag-batch-event-runtime-1',semantic_quality={'final_em':0.,'final_f1':.1})
        rows.append({**c,'segment':'synthetic','external_work_sha256':str((c['replicas'],c['rate'],c['repeat'])),'output_signature':'same','summary':s})
    return ds,rows

class DesignReportTests(unittest.TestCase):
    def test_sizes_and_regression_preregistered(self):
        ds=design.make_design();self.assertEqual(len(ds),72);self.assertEqual(len(design.cells_for(ds,'core')),48)
        self.assertEqual(len(design.cells_for(ds,'regression')),24)
    def test_method_positions_have_equal_means(self):
        ds=design.make_design()
        for m in design.METHODS:
            self.assertEqual(statistics.mean(c['position'] for c in ds if c['method']==m),3.5)
    def test_input_and_seed_common(self):
        ds=design.make_design();self.assertTrue(all(c['N']==16 and c['seed']==200201 and c['packet_slice']==[0,16] for c in ds))
    def test_new_methods_share_configuration(self):
        cells=[c for c in design.make_design()[:6] if c['method'].endswith('v2')]
        configs=[design.config_for(CFG,PRIORS,c) for c in cells]
        for c in configs:c.pop('dagv2_public_method')
        self.assertTrue(all(c==configs[0] for c in configs))
    def test_report_keeps_all_negative_conditions(self):
        ds,rows=make_rows();res,flat=report.build(rows,ds)
        self.assertTrue(res['complete']);self.assertEqual(len(flat),72)
        p=[p for p in res['paired_aggregates'] if p['candidate']=='DAG-Batch-v2' and p['reference']=='Affinity']
        self.assertTrue(all(p['metrics']['mean_jct_ms_gain_pct']['mean']<0 for p in p))
    def test_incomplete_remains_incomplete(self):
        ds,r=make_rows();res,_=report.build(r[:1],ds);self.assertFalse(res['complete']);self.assertEqual(len(res['pending_labels']),71)
    def test_duplicate_rejected(self):
        ds,r=make_rows()
        with self.assertRaises(ValueError):report.build(r+[r[0]],ds)
    def test_mismatched_external_trace_rejected(self):
        ds,r=make_rows();r[0]['external_work_sha256']='wrong'
        with self.assertRaises(ValueError):report.build(r,ds)
    def test_tpot_missing_stays_null(self):
        ds,r=make_rows()
        for x in r:x['summary']['mean_client_tpot_proxy_ms']=None
        res,_=report.build(r,ds)
        self.assertTrue(all(x['metrics']['mean_client_tpot_proxy_ms']['mean'] is None for x in res['aggregates']))
    def test_text_has_every_condition_once(self):
        ds,r=make_rows()
        with tempfile.TemporaryDirectory() as td:
            report.write(td,r,ds);text=(Path(td)/'RESULTS_FOR_CHAT.txt').read_text()
            self.assertEqual(text.count('\nV2_CONDITION='),72);self.assertIn('V2_REPORT_END=',text)
            for l in text.splitlines():
                if l.startswith('V2_'):json.loads(l.split('=',1)[1])
    def test_zero_quality_denominator_not_infinity(self):
        ds,r=make_rows();res,_=report.build(r,ds)
        self.assertTrue(all(p['final_em_relative_gain_pct'] is None for p in res['paired']))
    def test_actual_paired_percent_not_ratio_of_means(self):
        ds,r=make_rows();res,_=report.build(r,ds)
        p=res['paired_aggregates'][0];seq=[q for q in res['paired'] if all(q[k]==p[k] for k in ('replicas','rate','candidate','reference'))]
        self.assertEqual(p['metrics']['mean_jct_ms_gain_pct']['mean'],statistics.mean(q['mean_jct_ms_gain_pct'] for q in seq))
