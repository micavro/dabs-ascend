from __future__ import annotations
import copy, time, unittest
from unittest.mock import patch
from helpers import CFG, MODEL
from dagbatch24 import selector as S
from joint18v2.common import action_key


def snapshot():
    now=time.monotonic();ns={}
    def n(k,w,parents,phase='prefill',state='ready',rep=None,prompt=2048,output=12):
        ns[k]={'name':k,'wid':w,'parents':parents,'state':state,'phase':phase,'replica':rep,'prompt':prompt,'output':output,
            'output_done':0,'computed':0,'ready_at':now-.02,'prefix_hash':w,'share':1024,'max_output_tokens':96,'compiled_successors':[],'compiled_groups':[]}
    n('r','wf',[],state='done',rep=0);n('a','wf',['r']);n('b','wf',['r'],output=24);n('j','wf',['a','b'],state='blocked',prompt=1024)
    n('d','background',[],phase='decode',state='submitted',rep=0,output=18)
    ns['d']['computed']=2048;ns['d']['output_done']=2
    for k,nx in ns.items():
        nx['compiled_successors']=[j for j,y in ns.items() if k in y['parents']]
        if k in ('a','b'):nx['compiled_groups']=[['a','b']]
    return {'replicas':2,'nodes':ns,'ready':['a','b'],'pressure':[4,0],'reserved_blocks':[200,0],'capacity_blocks':[4096,4096],
        'state_ages_s':[0.,0.],'cache_unknown_count':0,'cache_evidence':[{'prefix_hash':h,'replica':r,'tokens':1024 if r==0 else 0,
        'state':'active_computed' if r==0 else 'absent','known':True,'observed_age_s':0.} for h in ('wf','background') for r in range(2)],
        'now':now,'prefix_history':{'wf':[0]},'current_caps':[4096,4096],'queue_order':{'0':['d'],'1':[]},'inflight_batches':[],'decision_index':1}

class PolicyTests(unittest.TestCase):
    def cfg(self):
        c=copy.deepcopy(CFG);c.update(replicas=2,base_cap=4096,dagv2_per_candidate_slice_s=.1,planning_soft_limit_s=2.)
        return c
    def test_routes_include_balance_and_reference(self):
        routes,info=S.proposed_routes(snapshot(),MODEL,self.cfg())
        self.assertEqual(routes[0]['family'],'affinity');self.assertIn('remaining_work_balanced',info['route_families']);self.assertLessEqual(len(routes),4)
    def test_no_submitted_migration(self):
        s=snapshot();before=copy.deepcopy(s);rs,_=S.proposed_routes(s,MODEL,self.cfg())
        self.assertEqual(s,before)
        self.assertTrue(all(set(a['placement'])==set(s['ready']) for a in rs))
    def test_cache_absence_and_unknown_are_different(self):
        s=snapshot();c=self.cfg();a=S.observed_cache(s,c);self.assertEqual(a[('wf',1)],0)
        s['cache_evidence']=[e for e in s['cache_evidence'] if e['replica']!=1]
        self.assertNotIn(('wf',1),S.observed_cache(s,c))
    def test_stale_cache_excluded(self):
        s=snapshot();s['cache_evidence'][0]['observed_age_s']=99.
        self.assertNotIn(('wf',0),S.observed_cache(s,self.cfg()))
    def test_proposal_uses_no_future_answer_content(self):
        a=snapshot();b=copy.deepcopy(a)
        for n in b['nodes'].values():n.update(dataset_id='DIFFERENT',gold='SECRET',stream={'text':'SECRET'},tokens=[42]*3000)
        ra,_=S.proposed_routes(a,MODEL,self.cfg());rb,_=S.proposed_routes(b,MODEL,self.cfg())
        self.assertEqual([action_key(x) for x in ra],[action_key(x) for x in rb])
    def test_join_completion_uses_max_not_branch_sum(self):
        s=snapshot();own={(k,r):0. if n['state']=='done' else 1. for k,n in s['nodes'].items() for r in range(2)}
        g=S.graph_estimates(s,own,{'a':0,'b':1},[0,0])
        self.assertEqual(g['finish']['j'],2.)
    def test_known_cycle_fails(self):
        s=snapshot();s['nodes']['r']['parents']=['j']
        own={(k,r):1. for k in s['nodes'] for r in range(2)}
        with self.assertRaises(ValueError):S.graph_estimates(s,own,{},[0,0])
    def test_all_methods_use_same_candidate_library(self):
        s=snapshot();c=self.cfg();lib=[]
        orig=S.proposed_routes
        def wrap(*a):
            x=orig(*a);lib.append([action_key(y) for y in x[0]]);return x
        with patch.object(S,'proposed_routes',side_effect=wrap):
            for name in S.NEW_METHODS:S.choose(s,MODEL,c,name,time.monotonic()+3)
        self.assertEqual(lib[0],lib[1]);self.assertEqual(lib[1],lib[2])
    def test_higher_uncached_work_affects_balancing(self):
        s=snapshot();m=copy.deepcopy(MODEL)
        for v in m['models'].values():v['coef']=[1.,30.,2.,0.,0.,0.]
        own,loads,cache=S.estimate_work(s,m,self.cfg())
        self.assertLess(own['a',0],own['a',1])
    def test_no_prefill_avoids_search(self):
        s=snapshot();s['ready']=[];s['nodes']={'d':s['nodes']['d']}
        with patch.object(S,'evaluate',side_effect=AssertionError('should not evaluate')):
            ans=S.choose(s,MODEL,self.cfg(),'DAG-Batch-v2')
        self.assertEqual(ans['dagv2']['reason'],'no_prefill_control_opportunity')
    def test_reference_timeout_never_ranks_partial(self):
        z={'complete':False,'rankable':False,'sum_remaining_jct_ms':None,'reason':'cpu_deadline'}
        with patch.object(S,'evaluate',return_value=z):a=S.choose(snapshot(),MODEL,self.cfg(),'DAG-Batch-v2')
        self.assertEqual(a['dagv2']['reason'],'reference_unrankable');self.assertFalse(a['model_selection'])
    def test_low_cap_only_when_net_objective_better(self):
        s=snapshot();base=S.reference(s,self.cfg());routes=[base]
        # Candidate-local results are synthetic, explicitly testing selection not GPU efficacy.
        def ev(s,a,m,c,**kw):
            cost=1100 if min(a['caps'])<4096 else 1000
            return {'complete':True,'rankable':True,'sum_remaining_jct_ms':cost,'reason':'mock','workflow_prediction_ms':{'wf':cost*.5,'background':cost*.5}}
        with patch.object(S,'proposed_routes',return_value=(routes,{})),patch.object(S,'evaluate',side_effect=ev):
            ans=S.choose(s,MODEL,self.cfg(),'DAG-Batch-v2')
        self.assertEqual(ans['action']['caps'],[4096,4096])
    def test_positive_low_cap_is_selectable(self):
        s=snapshot();base=S.reference(s,self.cfg())
        def ev(s,a,m,c,**kw):
            low=min(a['caps'])<4096;cost=850 if low else 1000
            return {'complete':True,'rankable':True,'sum_remaining_jct_ms':cost,'reason':'mock',
                'workflow_prediction_ms':{'wf':450 if low else 400,'background':400 if low else 600}}
        with patch.object(S,'proposed_routes',return_value=([base],{})),patch.object(S,'evaluate',side_effect=ev):
            ans=S.choose(s,MODEL,self.cfg(),'DAG-Batch-v2')
        self.assertIn(1024,ans['action']['caps']);self.assertEqual(ans['dagv2']['pairs'][0]['predicted_harmed'],1)
    def test_incomplete_low_cap_does_not_beat_fixed(self):
        s=snapshot();base=S.reference(s,self.cfg())
        def ev(s,a,m,c,**kw):
            if min(a['caps'])<4096:return {'complete':False,'rankable':False,'sum_remaining_jct_ms':None,'reason':'cpu_deadline'}
            return {'complete':True,'rankable':True,'sum_remaining_jct_ms':1000,'reason':'mock','workflow_prediction_ms':{'wf':500,'background':500}}
        with patch.object(S,'proposed_routes',return_value=([base],{})),patch.object(S,'evaluate',side_effect=ev):a=S.choose(s,MODEL,self.cfg(),'DAG-Batch-v2')
        self.assertEqual(a['action']['caps'],[4096,4096]);self.assertEqual(a['dagv2']['complete_pairs'],0)
    def test_real_kernel_result_keeps_area_identity(self):
        s=snapshot();cfg=self.cfg();a=S.choose(s,MODEL,cfg,'DAG-Batch-v2',time.monotonic()+3.)
        self.assertGreater(a['complete_distinct_evaluations'],0)
        for e in a['evaluations']:
            if e['complete']:self.assertAlmostEqual(e['cost_ms'],sum(e['workflow_completion_ms'].values()))
    def test_fixed_branch_does_not_generate_budget_work(self):
        with patch.object(S,'budget_response',side_effect=AssertionError('unnecessary budget work')):
            a=S.choose(snapshot(),MODEL,self.cfg(),'DAG-Fixed-v2',time.monotonic()+2)
        self.assertEqual(a['action']['caps'],[4096,4096])
    def test_invalid_method_rejected(self):
        with self.assertRaises(ValueError):S.choose(snapshot(),MODEL,self.cfg(),'ORACLE')
    def test_old_v1_is_original_entry(self):
        marker={'action':'marker'};cfg=self.cfg();cfg['dagv2_public_method']='DAG-Batch-v1';cfg['batching20_policy']='mixed_1024'
        with patch.object(S,'legacy_process',return_value=marker) as call:
            out=S.process_plan(snapshot(),MODEL,cfg,'D',time.monotonic()+1.)
        self.assertIs(out,marker);self.assertEqual(call.call_args.args[3],'D');self.assertNotIn('dagv2_public_method',call.call_args.args[2])

class JointInteractionTests(unittest.TestCase):
    def test_joint_can_change_route_because_budget_changes_its_value(self):
        s=snapshot();cfg=copy.deepcopy(CFG);cfg.update(base_cap=4096,replicas=2,planning_soft_limit_s=1.)
        ref=S.reference(s,cfg);alt=copy.deepcopy(ref);alt['family']='synthetic_alternative';alt['placement']={k:1 for k in ref['placement']}
        def budgets(s,a,m,c):
            b=copy.deepcopy(a);b['caps']=[1024,1024];return b,{'reason':'synthetic_for_selection_logic'}
        def evaluation(s,a,m,c,**kw):
            other=all(v==1 for v in a['placement'].values());low=1024 in a['caps']
            cost={(False,False):1000,(False,True):950,(True,False):1050,(True,True):800}[other,low]
            return {'complete':True,'rankable':True,'sum_remaining_jct_ms':cost,'reason':'synthetic','workflow_prediction_ms':{'wf':cost}}
        with patch.object(S,'proposed_routes',return_value=([ref,alt],{})),patch.object(S,'budget_response',side_effect=budgets),patch.object(S,'evaluate',side_effect=evaluation):
            dec=S.choose(s,MODEL,cfg,'DAG-Decoupled-v2',time.monotonic()+2)
            joint=S.choose(s,MODEL,cfg,'DAG-Batch-v2',time.monotonic()+2)
        self.assertEqual(dec['action']['placement'],ref['placement']);self.assertEqual(joint['action']['placement'],alt['placement'])
        self.assertEqual(joint['dagv2']['selected_cost_ms'],800)
    def test_budget_responses_recomputed_for_each_route(self):
        s=snapshot();cfg=copy.deepcopy(CFG);cfg.update(base_cap=4096,replicas=2)
        ref=S.reference(s,cfg);alt=copy.deepcopy(ref);alt['placement']={k:1 for k in ref['placement']}
        high0,ev0=S.budget_response(s,ref,MODEL,cfg);high1,ev1=S.budget_response(s,alt,MODEL,cfg)
        self.assertEqual(high0['caps'],[1024,4096]);self.assertEqual(high1['caps'],[4096,4096])
    def test_equal_action_cells_reuse_score_not_claim_distinct(self):
        s=snapshot();s['nodes']['d']['state']='done';cfg=copy.deepcopy(CFG);cfg.update(base_cap=4096)
        ref=S.reference(s,cfg)
        with patch.object(S,'proposed_routes',return_value=([ref],{})):
            a=S.choose(s,MODEL,cfg,'DAG-Batch-v2',time.monotonic()+2)
        self.assertEqual(a['dagv2']['distinct_complete_pairs'],0)
        self.assertEqual(a['complete_distinct_evaluations'],1)
    def test_no_finished_workflow_counted_twice(self):
        s=snapshot();cfg=copy.deepcopy(CFG);cfg.update(base_cap=4096)
        a=S.choose(s,MODEL,cfg,'DAG-Batch-v2',time.monotonic()+2)
        for r in a['dagv2'].get('pairs',[]):
            if r['complete']:
                self.assertAlmostEqual(sum(r['workflow_saving_ms'].values()),r['fixed_cost_ms']-r['adaptive_cost_ms'])
