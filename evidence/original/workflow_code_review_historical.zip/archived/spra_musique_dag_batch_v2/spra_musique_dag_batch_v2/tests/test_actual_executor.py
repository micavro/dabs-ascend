"""API-shaped CPU fake engine + actual inherited client/hook. NOT native GPU tests."""
from __future__ import annotations
import asyncio,contextlib,copy,importlib.util,io,json,os,sys,tempfile,unittest,uuid
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,ProcessPoolExecutor
from unittest.mock import patch
import multiprocessing,time
from helpers import fixture,FakeTokenizer,CFG,MODEL,PRIORS,SOURCE
from semantic19.dataset import compile_record
from typed19.workflow import compile_packets,instantiate
from typed19.answers import SCHEMA
from joint18v2.common import load

from dagbatch24.design import METHODS
from dagbatch24.runner import inactive_offsets,inactive_proof,worker_ready
from dagbatch24.evidence import validate

class ActualExecutorTests(unittest.IsolatedAsyncioTestCase):
    async def scenario(self,method,R):
        import httpx
        from fake_native import modules,FakeGroup,hashes
        from joint18v2.cache import NativeCacheObserver
        import dagbatch24.event_client as C
        with tempfile.TemporaryDirectory() as td:
            path=Path(td);mods,sm,Engine=modules();scheds=[];engines=[]
            with patch.dict(sys.modules,mods),patch.dict(os.environ,{'SPRA_E1_ROOT':td,'POD_NAME':'spra-vllm-0','NVIDIA_VISIBLE_DEVICES':'MOCK'}):
                spec=importlib.util.spec_from_file_location('hook_'+uuid.uuid4().hex,SOURCE/'runtime/joint18v2_hook.py')
                hook=importlib.util.module_from_spec(spec);spec.loader.exec_module(hook)
                hook.capabilities=lambda:{'scheduler_source_sha256':'mock','imported_version':'0.6.3','distribution_version':'0.6.3'}
                hook.NativeCacheObserver=lambda mgr,b:NativeCacheObserver(mgr,b,hashes)
                with contextlib.redirect_stdout(io.StringIO()):
                    hook.install()
                    for r in range(4):
                        os.environ['POD_NAME']=f'spra-vllm-{r}';os.environ['NVIDIA_VISIBLE_DEVICES']=f'MOCK-NOT-GPU-{r}'
                        s=sm.Scheduler();scheds.append(s);engines.append(Engine(s));s._v2_writer.drain()
                initial=[load(path/'joint18v2'/f'spra-vllm-{r}.status.json') for r in range(R)]
                cfg=copy.deepcopy(CFG);cfg.update(replicas=R,workflow_count=2,epoch_s=.04,ready_coalesce_s=.001,
                    planning_soft_limit_s=.025,commit_reserve_s=.003,max_output_tokens=8,initial_output_estimate=2,
                    snapshot_max_age_s=2.,cache_evidence_max_age_s=2.,condition_wall_s=15,initial_expected_apply_delay_ms=2.)
                cell={'method':method,**METHODS[method],'replicas':R,'rate':4.,'N':2}
                cfg['batching20_policy']='mixed_1024' if method=='DAG-Batch-v1' else 'fixed_4096';cfg['batching20_output_priors']=PRIORS
                cfg.update(dagv2_public_method=method,dagv2_min_decision_gap_s=.001,dagv2_per_candidate_slice_s=.012)
                cfg['base_cap']=int(cell['policy'].split('_')[1]) if cell['policy'].startswith('fixed_') else 4096
                ps=[]
                for i in range(2):
                    raw=fixture();raw['id']=f'SYNTHETIC_LIVE_{i}';raw['paragraphs'][0]['title']=f'City{i}';p,_=compile_record(raw);ps.append(p)
                tok=FakeTokenizer();pack,_=await compile_packets(ps,tok,cfg);ns,mat,proof=await instantiate(pack,tok,cfg,1)
                for n in ns.values():n['arrival_offset']=0.
                proof['arrivals']=[0.,0.]
                sent=[]
                class Stream(httpx.AsyncByteStream):
                    def __init__(self,g):self.g=g
                    async def __aiter__(self):
                        while self.g.done<1:await asyncio.sleep(.001)
                        yield ('data: '+json.dumps({'id':self.g.request_id,'choices':[{'text':'{"answer":'}]})+'\n\n').encode()
                        while self.g.done<2:await asyncio.sleep(.001)
                        yield ('data: '+json.dumps({'id':self.g.request_id,'choices':[{'text':'"Paris"}','finish_reason':'stop'}]})+'\n\n').encode()
                        yield ('data: '+json.dumps({'choices':[],'usage':{'prompt_tokens':len(self.g.tokens),'completion_tokens':2}})+'\n\n').encode()
                        yield b'data: [DONE]\n\n'
                async def handler(req):
                    r=req.url.port-8000;self.assertLess(r,R)
                    payload=json.loads(req.content);sent.append((r,payload));self.assertEqual(payload['guided_json'],SCHEMA)
                    self.assertNotIn('min_tokens',payload);self.assertNotIn('ignore_eos',payload)
                    g=FakeGroup('r'+uuid.uuid4().hex,payload['prompt'],2);scheds[r].add_seq_group(g)
                    return httpx.Response(200,stream=Stream(g))
                alive=True
                async def pump():
                    while alive:
                        for s,e in zip(scheds,engines):
                            if s.running or s.waiting:await e.step_async()
                        await asyncio.sleep(.003)
                task=asyncio.create_task(pump());off=inactive_offsets(path,R)
                try:
                    with ThreadPoolExecutor(1) as executor:
                        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
                            with contextlib.redirect_stdout(io.StringIO()):
                                s,e=await C.execute(client,path,initial,cfg,ns,path/'RAW',cell['scheduler'],MODEL,
                                    executor=executor if cell['scheduler']!='A' else None,materializer=mat)
                    self.assertEqual(s['request_correlation'],'6/6');self.assertEqual(s['native_next_batch_matches'],s['native_next_batch_checked'])
                    self.assertTrue(s['control_time_match']);self.assertEqual(len(sent),6)
                    self.assertTrue(inactive_proof(path,off)['pass']);self.assertTrue(all(n['answer_contract']['schema_ok'] for n in ns.values()))
                    if method=='RR':self.assertEqual([r for r,p in sent],[i%R for i in range(6)])
                    self.assertNotIn('GOLD_SECRET',json.dumps([p for _,p in sent]));self.assertIn('(Paris)',ns['w0000/step3']['resolved_question'])
                    v=validate(path/'RAW',cell,cfg,pack,proof,MODEL);self.assertTrue(v['accepted'])
                    if method=='DAG-Batch-v1':
                        plans=[json.loads(l) for l in (path/'RAW/plans.jsonl').read_text().splitlines()]
                        self.assertTrue(any(p.get('batching20',{}).get('D0_schedule_unchanged') for p in plans))
                finally:
                    alive=False
                    try:await task
                    finally:
                        for s in scheds:s._v2_stop.set()
                        await asyncio.sleep(.05)
                        for s in scheds:s._v2_writer.close()

for m in METHODS:
    for R in (1,2,3,4):
        async def test(self,m=m,R=R):await self.scenario(m,R)
        setattr(ActualExecutorTests,'test_'+m.replace('-','_')+'_R'+str(R),test)

class SpawnTests(unittest.TestCase):
    def test_real_spawn_new_selector_entry(self):
        import dagbatch24.event_client as C
        from dagbatch24.selector import process_plan
        cfg=copy.deepcopy(CFG);cfg['base_cap']=4096;cfg['dagv2_public_method']='DAG-Batch-v2';cfg['planning_soft_limit_s']=.1
        # Empty arrived set is a valid no-action snapshot; no fabricated future work.
        s={'replicas':2,'nodes':{},'ready':[],'pressure':[0,0],'reserved_blocks':[0,0],
           'capacity_blocks':[4096,4096],'now':time.monotonic(),'state_ages_s':[0,0],
           'cache_unknown_count':0,'cache_evidence':[],'current_caps':[4096,4096]}
        with ProcessPoolExecutor(1,mp_context=multiprocessing.get_context('spawn')) as pool:
            pid=pool.submit(worker_ready).result(timeout=15);self.assertNotEqual(pid,os.getpid())
            ans=pool.submit(process_plan,s,MODEL,cfg,'D',time.monotonic()+1.).result(timeout=15)
            self.assertEqual(ans['dagv2']['method'],'DAG-Batch-v2');self.assertEqual(ans['action']['caps'],[4096,4096])
