# 来源与变更边界

本轮直接读取上传的spra_musique_b1_case_v1.zip及其依赖源码；优化方向来自先前保存的SOURCE_REVIEW.md。未访问用户GPU39磁盘或连接任何远程控制服务。

本地event_client复制自spra_stage19_musique_joint_v1/joint18v2/client.py，来源SHA256记录在analysis/CLIENT_PROVENANCE.json。完整差异在CLIENT_DIFF.patch。仅新增客户端调度时钟、提交观测及诊断；后端hook不修改。

公共依赖以dependency_identity.json及原case23/batching20链校验，不使用新版vLLM替换现场0.6.3。用户已有回归测试输出不能代替本包的新测试，新测试同样不代替GPU实机。

外部核对只涉及Python3.11事件/任务API：
- https://docs.python.org/3.11/library/asyncio-sync.html#event
- https://docs.python.org/3.11/library/asyncio-task.html#asyncio.wait_for

这些文档支持Event.wait/set与带超时等待的语义，不证明本算法实机效果。其余方法选择与实验协议是本次实现，不冒称原有论文结论或全局最优。
