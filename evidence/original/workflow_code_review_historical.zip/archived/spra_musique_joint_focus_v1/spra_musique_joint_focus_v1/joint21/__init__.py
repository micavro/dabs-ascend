"""MuSiQue: preserved D0/Mixed composition plus one bounded joint feedback."""
REVISION = 'musique-joint-focus-1'
CHECKER_REVISION = 'native-tail-capacity-check-1'
