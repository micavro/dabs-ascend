from __future__ import annotations
import hashlib
import statistics
import math


def tuning_design(p):
    # Counterbalance the shared caps across A/D, no result-dependent order.
    caps=[4096,1024,256,2048,512];out=[]
    for i,cap in enumerate(caps):
        methods=['A','D'] if i%2==0 else ['D','A']
        for m in methods:
            out.append({'label':f'FIXED_{len(out)+1:02d}_{m}_{cap}', 'role':m+'-F'+str(cap),
                        'mode':m,'fixed_cap':cap,'block':0,'position':len(out)+1,
                        'seed':p['fixed_seed'],'rate':p['primary_rate'],'N':p['development_questions']})
    return out


def select_fixed(rows,p):
    design=tuning_design(p)
    if len(rows)!=len(design) or {r['label'] for r in rows}!={d['label'] for d in design}:
        raise ValueError('fixed selection requires every preregistered condition')
    for row in rows:
        if not row.get('accepted'): raise ValueError('unaccepted condition cannot select fixed reference')
    if len({r.get('external_work_sha256') for r in rows}) != 1 or not rows[0].get('external_work_sha256'):
        raise ValueError('fixed scan external inputs differ or have no receipt')
    if any(not isinstance(r['summary'].get('mean_jct_ms'), (int,float)) or not math.isfinite(r['summary']['mean_jct_ms']) or r['summary']['mean_jct_ms'] <= 0 for r in rows):
        raise ValueError('invalid fixed-scan JCT')
    result={}
    for mode in ('A','D'):
        rs=[r for r in rows if r['mode']==mode]
        best=min(rs,key=lambda r:(r['summary']['mean_jct_ms'],r['fixed_cap']!=4096,-r['fixed_cap']))
        result[mode]=best['fixed_cap']
    return {'caps':result,'quality_or_TPOT_used':False,'dataset_split':'profile_train32',
            'measurement_N':p['development_questions'],'applied_main_N':p['main_questions'],
            'scope':'best of measured development caps; not oracle for N64',
            'table':[{'method':r['mode'],'cap':r['fixed_cap'],'mean_jct_ms':r['summary']['mean_jct_ms']} for r in rows]}


def main_design(p,selection):
    roles=[('A-Tuned','A',selection['caps']['A']),('D0-F4096','D',4096),
           ('C-D0-Mixed1024','C',4096),('J-Light','J',4096)]
    if selection['caps']['A']!=4096: roles.append(('A-F4096','A',4096))
    if selection['caps']['D']!=4096: roles.append(('D0-BestFixed','D',selection['caps']['D']))
    orders=[[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1]];out=[]
    for block in range(1,p['main_blocks']+1):
        order=orders[(block-1)%4].copy()
        for extra in range(4,len(roles)):
            order.insert((block+extra)% (len(order)+1),extra)
        for position,i in enumerate(order,1):
            role,mode,cap=roles[i]
            aliases=[role]
            if role=='A-Tuned' and cap==4096:aliases+=['A-F4096']
            if role=='D0-F4096' and selection['caps']['D']==4096:aliases+=['D0-BestFixed']
            out.append({'label':f'B{block}_{position}_{role}','role':role,'aliases':aliases,
                        'mode':mode,'fixed_cap':cap,'block':block,'position':position,
                        'seed':p['main_seed_base']+block,'rate':p['primary_rate'],'N':p['main_questions']})
    return out


def packet_order(packets,seed):
    return sorted(packets,key=lambda p:hashlib.sha256((str(seed)+'|'+p['id']).encode()).hexdigest())


def report(rows,selection,p):
    design=main_design(p,selection)
    if len(rows)!=len(design) or {r['label'] for r in rows}!={d['label'] for d in design}:
        raise ValueError('no success report before whole main batch completes')
    paired=[]
    fields=['mean_jct_ms','p95_jct_ms','mean_request_ttft_ms','p95_request_ttft_ms',
            'mean_node_time_to_first_content_ms','mean_client_tpot_proxy_ms','p95_client_tpot_proxy_ms']
    for b in range(1,p['main_blocks']+1):
        cells=[r for r in rows if r['block']==b]
        if any(not r.get('accepted') for r in cells):raise ValueError('unaccepted condition')
        if len({r['external_work_sha256'] for r in cells})!=1:raise ValueError('external work differs within block')
        lookup={role:r['summary'] for r in cells for role in r.get('aliases',[r['role']])}
        compares={'total_J_vs_A':('J-Light','A-Tuned'),'total_C_vs_A':('C-D0-Mixed1024','A-Tuned'),
                  'scheduling_D_vs_A':('D0-F4096','A-Tuned'),'batching_C_vs_D0':('C-D0-Mixed1024','D0-F4096'),
                  'batching_C_vs_best_fixed_D0':('C-D0-Mixed1024','D0-BestFixed'),
                  'coordination_J_vs_C':('J-Light','C-D0-Mixed1024'),
                  'total_J_vs_A_F4096':('J-Light','A-F4096'),
                  'total_C_vs_A_F4096':('C-D0-Mixed1024','A-F4096'),
                  'scheduling_D_vs_A_F4096':('D0-F4096','A-F4096'),
                  'joint_J_vs_best_fixed_D0':('J-Light','D0-BestFixed')}
        values={}
        for label,(cand,ref) in compares.items():
            a,c=lookup[ref],lookup[cand]
            gains={f:100*(1-c[f]/a[f]) if isinstance(c.get(f),(int,float)) and isinstance(a.get(f),(int,float)) and a[f]>0 else None for f in fields}
            gains.update(workflow_throughput_pct=100*(c['cohort_workflows_s']/a['cohort_workflows_s']-1),
                         token_throughput_pct=100*(c['cohort_tokens_s']/a['cohort_tokens_s']-1))
            values[label]=gains
        paired.append({'block':b,'gains':values,'JCT_ms':{k:v['mean_jct_ms'] for k,v in lookup.items()}})
    avg={k:statistics.mean(b['gains'][k]['mean_jct_ms'] for b in paired) for k in paired[0]['gains']}
    return {'schema':'musique-joint-focus-result-1','paired':paired,'mean_paired_JCT_gain_pct':avg,
            'primary_rate':p['primary_rate'],'N':p['main_questions'],'blocks':p['main_blocks'],
            'point_estimate_J_above_10pct':avg['total_J_vs_A']>10,
            'point_estimate_C_above_10pct':avg['total_C_vs_A']>10,
            'batch_increment_positive':avg['batching_C_vs_best_fixed_D0']>0,
            'coordination_increment_positive':avg['coordination_J_vs_C']>0,
            'formal_10pct_guarantee':False,'question_set_unseen':False,
            'no_posthoc_latency_subtraction':True,'all_positive_and_negative_conditions_retained':True,
            'distinct_roles_are_not_extra_samples':True,
            'old_partial_confirmation_completed_by_this_batch':False}
