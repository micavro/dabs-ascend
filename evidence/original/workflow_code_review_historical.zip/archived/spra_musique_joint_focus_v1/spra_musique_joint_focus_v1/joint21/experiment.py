"""Read-only old-record revalidation -> small fixed scan -> paired Joint runs.

No backend patch, no restart, no new dataset, no online policy fitting. This
runner creates independent outputs, preserves old failures and supports explicit
resumption with attempt provenance. The old 36-condition protocol is NOT silently
replaced or completed by this focused experiment.
"""
from __future__ import annotations
import argparse
import asyncio
import copy
import csv
from collections import Counter, defaultdict
import fcntl
import json
import multiprocessing
import os
import statistics
import time
import uuid
import zipfile
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from .dependency import ROOT, BATCH, activate, sha, own_identity
activate()
from . import REVISION, CHECKER_REVISION
from .audit import revalidate_suite, condition_verdict, jsonl
from .binding import bindings
from .protocol import tuning_design, main_design, select_fixed, packet_order, report
from batching20 import experiment as old
from batching20.policy import scheduling_view, scheduling_hash
from batching20.dependency import verify as verify_dependencies
from joint18v2.common import atomic, load, digest
from joint18v2.client import gate, execute, wait_drained
from typed19.workflow import ServerTokenizer, compile_packets, instantiate
from typed19.quality import evaluate as evaluate_quality
from semantic19.dataset import load_public

HOOK = old.HOOK
DEFAULT_PRIOR = BATCH / 'runs/D0_BATCH_CONFIRM_20261010T123919Z_df416da6'

def stamp(prefix): return prefix+'_'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'_'+uuid.uuid4().hex[:8]
def config(): return load(ROOT/'configs/protocol.json')
def compact(s): return old.compact(s)
def worker_ready(): return os.getpid()

def save_zip(directory,dest,extra=()):
    directory=Path(directory);dest=Path(dest);dest.parent.mkdir(parents=True,exist_ok=True)
    manifest={}
    with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(directory.rglob('*')):
            if f.is_file() and not f.is_symlink() and f!=dest:
                arc=str(f.relative_to(directory));z.write(f,arc);manifest[arc]=sha(f)
        for f,arc in extra:
            z.write(f,arc);manifest[arc]=sha(f)
        z.writestr('ARCHIVE_SHA256SUMS',''.join(h+'  '+n+'\n' for n,h in sorted(manifest.items())))
    dest.with_suffix('.zip.sha256').write_text(sha(dest)+'  '+dest.name+'\n')
    return dest


def prepare(prior_suite=DEFAULT_PRIOR):
    frozen,mf,_,_=old.load_frozen()
    dev,selection=old.read_selection(frozen)
    if selection['adaptive_policy']!='mixed_1024':
        raise ValueError('this declared protocol requires the recorded Mixed1024 winner; no automatic strategy change')
    out=ROOT/'prepared'/stamp('FOCUS');out.mkdir(parents=True)
    print('PREPARE_DIRECTORY='+str(out),flush=True)
    review=revalidate_suite(prior_suite)
    atomic(out/'prior_revalidation.json',review)
    print('PRIOR_REVALIDATION='+json.dumps({k:v for k,v in review.items() if k!='conditions'}),flush=True)
    for v in review['conditions']:
        print('PRIOR_CONDITION_VERDICT='+json.dumps({k:v0 for k,v0 in v.items() if k not in ('corrected_tail_rows','unresolved_rows','source_hashes')}),flush=True)
    if not review['all_saved_conditions_revalidated']:
        bundle=save_zip(out,ROOT/'reports'/(out.name+'_blocked.zip'))
        print('UNRESOLVED_BATCH_EVIDENCE_BUNDLE='+str(bundle),flush=True)
        raise RuntimeError('old discrepancy remains unresolved; new GPU runs blocked. No tolerance, no baseline auto-acceptance.')
    for name in ('model.json','priors.json'):
        (out/name).write_bytes((frozen/name).read_bytes())
    atomic(out/'original_D0_manifest.json',mf)
    atomic(out/'old_selection.json',selection)
    atomic(out/'protocol.json',config())
    receipt={'revision':REVISION,'checker_revision':CHECKER_REVISION,
             'source_dependencies':verify_dependencies(),'adapter_identity':own_identity(),
             'original_freeze':str(frozen.resolve()),'original_freeze_sha256':sha(frozen/'manifest.json'),
             'dataset':mf['dataset'],'dataset_manifest_sha256':mf['dataset_manifest_sha256'],
             'dataset_files':mf['dataset_files'],'D0_configuration':mf['D0_configuration'],
             'model_refitted':False,'source_D0_modified':False,'source_Mixed1024_modified':False,
             'backend_modified':False,'prior_suite_completed':False,
             'files':{n:sha(out/n) for n in ('model.json','priors.json','original_D0_manifest.json','prior_revalidation.json','old_selection.json','protocol.json')}}
    atomic(out/'manifest.json',receipt)
    atomic(ROOT/'prepared/latest.json',{'directory':str(out.resolve())})
    print('JOINT_FOCUS_FROZEN='+json.dumps({'directory':str(out),'new_GPU_requests':0,
         'primary_rate':4,'fixed_development_conditions':10,'main_core_conditions':16,
         'main_max_conditions_with_stronger_fixed_refs':24,'old_results_not_pooled':True}),flush=True)
    return out


def load_prepared():
    ptr=ROOT/'prepared/latest.json'
    if not ptr.is_file():raise FileNotFoundError('run_prepare.sh first; only saved records are read')
    out=Path(load(ptr)['directory']);mf=load(out/'manifest.json')
    if mf['source_dependencies']!=verify_dependencies() or mf['adapter_identity']!=own_identity():
        raise ValueError('code changed after freezing; cannot reuse protocol')
    for rel,h in mf['files'].items():
        if sha(out/rel)!=h:raise ValueError('frozen artifact changed: '+rel)
    dataset=Path(mf['dataset'])
    if sha(dataset/'manifest.json')!=mf['dataset_manifest_sha256']:raise ValueError('dataset manifest changed')
    for rel,h in mf['dataset_files'].items():
        if sha(dataset/rel)!=h:raise ValueError('dataset changed: '+rel)
    if load(out/'protocol.json')!=config():raise ValueError('protocol changed')
    return out,mf,load(out/'model.json'),load(out/'priors.json')


def latest_completed(mode,prepared):
    ptr=ROOT/'records'/(mode+'_latest.json')
    if not ptr.is_file():return None
    r=load(ptr);d=Path(r['directory'])
    if r['prepared_sha256']!=sha(prepared/'manifest.json'):raise ValueError('completed pointer belongs to another freeze')
    if load(d/'suite_status.json')['status']!='complete':raise ValueError('invalid complete pointer')
    for row in load(d/'index.json'):verify_acceptance(Path(row['folder']))
    return d


def verify_acceptance(folder):
    r=load(folder/'accepted.json')
    if not r.get('measurement_accepted'):raise ValueError('nonaccepted receipt')
    for rel,h in r['files'].items():
        if sha(folder/rel)!=h:raise ValueError('accepted record changed: '+str(folder/rel))
    return r


def feedback_evidence(folder,mode):
    plans=list(jsonl(Path(folder)/'plans.jsonl'));receipts=[]
    d0_receipts=0; opportunities=0
    from joint18v2.batchcheck import binding_evidence
    bycap=defaultdict(lambda:{'iterations':0,'with_prefill':0,'mixed':0,'decode_only':0,'strict_binding_candidates':0,'logical_prefill_tokens':0})
    for e in jsonl(Path(folder)/'backend.jsonl'):
        if e.get('event')!='iteration' or not e.get('scheduled'):continue
        t=bycap[str(e.get('prefill_cap'))];t['iterations']+=1
        t['with_prefill']+=int(e['prefill_logical_tokens']>0)
        t['mixed']+=int(e['prefill_logical_tokens']>0 and e['decode_tokens']>0)
        t['decode_only']+=int(e['prefill_logical_tokens']==0 and e['decode_tokens']>0)
        t['strict_binding_candidates']+=int(binding_evidence(e)['binding_candidate'])
        t['logical_prefill_tokens']+=e['prefill_logical_tokens']
    for p in plans:
        j=p.get('joint21');b=p.get('batching20');native_fallback=p.get('commit_fallback')
        if b:
            d0_receipts+=1
            opportunities+=sum(x.get('reason')=='mixed_cold_prefill_test' for x in b.get('evidence',{}).get('replicas',[]))
        if j:
            before=j['D0_action'];composition=j['composition_action'];a=p['action']
            if before['admit']!=composition['admit'] or before['order']!=composition['order'] or before['placement']!=composition['placement']:
                raise RuntimeError('Mixed changed D0 scheduling before feedback')
            if not native_fallback and (before['admit']!=a['admit'] or before['order']!=a['order']):
                raise RuntimeError('joint feedback unexpectedly changed D0 admission/order')
            receipts.append({'decision_index':p['decision_index'],'complete_packet':j['four_cells_complete'],
                'different_from_C':bool(j['changed_from_composition'] and not native_fallback),
                'route_feedback_selected':j.get('route_feedback_selected',False),
                'route_feedback_committed':bool(j.get('route_feedback_selected') and not native_fallback),
                'extra_wall_ms':j['additional_wall_ms'],'reason':j['reason'],
                'commit_fallback':native_fallback,'all_scores':j.get('scores',[])})
        elif b:
            if not b['D0_schedule_unchanged'] or b['D0_schedule_hash']!=scheduling_hash(b['D0_action']):
                raise RuntimeError('D0 scheduling integrity failed')
            if not native_fallback and scheduling_view(b['D0_action'])!=scheduling_view(p['action']):
                raise RuntimeError('non-Joint policy changed D0 scheduling')
    result={'revision':REVISION,'mode':mode,'feedback_calls':len(receipts),
            'D0_worker_receipts':d0_receipts,'Mixed1024_replica_opportunities':opportunities,'per_cap_activity':dict(bycap),
            'complete_feedback_packets':sum(x['complete_packet'] for x in receipts),
            'committed_differences_from_C':sum(x['different_from_C'] for x in receipts),
            'committed_route_feedback':sum(x['route_feedback_committed'] for x in receipts),
            'mean_feedback_ms':statistics.mean(x['extra_wall_ms'] for x in receipts) if receipts else 0.,
            'D0_rules_unchanged':True,'D0_admission_order_preserved_before_native_guard':True,
            'source_Mixed_rule_unchanged':True,'real_nonregression_guaranteed':False,'receipts':receipts}
    atomic(Path(folder)/'feedback_evidence.json',result)
    return {k:v for k,v in result.items() if k!='receipts'}


def finalize(folder,cell,dataset):
    folder=Path(folder)
    if (folder/'accepted.json').is_file():
        verify_acceptance(folder);return load(folder/'row.json')
    verdict=condition_verdict(folder)
    atomic(folder/'independent_validation.json',verdict)
    if not verdict['accepted']:
        atomic(folder/'rejected.json',{'measurement_accepted':False,'errors':verdict.get('errors'),
               'classification':verdict.get('classification'),'no_performance_value_used_for_acceptance':True})
        raise RuntimeError('measurement not accepted; see '+str(folder/'independent_validation.json'))
    summary=load(folder/'summary.json');nodes=load(folder/'nodes.json')
    if cell['mode'] in ('A','D'):
        for e in jsonl(folder/'backend.jsonl'):
            if e.get('event')=='iteration' and e.get('scheduled') and e.get('prefill_cap')!=cell['fixed_cap']:
                raise RuntimeError('declared fixed cap not applied: '+str(folder))
    if not (folder/'client_summary.json').exists():(folder/'client_summary.json').write_bytes((folder/'summary.json').read_bytes())
    q=evaluate_quality(nodes,dataset,summary['cohort_duration_s'])
    atomic(folder/'quality.json',q)
    summary.update(q);summary.update(feedback_evidence(folder,cell['mode']))
    summary.update(measurement_accepted=True,independent_batch_check_revision=CHECKER_REVISION,
                   independent_batch_checked=verdict['iterations'],independent_batch_matched=verdict['matches'],
                   criterion='all required checks before final acceptance; quality and TPOT are outcomes',
                   output_work_forced_equal=False)
    atomic(folder/'summary.json',summary)
    proof=load(folder/'semantic_proof.json');external=load(folder/'cell.json')['external_work_sha256']
    row={**cell,'folder':str(folder.resolve()),'accepted':True,'external_work_sha256':external,
         'summary':compact(summary),'source_question_ids':proof['ids']}
    atomic(folder/'row.json',row)
    names=['nodes.json','backend.jsonl','summary.json','manifest.json','trace_capture.json','semantic_proof.json',
           'cell.json','row.json','independent_validation.json','feedback_evidence.json','quality.json']
    atomic(folder/'accepted.json',{'measurement_accepted':True,'files':{n:sha(folder/n) for n in names},
           'source_conditions_not_overwritten':True,'quality_is_not_success_gate':True})
    return row


def rows_csv(out,rows):
    fields=['label','role','mode','block','position','N','rate','fixed_cap','accepted',
            'mean_jct_ms','p95_jct_ms','mean_request_ttft_ms','mean_client_tpot_proxy_ms','cohort_workflows_s','cohort_tokens_s']
    with (out/'conditions.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in rows:w.writerow({k:r.get(k,r['summary'].get(k)) for k in fields})


async def live(mode,runtime,resume=None,retry_incomplete=False):
    import httpx
    prepared,mf,model,priors=load_prepared();p=config();dataset=Path(mf['dataset']);runtime=Path(runtime)
    if mode=='gate':
        async with httpx.AsyncClient(timeout=30,trust_env=False) as client:
            ss=await gate(client,runtime,4)
            if any(s.get('hook_source_sha256')!=HOOK for s in ss):raise ValueError('different hook; no automatic deployment')
        print('GATE_READY=True MODEL_GENERATION_REQUESTS=0 BACKEND_CHANGED=False');return
    if mode not in ('fixed','main'):raise ValueError(mode)
    complete=latest_completed(mode,prepared)
    if complete is not None and resume is None:
        print('SUITE_ALREADY_COMPLETE='+str(complete)+' NEW_GPU_REQUESTS=0');return
    selection=None
    if mode=='main':
        dev=latest_completed('fixed',prepared)
        if dev is None:raise FileNotFoundError('complete run_fixed.sh; no holdout-driven fixed selection')
        selection=load(dev/'fixed_selection.json')
        if selection!=select_fixed(load(dev/'index.json'),p):raise ValueError('fixed selection changed')
    design=tuning_design(p) if mode=='fixed' else main_design(p,selection)
    records,dm=load_public(dataset,'profile' if mode=='fixed' else 'pilot')
    expected=p['development_questions'] if mode=='fixed' else p['main_questions']
    if len(records)!=expected:raise ValueError('expected existing '+str(expected)+' source questions')
    cfg=copy.deepcopy(mf['D0_configuration']);cfg.update(arrival_rate=p['primary_rate'],arrival_shape=p['arrival_shape'],base_cap=4096)
    code_receipt={'prepared_sha256':sha(prepared/'manifest.json'),'adapter_identity':own_identity(),
                  'source_dependencies':verify_dependencies(),'mode':mode,'design':design,'protocol':p}
    if resume is not None:
        out=Path(resume).resolve()
        if load(out/'frozen_protocol.json')!=code_receipt:raise ValueError('resume protocol/code mismatch')
    else:
        out=ROOT/'runs'/stamp('JOINT_'+mode.upper());out.mkdir(parents=True)
        atomic(out/'frozen_protocol.json',code_receipt);atomic(out/'index.json',[])
        if selection:atomic(out/'fixed_selection.json',selection)
    print('RESULT='+str(out),flush=True)
    rows=[];pending=[]
    # Reuse accepted attempts exactly once. Completed raw attempts can be finalized
    # without re-generating; genuinely interrupted attempts require explicit opt-in.
    for cell in design:
        attempts=sorted(out.glob(cell['label']+'__attempt*'))
        good=[]
        for folder in attempts:
            if (folder/'accepted.json').is_file():
                verify_acceptance(folder);good.append(load(folder/'row.json'))
        if len(good)>1:raise ValueError('duplicate accepted attempts for '+cell['label'])
        if good:rows.append(good[0]);continue
        if attempts:
            try:
                row=finalize(attempts[-1],cell,dataset);rows.append(row)
                print('SAVED_COMPLETED_CONDITION_RECOVERED='+cell['label'],flush=True);continue
            except (OSError,ValueError,KeyError,RuntimeError) as exc:
                if not retry_incomplete:
                    raise RuntimeError('saved attempt not accepted; no automatic retry: '+str(attempts[-1])+'; '+str(exc)) from exc
        pending.append((cell,len(attempts)+1))
    atomic(out/'index.json',rows)
    if not runtime.is_dir():raise FileNotFoundError('existing runtime directory required')
    if not pending:
        finish_suite(out,mode,rows,p,selection,prepared);return out
    segment=stamp('SEGMENT');executor=None
    with (runtime/'experiment.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        with bindings():
            async with httpx.AsyncClient(timeout=httpx.Timeout(180,connect=5,pool=10),trust_env=False,
                limits=httpx.Limits(max_connections=192,max_keepalive_connections=64,keepalive_expiry=2)) as client:
                initial=await gate(client,runtime,4)
                if any(s.get('hook_source_sha256')!=HOOK for s in initial):raise ValueError('hook mismatch')
                atomic(out/'segments'/(segment+'.json'),{'initial':initial,'resumed':resume is not None,
                        'pending_labels':[c['label'] for c,_ in pending],'warmup_in_this_segment':True})
                atomic(out/'suite_status.json',{'status':'running','accepted_conditions':len(rows),'expected':len(design)})
                try:
                    tok=ServerTokenizer(client,cfg['model'])
                    packets,info=await compile_packets(records,tok,cfg)
                    atomic(out/'segments'/(segment+'_packet_preparation.json'),info)
                    executor=ProcessPoolExecutor(1,mp_context=multiprocessing.get_context('spawn'))
                    await asyncio.get_running_loop().run_in_executor(executor,worker_ready)
                    await old.warmup(client,runtime,initial,cfg,out/'segments'/segment,tok)
                    for cell,attempt in pending:
                        load_prepared()
                        cc=copy.deepcopy(cfg);cc.update(workflow_count=cell['N'],base_cap=cell['fixed_cap'],
                              joint21_fixed_cap=cell['fixed_cap'],joint21_method=cell['mode'],
                              joint21_feedback_ms=p['feedback_budget_ms'],joint21_output_priors=priors)
                        ps=packet_order(packets,cell['seed'])
                        ns,materialize,proof=await instantiate(ps,tok,cc,cell['seed'],priors)
                        external=digest({'ids':[x['id'] for x in ps],'graphs':[x['graph'] for x in ps],
                           'evidence_hashes':[x['evidence_hash'] for x in ps],'arrival_offsets':proof['arrivals'],
                           'typed_protocol':True,'natural_EOS_max96':True})
                        folder=out/(cell['label']+f'__attempt{attempt:02d}')
                        # Execute requires a not-yet-existing condition directory. Stage only
                        # the input proof alongside it, then copy inside even on exceptions.
                        plan_record={**cell,'external_work_sha256':external,'segment':segment,'attempt':attempt}
                        atomic(out/'planned_inputs'/(folder.name+'.json'),{'cell':plan_record,'proof':proof})
                        print('JOINT_FOCUS_CONDITION_START='+json.dumps(plan_record),flush=True)
                        try:
                            await execute(client,runtime,initial,cc,ns,folder,'A' if cell['mode']=='A' else 'D',model,
                                          executor=executor if cell['mode']!='A' else None,materializer=materialize)
                        finally:
                            if folder.is_dir():
                                atomic(folder/'cell.json',plan_record);atomic(folder/'semantic_proof.json',proof)
                        row=finalize(folder,cell,dataset);rows.append(row)
                        atomic(out/'index.json',rows);rows_csv(out,rows)
                        print('JOINT_FOCUS_CONDITION_ACCEPTED='+json.dumps({**cell,**compact(row['summary'])},ensure_ascii=False),flush=True)
                except BaseException as exc:
                    atomic(out/'suite_status.json',{'status':'failed','accepted_conditions':len(rows),'error':repr(exc),
                           'automatic_retry':False,'resume_command':'--resume '+str(out)})
                    raise
                finally:
                    if executor:executor.shutdown(wait=True,cancel_futures=True)
                    atomic(runtime/'joint18v2/control.json',{'enabled':False})
                    try:drained=await wait_drained(runtime,initial)
                    except Exception:drained=False
                    unchanged=verify_dependencies()==mf['source_dependencies'] and own_identity()==mf['adapter_identity']
                    cleanup={'backend_drained':drained,'source_files_unchanged':unchanged,'backend_changed':False,
                             'old_runs_modified':False,'segment':segment}
                    atomic(out/'cleanup.json',cleanup);print('CLEANUP='+json.dumps(cleanup),flush=True)
                    if not drained or not unchanged:raise RuntimeError('cleanup failed; do not start another run')
    finish_suite(out,mode,rows,p,selection,prepared)
    return out


def finish_suite(out,mode,rows,p,selection,prepared):
    design=tuning_design(p) if mode=='fixed' else main_design(p,selection)
    if len(rows)!=len(design):raise ValueError('suite is incomplete')
    if mode=='fixed':
        chosen=select_fixed(rows,p);atomic(out/'fixed_selection.json',chosen)
        print('FOCUS_FIXED_REFERENCE_FROZEN='+json.dumps(chosen),flush=True)
    else:
        result=report(rows,selection,p);atomic(out/'joint_result.json',result)
        print('MUSIQUE_JOINT_FOCUS_RESULT='+json.dumps(result),flush=True)
    rows_csv(out,rows)
    atomic(out/'suite_status.json',{'status':'complete','accepted_conditions':len(rows),
           'all_positive_and_negative_retained':True,'formal_gain_guaranteed':False})
    atomic(ROOT/'records'/(mode+'_latest.json'),{'directory':str(out.resolve()),'prepared_sha256':sha(prepared/'manifest.json')})
    if mode=='main':
        extras=[(prepared/n,'frozen/'+n) for n in ('manifest.json','model.json','priors.json','protocol.json','prior_revalidation.json')]
        extras += [(ROOT/n,'code/'+n) for n in own_identity()]
        fixed=latest_completed('fixed',prepared)
        extras += [(f,'fixed_development/'+str(f.relative_to(fixed))) for f in fixed.rglob('*') if f.is_file() and not f.is_symlink()]
        bundle=save_zip(out,ROOT/'archives'/(out.name+'.zip'),extras)
        print('MUSIQUE_JOINT_ARCHIVE='+json.dumps({'path':str(bundle),'sha256':sha(bundle)}),flush=True)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('command',choices=['plan','prepare','gate','fixed','main','report'])
    ap.add_argument('--prior-suite',type=Path,default=DEFAULT_PRIOR)
    ap.add_argument('--runtime',type=Path,default=Path('/home/wmy/sci/spra_core_exp/joint_e1'))
    ap.add_argument('--resume',type=Path)
    ap.add_argument('--retry-incomplete',action='store_true',help='explicitly record a new attempt; never automatic')
    ap.add_argument('--run-dir',type=Path)
    a=ap.parse_args()
    if a.retry_incomplete and not a.resume:ap.error('--retry-incomplete requires --resume')
    if a.command=='plan':
        print(json.dumps(config(),ensure_ascii=False,indent=2));return
    if a.command=='prepare':prepare(a.prior_suite);return
    if a.command=='report':
        if a.run_dir is None:ap.error('--run-dir required')
        print((a.run_dir/'joint_result.json').read_text());return
    asyncio.run(live(a.command,a.runtime,a.resume,a.retry_incomplete))
