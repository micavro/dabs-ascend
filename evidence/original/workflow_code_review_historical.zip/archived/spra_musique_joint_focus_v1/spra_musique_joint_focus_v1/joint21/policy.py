"""Keep exact D0 and Mixed1024; Joint adds at most one existing route alternative.

Not a no-regression theorem. All candidate effects use the preserved common
continuation. Local feedback budget is inside the existing global deadline.
"""
from __future__ import annotations
import copy
import math
import time
from .dependency import activate
activate()
from batching20.policy import process_plan as composition_plan, choose_caps, scheduling_view, scheduling_hash
from semantic19.selector import choose as original_D0
from joint18v2.actions import resources
from joint18v2.common import validate_action, action_key
from core18v2.engine import evaluate


def distinct_alternative(snapshot, cfg, d0, evaluations):
    """Choose only a placement already evaluated/proposed by unchanged D0.

    D0 admission/order stay byte-for-byte the same. Native memory projection
    cannot silently alter the admitted set. No running request can be migrated.
    """
    options = []
    for e in evaluations:
        proposal = e.get('action')
        if not isinstance(proposal, dict): continue
        q = copy.deepcopy(d0)
        q['placement'] = copy.deepcopy(proposal['placement'])
        if q['placement'] == d0['placement']: continue
        if set(q['placement']) != set(d0['placement']): continue
        if any(snapshot['nodes'][k]['state'] != 'ready' for k in q['placement']): continue
        changed = [k for k in q['admit'] if q['placement'][k] != d0['placement'][k]]
        if not changed: continue
        projected = resources(q, snapshot, cfg)
        if projected['admit'] != d0['admit']: continue
        validate_action(q, snapshot, cfg)
        q['family'] = 'joint_feedback/' + proposal.get('family', 'existing_D0_route')
        q['feedback_moved'] = changed
        options.append(q)
    if not options: return None
    # The existing D0 is a two-route selector; deterministic tie rule is not GPU-outcome based.
    return min(options, key=lambda a: (len(a['feedback_moved']), action_key(a)))


def feedback(snapshot, model, cfg, d0_answer, composed, deadline, evaluator=evaluate):
    start = time.monotonic()
    result = copy.deepcopy(d0_answer)
    result['action'] = copy.deepcopy(composed)
    evidence = {'schema': 'musique-one-feedback-1', 'reference': 'D0_then_frozen_Mixed1024',
                'real_nonregression_guaranteed': False, 'four_cells_complete': False,
                'changed_from_composition': False, 'route_feedback_selected': False,
                'uncompleted_scores_ranked': False, 'quality_or_TPOT_veto': False,
                'scores': [], 'additional_wall_ms': 0.0}
    result['joint21'] = evidence
    def done(reason):
        evidence['reason'] = reason
        evidence['additional_wall_ms'] = 1000 * (time.monotonic() - start)
        evidence['D0_action'] = copy.deepcopy(d0_answer.get('batching20', {}).get('D0_action', d0_answer['action']))
        evidence['composition_action'] = copy.deepcopy(composed)
        validate_action(result['action'], snapshot, cfg)
        return result
    d0 = copy.deepcopy(d0_answer.get('batching20', {}).get('D0_action', d0_answer['action']))
    alternative = distinct_alternative(snapshot, cfg, d0, d0_answer.get('evaluations', []))
    if alternative is None: return done('no_distinct_existing_D0_placement')
    cap0, ev0 = choose_caps(snapshot, d0, model, cfg, 'mixed_1024')
    cap1, ev1 = choose_caps(snapshot, alternative, model, cfg, 'mixed_1024')
    evidence['postplacement_cap_evidence'] = {'r0': ev0, 'r1': ev1}
    if cap0 == [4096] * snapshot['replicas'] and cap1 == cap0:
        # Proposal screening only: not a statement that future window effects are equal.
        return done('no_observed_mixed_opportunity_in_either_placement')
    cells = {}
    for route, a in [('r0', d0), ('r1', alternative)]:
        for budget, caps in [('F', [4096] * snapshot['replicas']), ('M', cap0 if route == 'r0' else cap1)]:
            q = copy.deepcopy(a); q['caps'] = list(caps); cells[route + budget] = q
    if action_key(composed) != action_key(cells['r0M']):
        return done('composition_already_used_deadline_fallback')
    budget_s = min(float(cfg.get('joint21_feedback_ms', 8.0)) / 1000,
                   max(0.0, deadline - start - 0.001))
    if budget_s <= 0.001: return done('no_feedback_time_after_D0')
    stop = start + budget_s
    ecfg = {k:v for k,v in cfg.items() if not k.startswith('joint21_')}
    ecfg['base_cap'] = 4096
    # Same expected commit for every cell, including C. No fictional immediate action.
    ecfg['apply_delay_ms'] = max(float(cfg.get('apply_delay_ms', 0.)),
                                1000 * max(0., start - snapshot['now']) + budget_s*1000 + 2.0)
    if ecfg['apply_delay_ms'] >= float(ecfg.get('action_horizon_ms', 200.)) - 1.0:
        return done('too_little_physical_window_after_feedback')
    evidence['common_expected_apply_delay_ms'] = ecfg['apply_delay_ms']
    memo = {}; scores = {}; labels = ['r0M','r0F','r1M','r1F']
    unique = list(dict.fromkeys(action_key(cells[x]) for x in labels))
    evidence['distinct_complete_actions'] = len(unique)
    evidence['same_admit_and_order_as_D0'] = all(
        a['admit'] == d0['admit'] and a['order'] == d0['order'] for a in cells.values())
    for i, label in enumerate(labels):
        key = action_key(cells[label])
        if key not in memo:
            left = len([k for k in unique if k not in memo]); now = time.monotonic()
            if now >= stop: return done('feedback_deadline_composition_retained')
            slice_stop = min(stop, now + (stop - now) / max(1, left))
            try:
                z = evaluator(snapshot, cells[label], model, ecfg, deadline=slice_stop)
            except (ValueError, KeyError, RuntimeError, OverflowError, ZeroDivisionError) as exc:
                evidence['evaluation_error'] = repr(exc)
                return done('evaluation_error_composition_retained')
            memo[key] = z
        z = memo[key]; value = z.get('sum_remaining_jct_ms')
        valid = bool(z.get('rankable')) and isinstance(value, (int,float)) and math.isfinite(value)
        evidence['scores'].append({'cell': label, 'action': cells[label], 'complete': valid,
                                   'model_cost_ms': value if valid else None,
                                   'reason': z.get('reason'), 'cpu_wall_ms': z.get('cpu_wall_ms')})
        if not valid: return done('incomplete_cell_composition_retained')
        scores[label] = float(value)
    if time.monotonic() >= deadline: return done('feedback_return_deadline_composition_retained')
    evidence['four_cells_complete'] = True
    best = min(labels, key=lambda x: (scores[x], x != 'r0M', labels.index(x)))
    active_wf = len({n['wid'] for n in snapshot['nodes'].values() if n['state'] != 'done'})
    # Empirical risk guard, NOT a calibrated error bound. Actual overhead stays in real JCT.
    expected_extra = max(1., 1000*(time.monotonic()-start)) * active_wf
    threshold = max(float(cfg.get('minimum_predicted_gain_ms', 1.0)), expected_extra)
    gain = scores['r0M'] - scores[best]
    evidence.update(predicted_gain_ms=gain, estimated_extra_wait_charge_ms=expected_extra,
                    acceptance_margin_ms=threshold, candidate_winner=best,
                    margin_is_certified_error_bound=False)
    if best == 'r0M' or gain <= threshold: return done('insufficient_net_predicted_gain_keeps_composition')
    result['action'] = copy.deepcopy(cells[best])
    result['action']['family'] = 'joint_feedback/' + best
    evidence.update(changed_from_composition=True, selected_cell=best,
                    route_feedback_selected=result['action']['placement'] != d0['placement'])
    # Existing batching integrity checker still describes the PRE-feedback composition.
    result['joint21']['D0_schedule_hash'] = scheduling_hash(d0)
    return done('complete_packet_feedback_selected')


def process_plan(snapshot, model, cfg, method, deadline):
    mode = cfg.get('joint21_method')
    cleaned = {k:v for k,v in cfg.items() if not k.startswith('joint21_')}
    if mode == 'D':
        fixed = int(cfg.get('joint21_fixed_cap', 4096))
        cc = dict(cleaned); cc['batching20_policy'] = 'fixed_' + str(fixed)
        return composition_plan(snapshot, model, cc, 'D', deadline)
    if mode not in ('C','J'): raise ValueError('unknown joint21 optimized method')
    cc = dict(cleaned); cc.update(batching20_policy='mixed_1024', batching20_output_priors=cfg.get('joint21_output_priors', {}))
    answer = composition_plan(snapshot, model, cc, 'D', deadline)
    if mode == 'C': return answer
    ecfg = dict(cfg); ecfg['batching20_output_priors'] = cfg.get('joint21_output_priors', {})
    return feedback(snapshot, model, ecfg, answer, answer['action'], deadline)
