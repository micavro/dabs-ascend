from __future__ import annotations
import hashlib
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BATCH = Path(os.environ.get('D0_BATCH_SOURCE', ROOT.parent / 'spra_musique_d0_batching_v1')).resolve()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def activate():
    sys.dont_write_bytecode = True
    expected = json.loads((ROOT / 'dependency_identity.json').read_text())
    bad = {}
    for rel, want in expected.items():
        p = BATCH / rel
        got = sha(p) if p.is_file() else None
        if got != want:
            bad[rel] = {'expected': want, 'actual': got}
    if bad:
        raise RuntimeError('Frozen batching/D0 dependency differs; no files changed: ' + json.dumps(bad))
    if str(BATCH) not in sys.path:
        sys.path.insert(0, str(BATCH))
    from batching20.dependency import activate as original_activate
    return original_activate()

def own_identity():
    out = {}
    for d in ('joint21', 'tools', 'configs'):
        for p in sorted((ROOT / d).rglob('*')):
            if p.is_file() and p.suffix in ('.py', '.sh', '.json'):
                out[str(p.relative_to(ROOT))] = sha(p)
    out['dependency_identity.json'] = sha(ROOT / 'dependency_identity.json')
    return out
