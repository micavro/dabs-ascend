from contextlib import contextmanager
from .dependency import activate
activate()
from .policy import process_plan
from .batchcheck import compare_iteration
from typed19.transport import stream
import joint18v2.client as client

@contextmanager
def bindings():
    old = client.process_plan, client.compare_iteration, client.stream
    client.process_plan, client.compare_iteration, client.stream = process_plan, compare_iteration, stream
    try: yield
    finally: client.process_plan, client.compare_iteration, client.stream = old
