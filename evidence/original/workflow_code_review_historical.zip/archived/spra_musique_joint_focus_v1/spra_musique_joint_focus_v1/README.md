# MuSiQue：D₀ + Mixed1024 + 一次轻量联合反馈

本包是独立客户端实验目录，**不是后端补丁，不需要 stage、重启、下载数据、重跑canary或旧54条件开发**。

## 目标和证据边界

使用已运行成功的结构化MuSiQue应用、原D₀调度函数和冻结Mixed1024控制，重点研究4 workflow/s的完整JCT。现有4/s增量来自一个有效配对，不能承诺复现；原2/s负结果不删除。

四种核心方法：

- A-Tuned：原Affinity/FIFO，固定额度在本包开发集选择。
- D0-F4096：原D₀函数、模型和参数，固定4096。
- C-D0-Mixed1024：原D₀先选调度、原Mixed1024后选额度。是组合参照，不冒充新的联合反馈。
- J-Light：以C为参照，最多取D₀本次已经生成的一个替代放置，比较两种放置各自的fixed/Mixed响应。仍保留D₀的准入和顺序。

性能目标是完整JCT相对A超过10%，**不是保证，也不要求协调增量自己超过10%**。TTFT、TPOT、质量和生成量完整记录，不作性能晋级门槛。资源、依赖、请求对应和动作时间检查仍须全部通过。

## 本次确认的代码缺陷

原 `joint18v2/batchcheck.py` 使用 `min(remaining, room//16*16)`。当尾块本来能放下、但可用额度不是整块时，会错误截短。例如remaining=31、room=31时原检查器预测16，而vLLM 0.6.3对应条件应为31。remaining=13、room=1024时原代码本来就得到13；不能误用那个例子证明现有代码有错。

修正为：只有 `remaining > room` 才把room按块向下取整。预测不读取原生结果；未知分配分支、抢占、swap、字段缺失继续拒绝接受。`free_blocks_before`在现有hook中实际上是在schedule后采样，本包不将它用作调度前内存证明。

这确认了**源码缺陷**，不预先声称旧256/257恰由此引起。`run_prepare.sh`会在你的服务器读取真正的那条迭代并判定。

## 依赖和路径

CPU下载目录：`/home/wmy/paper/sci/`

GPU39：`wqx@10.18.2.128`，端口8822，CPU密钥`/home/wmy/ustc87`。

GPU项目根目录：`/home/wmy/sci/spra_paper_experiments_github/`

下面三个已经存在的目录必须保留，程序只读并校验哈希：

```
spra_musique_d0_batching_v1/
spra_stage19_typed_handoff_v1/
spra_stage19_musique_joint_v1/
```

冻结模型来自 `spra_musique_d0_batching_v1/prepared/latest.json`。不重新拟合，不再访问原始下载站。

默认旧失败目录：

```
../spra_musique_d0_batching_v1/runs/D0_BATCH_CONFIRM_20261010T123919Z_df416da6/
```

实际路径不同可用 `bash run_prepare.sh --prior-suite /实际目录`。不得改哈希强行放行。

## 最短执行顺序（GPU39）

```
conda activate spra-exp
cd /home/wmy/sci/spra_paper_experiments_github/spra_musique_joint_focus_v1
bash run_checks.sh
bash run_prepare.sh
python -B tools/run_focus.py gate
bash run_fixed.sh
bash run_main.sh
```

都支持在外层使用`set -euo pipefail`和`tee`。**不要调用原目录的run_confirm.sh，这不是其断点续跑。**

### prepare：只读原记录并冻结新协议

同一个修正的独立检查器重核旧失败suite内每一个已保存的测量条件。全部可解释才生成新prepared指针；旧summary、失败状态、index和5个已接受结果均不改写。未运行的旧30格不会被伪装成已完成，新旧批次不混合。

成功：`PRIOR_REVALIDATION`和`JOINT_FOCUS_FROZEN`。

不能解释：`UNRESOLVED_BATCH_EVIDENCE_BUNDLE`指向自动生成的zip，随后停止，无新GPU请求。缺少字段不视为成功，不把实际输出喂回预测。

### fixed：10个开发条件

原32个train问题，一次完整工作集，4/s原wave。A和D₀分别比较256/512/1024/2048/4096；共同计入完整JCT并记录质量。D₀打分仍使用原4096参照，固定cap是外部覆盖，避免悄悄改变已有效的调度函数。

只根据全部十格完成后的Mean JCT选择两种方法各自最佳已测固定cap。**这是N32开发选择，不是宣称知道N64的真实最优固定额度。**D₀原4096仍在主结果保留。

### main：16个核心条件，最多24个（强参照需要时增加）

4/s；每条件64个MuSiQue问题；四个block各运行四种核心方法。若A开发最优不是4096，加A-F4096；若D₀开发最优不是4096，加D0-BestFixed。相同固定配置合并角色，绝不当成重复样本。

四个block**复用已经编译的64个dev问题**，按预声明hash seed改变到达顺序；不是四组新问题、不是未见holdout。原始DAG、父答案、自然EOS和JSON协议不变，不按答对/输出长度/收益筛题。到达仍是原wave：平均4/s，8/s到达1秒后停止1秒；N64到达偏移为0.0625至14.9375秒，不声称稳态容量。

每个suite或恢复segment先做固定8个普通生成＋4个JSON预热，单独记录；不复跑旧canary。沿用现有Run namespace初始冷前缀约定，不新增盐规则，不清空物理缓存。

## 搜索边界

J保留完整C和D₀；额外反馈最多8ms，并包含在原80ms规划预算内。最多一个D₀已有替代放置；准入、顺序不变；不能改已提交节点。对每个放置重新调用同一Mixed1024函数，不把旧向量机械套到新副本。

四格只按完整动作完全相同去重，不把“下一批相同”当作“200ms内等价”。没有观测到mixed机会只是筛选规则，明确不证明未来整个窗口等价。全部不同格评分完整后才允许改变C；不可排名、超时、数值错误、实际窗口不足都保留C。

候选使用同一预计生效时刻、同一200ms到期规则和继承状态的共同续行。选择增加一个按活跃workflow数估计的CPU等待余量，该余量**不是模型误差上界或性能保证**。所有真实计算、提交、准入和输入准备仍计入实测JCT。

## 报告与归档

正式主行是 `JOINT_FOCUS_CONDITION_ACCEPTED`。继承client打印的`CONDITION_DONE`是初步统计，不能在新的独立核对之前当成最终接受。

主要报告：

```
MUSIQUE_JOINT_FOCUS_RESULT=...
MUSIQUE_JOINT_ARCHIVE={"path":"...zip","sha256":"..."}
```

分别计算J/A-Tuned、J/A-F4096、C/A、D₀/A-F4096、C/D₀、C/最佳开发fixed-D₀、J/C，按同block比值后再平均。调度动作的同额度对照使用D₀-F4096对A-F4096，不把不同固定cap造成的差异全部归为DAG信息。保留每格JCT、TTFT、TPOT代理、有限工作集吞吐、质量、真实生成量和cap活动。

如果C超过10%、J没有超过C，结果是“组合有效，额外协调未建立”，不能改名。没有正收益也完成批次并归档，不自动改规则或更换负载。

## 中断与恢复

本包新suite有显式恢复：

```
bash run_main.sh --resume runs/JOINT_MAIN_实际名称
```

已接受记录先核对文件哈希，只使用一次；请求已经完整结束且证据充分的raw条件可以离线补完评分与接受，不重新生成。

确实执行中断、原始证据不完整的条件不会自动重试。只有明确选择再次执行时使用：

```
bash run_main.sh --resume runs/JOINT_MAIN_实际名称 --retry-incomplete
```

它创建`__attempt02`并保留原attempt、失败原因与segment，不覆盖文件。不得以性能不理想为由重试已接受条件；代码会跳过已接受条件。跨segment的配对时间差作为实验边界保留。

## 本地测试不代表什么

测试涉及原client/hook的假引擎、合成磁盘归档和真正的spawn子进程，不涉及目标原生vLLM、真实GPU或真实MuSiQue生成。源码正确性检查不能推导10%收益。完整测试记录与环境在TEST_RESULTS/TEST_SCOPE中。
