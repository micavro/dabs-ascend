import copy
import unittest
from joint21.batchcheck import prefill_chunk, predict_next, compare_iteration

def item(r,pre,p=1,c=0):return {'request_id':r,'prefill':pre,'prompt':p,'computed':c}
def event(available=13,remaining=13):
    # One decode and a first prefill consume enough total to leave exactly available.
    q={'running':[item('d',False,100,100)],'waiting':[item('first',True,4095-available),item('tail',True,remaining)],'swapped':[]}
    mapping=predict_next(q,4096,4096)
    scheduled=[{'request_id':k,'tokens':v,'prefill':k!='d'} for k,v in mapping.items()]
    return {'replica':0,'iteration':1,'pid':11,'case':'synthetic','plan_id':'p',
            'ordered_before':q,'total':4096,'prefill_cap':4096,'scheduled':scheduled,'preemptions':0,
            'prefill_logical_tokens':sum(x['tokens'] for x in scheduled if x['prefill']),'decode_tokens':1}

class TailTests(unittest.TestCase):
    def test_tail_fits_not_rounded(self):
        for n in (1,15,16,17,31,1023,1024,1025):
            for extra in (0,1,7,15,1024):
                self.assertEqual(prefill_chunk(n,n+extra),n)
    def test_truncated_chunks_align(self):
        for n in (1,15,16,17,1023,1024,1025):
            for room in range(n):self.assertEqual(prefill_chunk(n,room),(room//16)*16)
    def test_advice13_with1024_does_not_fail_old(self):
        q={'running':[],'waiting':[item('p',True,13)]}
        self.assertEqual(predict_next(q,1024,1024,legacy=True),{'p':13})
    def test_actual_formula_failure_on_residual13(self):
        e=event();c=compare_iteration(e)
        self.assertEqual(c['actual']['tail'],13);self.assertNotIn('tail',c['legacy_predicted'])
        self.assertTrue(c['match']);self.assertEqual(c['classification'],'matched_tail_rule_correction')
    def test_remaining31_room31_old16_new31(self):
        c=compare_iteration(event(31,31));self.assertEqual(c['legacy_predicted']['tail'],16);self.assertEqual(c['predicted']['tail'],31)
    def test_unexplained_member_remains_failure(self):
        e=event(1024,1024);e['scheduled']=e['scheduled'][:-1];e['prefill_logical_tokens']-=1024
        c=compare_iteration(e);self.assertFalse(c['match']);self.assertEqual(c['classification'],'unresolved_prediction_mismatch')
    def test_no_actual_output_used_to_predict(self):
        e=event();p=compare_iteration(e)['predicted'];e['scheduled'][0]['tokens']=2
        self.assertEqual(compare_iteration(e)['predicted'],p);self.assertFalse(compare_iteration(e)['match'])
    def test_duplicate_fails(self):
        e=event();e['scheduled'].append(copy.deepcopy(e['scheduled'][0]));self.assertFalse(compare_iteration(e)['match'])
    def test_swap_unsupported_not_matched(self):
        e=event();e['ordered_before']['swapped']=[item('s',True)];self.assertFalse(compare_iteration(e)['match'])
    def test_preemption_not_silently_legal(self):
        e=event();e['preemptions']=1;self.assertFalse(compare_iteration(e)['match'])
    def test_bad_logical_totals_fail(self):
        e=event();e['decode_tokens']=99;self.assertFalse(compare_iteration(e)['match'])
    def test_invalid_values(self):
        for x in (-1,True,1.5):
            with self.assertRaises(ValueError):prefill_chunk(x,16)
    def test_input_unmodified(self):
        e=event();old=copy.deepcopy(e);compare_iteration(e);self.assertEqual(e,old)
    def test_missing_evidence_false(self):self.assertFalse(compare_iteration({})['match'])
    def test_cap_independent_of_decode(self):
        q={'running':[item('d',False,100,100)],'waiting':[item('p',True,2048)]}
        self.assertEqual(predict_next(q,4096,1024),{'d':1,'p':1024})
