"""Synthetic disk artifacts and mocked serving; never performance evidence."""
import asyncio,contextlib,copy,io,json,tempfile,unittest,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
from joint21.dependency import activate,ROOT,own_identity
activate()
from joint21 import experiment as E
from batching20.dependency import TYPED,verify
from joint18v2.common import atomic,load
from semantic19.dataset import compile_record
sys.path.insert(0,str(TYPED/'tests'))
from test_typed_contract import fixture,FakeTokenizer
from test_audit_protocol import write_condition
from test_batchcheck import event

class OrchestrationTests(unittest.IsolatedAsyncioTestCase):
    def setup_artifacts(self,root):
        for rel in own_identity():
            f=root/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((ROOT/rel).read_bytes())
        dataset=root/'dataset';dataset.mkdir()
        for split,n in [('profile',32),('pilot',64)]:
            rows=[]
            for i in range(n):
                raw=fixture();raw['id']=f'FAKE_{split}_{i}';row,g=compile_record(raw);rows.append(row)
            (dataset/(split+'.public.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in rows))
        (dataset/'evaluation_gold.jsonl').write_text('')
        dm={'files':{f.name:E.sha(f) for f in dataset.iterdir()},'counts':{'profile':32,'pilot':64}}
        atomic(dataset/'manifest.json',dm)
        frozen=root/'old_frozen';frozen.mkdir()
        cfg=load(TYPED/'configs/semantic.json');cfg['base_cap']=4096
        model={'models':{str(i):{'coef':[10.,0.,0.,0.,0.,0.]} for i in range(4)}};priors={'3':{'p75':8}}
        atomic(frozen/'model.json',model);atomic(frozen/'priors.json',priors);atomic(frozen/'manifest.json',{})
        mf={'dataset':str(dataset),'dataset_manifest_sha256':E.sha(dataset/'manifest.json'),'dataset_files':dm['files'],
            'D0_configuration':cfg,'source_hashes':verify()}
        prior=root/'old_failed';prior.mkdir();write_condition(prior/'R4_A')
        atomic(prior/'frozen_protocol.json',{});atomic(prior/'cleanup.json',{'backend_drained':True})
        runtime=root/'runtime';(runtime/'joint18v2').mkdir(parents=True)
        return frozen,mf,model,priors,prior,runtime
    async def flow(self,fail=False):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);frozen,mf,model,priors,prior,runtime=self.setup_artifacts(root)
            calls=[];failed=[False]
            async def gate(*args):return [{'hook_source_sha256':E.HOOK}]*4
            async def warm(*args):return None
            async def drained(*args):return True
            def quality(*args):return {'semantic_quality':{'final_em':0.,'final_f1':0.},'quality_rows':[]}
            async def execute(client,runtime,initial,cfg,ns,folder,method,model,executor=None,materializer=None):
                calls.append(cfg['joint21_method']);folder.mkdir(parents=True)
                for k,n in ns.items():
                    await materializer(k,ns);n.update(state='done',start=10+n['step_position'],finish=10.5+n['step_position'],
                        stream={'text':'{"answer":"Paris"}','usage':{'completion_tokens':8}},replica=0)
                # Native batch fixture is separate from the fake workflow nodes. Tests
                # exercise the real proof/receipt driver; not native-generation mapping.
                ev=event();ev['event']='iteration'
                # Use a small independent single-prefill record valid for every fixed cap.
                ev['ordered_before']={'running':[],'waiting':[{'request_id':'x','prefill':True,'prompt':32,'computed':0}],'swapped':[]}
                ev['scheduled']=[{'request_id':'x','prefill':True,'tokens':32}]
                ev['prefill_cap']=cfg['base_cap'];ev['prefill_logical_tokens']=32;ev['decode_tokens']=0
                ev['remaining_prefill_in_before']=32
                atomic(folder/'nodes.json',ns);atomic(folder/'manifest.json',{})
                atomic(folder/'trace_capture.json',{'partial_lines':0,'condition_failed':False})
                (folder/'backend.jsonl').write_text(json.dumps(ev)+'\n');(folder/'plans.jsonl').write_text('')
                val={'A':120,'D':105,'C':100,'J':98}[cfg['joint21_method']]+(4096/cfg['base_cap']-1)
                s={'condition_valid':True,'budget_invariants':True,'control_time_match':True,
                   'request_correlation':f'{len(ns)}/{len(ns)}','native_next_batch_checked':1,'native_next_batch_matches':1,
                   'mean_jct_ms':val,'p95_jct_ms':val+10,'workflows':cfg['workflow_count'],
                   'cohort_duration_s':1.,'cohort_workflows_s':1000/val,'cohort_tokens_s':8000/val,'output_tokens':len(ns)*8}
                atomic(folder/'summary.json',s)
                if fail and len(calls)==3 and not failed[0]:
                    failed[0]=True;raise RuntimeError('injected after complete raw save')
                return s,[ev]
            with patch.object(E,'ROOT',root),patch.object(E.old,'load_frozen',return_value=(frozen,mf,model,priors)),\
                 patch.object(E.old,'read_selection',return_value=(root,{'adaptive_policy':'mixed_1024'})),\
                 contextlib.redirect_stdout(io.StringIO()):
                E.prepare(prior)
                with patch.object(E,'gate',gate),patch.object(E.old,'warmup',warm),patch.object(E,'wait_drained',drained),\
                     patch.object(E,'ServerTokenizer',lambda *a:FakeTokenizer()),patch.object(E,'execute',execute),\
                     patch.object(E,'evaluate_quality',quality),patch.object(E,'ProcessPoolExecutor',lambda *a,**kw:ThreadPoolExecutor(1)):
                    if fail:
                        with self.assertRaisesRegex(RuntimeError,'injected'):await E.live('fixed',runtime)
                        suite=next((root/'runs').iterdir());self.assertEqual(load(suite/'suite_status.json')['accepted_conditions'],2)
                        self.assertFalse((root/'records/fixed_latest.json').exists())
                        await E.live('fixed',runtime,resume=suite)
                        self.assertEqual(len(calls),10) # third completed attempt finalized, NOT regenerated
                    else:await E.live('fixed',runtime)
                    self.assertEqual(len(calls),10)
                    await E.live('main',runtime);self.assertEqual(len(calls),26)
                    result=load(Path(load(root/'records/main_latest.json')['directory'])/'joint_result.json')
                    self.assertTrue(result['point_estimate_J_above_10pct'])
                    self.assertFalse(result['formal_10pct_guarantee'])
                    before=len(calls);await E.live('main',runtime);self.assertEqual(len(calls),before)
                    arc=list((root/'archives').glob('*.zip'));self.assertEqual(len(arc),1)
                    import zipfile
                    with zipfile.ZipFile(arc[0]) as z:self.assertIsNone(z.testzip())
    async def test_prepare_fixed_main_archive(self):await self.flow()
    async def test_resume_completed_raw_without_reexecution(self):await self.flow(True)
    async def test_prepare_unresolved_never_opens_live(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);fr,mf,m,pr,prior,rt=self.setup_artifacts(root)
            e=json.loads((prior/'R4_A/backend.jsonl').read_text());e['scheduled'][-1]['tokens']-=1;e['prefill_logical_tokens']-=1
            (prior/'R4_A/backend.jsonl').write_text(json.dumps(e)+'\n')
            with patch.object(E,'ROOT',root),patch.object(E.old,'load_frozen',return_value=(fr,mf,m,pr)),\
                 patch.object(E.old,'read_selection',return_value=(root,{'adaptive_policy':'mixed_1024'})),\
                 contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(RuntimeError,'remains unresolved'):E.prepare(prior)
                self.assertFalse((root/'prepared/latest.json').exists())
                self.assertEqual(len(list((root/'reports').glob('*.zip'))),1)
