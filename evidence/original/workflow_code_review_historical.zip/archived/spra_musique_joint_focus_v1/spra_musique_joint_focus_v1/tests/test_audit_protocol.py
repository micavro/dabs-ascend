import copy,json,tempfile,unittest
from pathlib import Path
from joint21.audit import condition_verdict,revalidate_suite
from joint21.dependency import sha
from joint21.protocol import tuning_design,main_design,select_fixed,report,packet_order
from test_batchcheck import event
P=json.loads((Path(__file__).parents[1]/'configs/protocol.json').read_text())

def write_condition(folder,break_match=False):
    folder.mkdir(parents=True)
    e=event();e['event']='iteration'
    if break_match:e['scheduled'][-1]['tokens']-=1;e['prefill_logical_tokens']-=1
    ns={k:{'state':'done','parents':[],'stream':{'text':'{"answer":"x"}'}} for k in ('d','first','tail')}
    s={'condition_valid':True,'budget_invariants':True,'control_time_match':True,'request_correlation':'3/3',
       'native_next_batch_checked':1,'native_next_batch_matches':0,'mean_jct_ms':123.4}
    for name,obj in [('nodes.json',ns),('summary.json',s),('manifest.json',{}),('trace_capture.json',{'partial_lines':0,'condition_failed':False})]:
        (folder/name).write_text(json.dumps(obj))
    (folder/'backend.jsonl').write_text(json.dumps(e)+'\n')

class AuditTests(unittest.TestCase):
    def test_saved_tail_is_revalidated_not_retimed(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'R4_1_A';write_condition(p);before={f.name:sha(f) for f in p.iterdir()}
            v=condition_verdict(p);self.assertTrue(v['accepted']);self.assertEqual(v['legacy_matches'],0)
            self.assertEqual(v['matches'],1);self.assertEqual(before,{f.name:sha(f) for f in p.iterdir()})
    def test_unrelated_mismatch_stays_failed(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'R4_1_A';write_condition(p,True);self.assertFalse(condition_verdict(p)['accepted'])
    def test_partial_trace_not_accepted(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'R4_1_A';write_condition(p);(p/'trace_capture.json').write_text('{"partial_lines":1}')
            self.assertFalse(condition_verdict(p)['accepted'])
    def test_no_auto_creation_missing_evidence(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'nonexistent';self.assertFalse(condition_verdict(p)['accepted']);self.assertFalse(p.exists())
    def test_suite_does_not_claim_completion(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);write_condition(p/'R4_A');(p/'frozen_protocol.json').write_text('{}');(p/'cleanup.json').write_text('{"backend_drained":true}')
            v=revalidate_suite(p);self.assertTrue(v['all_saved_conditions_revalidated']);self.assertFalse(v['old_suite_completed_by_this_tool'])
    def test_failed_node_never_accepted(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'R4_A';write_condition(p);n=json.loads((p/'nodes.json').read_text());n['d']['state']='submitted'
            (p/'nodes.json').write_text(json.dumps(n));self.assertFalse(condition_verdict(p)['accepted'])

class ProtocolTests(unittest.TestCase):
    def test_complete_fixed_scan(self):
        self.assertEqual(len(tuning_design(P)),10)
        self.assertEqual({(c['mode'],c['fixed_cap']) for c in tuning_design(P)},{(m,c) for m in ('A','D') for c in P['fixed_caps']})
    def test_aliases_not_duplicate_conditions(self):
        d=main_design(P,{'caps':{'A':4096,'D':4096}});self.assertEqual(len(d),16)
        for b in range(1,5):self.assertEqual(len([x for x in d if x['block']==b]),4)
    def test_stronger_fixed_refs_are_added(self):
        self.assertEqual(len(main_design(P,{'caps':{'A':512,'D':2048}})),24)
    def test_method_positions_balanced_for_core_four(self):
        d=main_design(P,{'caps':{'A':4096,'D':4096}})
        for role in ('A-Tuned','D0-F4096','C-D0-Mixed1024','J-Light'):
            self.assertEqual({x['position'] for x in d if x['role']==role},{1,2,3,4})
    def test_fixed_selection_not_quality(self):
        rows=[{**d,'accepted':True,'external_work_sha256':'same','summary':{'mean_jct_ms':100+4096/d['fixed_cap'],'quality':0}} for d in tuning_design(P)]
        self.assertEqual(select_fixed(rows,P)['caps'],{'A':4096,'D':4096})
    def test_no_partial_winner(self):
        with self.assertRaises(ValueError):select_fixed([],P)
    def test_packet_order_not_from_labels(self):
        x=[{'id':str(i),'gold':i} for i in range(64)]
        self.assertEqual([r['id'] for r in packet_order(x,1)],[r['id'] for r in packet_order(list(reversed(x)),1)])
        self.assertEqual(len({r['id'] for r in packet_order(x,1)}),64)
    def test_full_report_three_different_effects(self):
        sel={'caps':{'A':4096,'D':4096}};rows=[]
        for d in main_design(P,sel):
            v={'A':100,'D':90,'C':85,'J':80}[d['mode']]
            rows.append({**d,'accepted':True,'external_work_sha256':str(d['block']),
                 'summary':{'mean_jct_ms':v,'cohort_workflows_s':100/v,'cohort_tokens_s':1000/v}})
        r=report(rows,sel,P);self.assertAlmostEqual(r['mean_paired_JCT_gain_pct']['total_J_vs_A'],20)
        self.assertAlmostEqual(r['mean_paired_JCT_gain_pct']['batching_C_vs_D0'],100*(1-85/90))
        self.assertFalse(r['formal_10pct_guarantee'])
    def test_cross_block_external_mismatch_rejected(self):
        sel={'caps':{'A':4096,'D':4096}};rows=[]
        for d in main_design(P,sel):rows.append({**d,'accepted':True,'external_work_sha256':d['role'],'summary':{}})
        with self.assertRaises(ValueError):report(rows,sel,P)
