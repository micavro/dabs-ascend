import copy,json,multiprocessing,subprocess,sys,time,unittest
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from joint21.dependency import activate,ROOT
activate()
from joint21.policy import process_plan
from test_policy import fixture,MODEL

class SpawnAndCLITests(unittest.TestCase):
    def test_real_spawn_worker(self):
        s,a,c=fixture();c.update(joint21_method='C')
        with ProcessPoolExecutor(1,mp_context=multiprocessing.get_context('spawn')) as pool:
            r=pool.submit(process_plan,s,MODEL,c,'D',time.monotonic()+5).result(timeout=10)
        self.assertTrue(r['batching20']['D0_schedule_unchanged'])
    def test_plan_needs_no_server(self):
        x=subprocess.run([sys.executable,'-B',str(ROOT/'tools/run_focus.py'),'plan'],capture_output=True,text=True,timeout=20)
        self.assertEqual(x.returncode,0,x.stderr);q=json.loads(x.stdout);self.assertEqual(q['primary_rate'],4.0)
    def test_retry_requires_resume(self):
        x=subprocess.run([sys.executable,'-B',str(ROOT/'tools/run_focus.py'),'main','--retry-incomplete'],capture_output=True,text=True,timeout=20)
        self.assertNotEqual(x.returncode,0);self.assertIn('requires --resume',x.stderr)
