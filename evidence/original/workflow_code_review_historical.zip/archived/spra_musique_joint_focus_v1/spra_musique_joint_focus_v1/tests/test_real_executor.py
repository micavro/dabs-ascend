from __future__ import annotations
import asyncio,contextlib,copy,importlib.util,io,json,os,sys,tempfile,unittest,uuid
from pathlib import Path
from unittest.mock import patch
from concurrent.futures import ThreadPoolExecutor
from joint21.dependency import activate
activate()
from batching20.dependency import TYPED,SOURCE
sys.path.insert(0,str(SOURCE/'tests'));sys.path.insert(0,str(TYPED/'tests'))
from test_typed_contract import fixture,FakeTokenizer
from typed19.workflow import compile_packets,instantiate
from typed19.answers import SCHEMA
from semantic19.dataset import compile_record
from joint18v2.common import load
from joint21.binding import bindings
class RealExecutorTests(unittest.IsolatedAsyncioTestCase):
    async def scenario(self,policy):
        method="A" if policy=="A" else "D"
        import httpx
        from fake_native import modules,FakeGroup,hashes
        from joint18v2.cache import NativeCacheObserver
        import joint18v2.client as C
        from typed19.transport import stream
        with tempfile.TemporaryDirectory() as td:
            path=Path(td);mods,sm,Engine=modules()
            with patch.dict(sys.modules,mods),patch.dict(os.environ,{'SPRA_E1_ROOT':td,'POD_NAME':'spra-vllm-0','NVIDIA_VISIBLE_DEVICES':'MOCK-NOT-GPU'}):
                spec=importlib.util.spec_from_file_location('typedhook'+uuid.uuid4().hex,SOURCE/'runtime/joint18v2_hook.py')
                hook=importlib.util.module_from_spec(spec);spec.loader.exec_module(hook)
                hook.capabilities=lambda:{'scheduler_source_sha256':'fixture','imported_version':'0.6.3','distribution_version':'0.6.3'}
                hook.NativeCacheObserver=lambda mgr,b:NativeCacheObserver(mgr,b,hashes)
                hook.install();sched=sm.Scheduler();engine=Engine(sched);sched._v2_writer.drain()
                initial=[load(path/'joint18v2/spra-vllm-0.status.json')]
                cfg=load(TYPED/'configs/semantic.json');cfg.update(replicas=1,epoch_s=.04,ready_coalesce_s=.001,planning_soft_limit_s=.02,
                    commit_reserve_s=.003,document_tokens_budget=256,max_output_tokens=8,initial_output_estimate=2,
                    snapshot_max_age_s=2.,cache_evidence_max_age_s=2.,condition_wall_s=10,initial_expected_apply_delay_ms=2.)
                cfg['joint21_method']=policy
                cfg['joint21_fixed_cap']=4096
                cfg['base_cap']=4096
                public,_=compile_record(fixture());tok=FakeTokenizer();pack,_=await compile_packets([public],tok,cfg)
                ns,mat,proof=await instantiate(pack,tok,cfg,1)
                for n in ns.values():n['arrival_offset']=0.
                sent=[]
                class Stream(httpx.AsyncByteStream):
                    def __init__(self,g):self.g=g
                    async def __aiter__(self):
                        while self.g.done<1:await asyncio.sleep(.001)
                        yield ('data: '+json.dumps({'id':self.g.request_id,'choices':[{'text':'{"answer":'}]})+'\n\n').encode()
                        while self.g.done<2:await asyncio.sleep(.001)
                        yield ('data: '+json.dumps({'id':self.g.request_id,'choices':[{'text':'"Paris"}','finish_reason':'stop'}]})+'\n\n').encode()
                        yield ('data: '+json.dumps({'choices':[],'usage':{'prompt_tokens':len(self.g.tokens),'completion_tokens':2}})+'\n\n').encode()
                        yield b'data: [DONE]\n\n'
                async def handler(req):
                    payload=json.loads(req.content);sent.append(payload)
                    self.assertEqual(payload['guided_json'],SCHEMA);self.assertNotIn('min_tokens',payload);self.assertNotIn('ignore_eos',payload)
                    g=FakeGroup('r'+uuid.uuid4().hex,payload['prompt'],2);sched.add_seq_group(g)
                    return httpx.Response(200,stream=Stream(g))
                alive=True
                async def pump():
                    while alive:
                        if sched.running or sched.waiting:await engine.step_async()
                        await asyncio.sleep(.003)
                task=asyncio.create_task(pump());model=None if method=='A' else {'models':{'0':{'coef':[1.,0.,0.,0.,0.,0.]}}}
                try:
                    with ThreadPoolExecutor(1) as executor,bindings():
                        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client,contextlib.nullcontext():
                            with contextlib.redirect_stdout(io.StringIO()):s,e=await C.execute(client,path,initial,cfg,ns,path/'RUN',method,model,executor=executor if model else None,materializer=mat)
                    self.assertEqual(s['request_correlation'],'3/3');self.assertEqual(s['native_next_batch_matches'],s['native_next_batch_checked'])
                    self.assertTrue(s['control_time_match']);self.assertEqual(len(sent),3)
                    self.assertTrue(all(n['answer_contract']['status']=='answer' for n in ns.values()))
                    self.assertNotIn('GOLD_SECRET',json.dumps(proof));self.assertIn('(Paris)',ns['w0000/step3']['resolved_question'])
                    from joint21.experiment import feedback_evidence
                    ev=feedback_evidence(path/'RUN',policy)
                    self.assertTrue(ev['D0_rules_unchanged'])
                    self.assertEqual(s['native_next_batch_matches'],s['native_next_batch_checked'])
                finally:
                    alive=False
                    try:await task
                    finally:sched._v2_stop.set();await asyncio.sleep(.04);sched._v2_writer.close()
    async def test_A_actual_client_hook_fake_engine(self):await self.scenario('A')
    async def test_D_actual_client_hook_fake_engine(self):await self.scenario('D')
    async def test_C_actual_client_hook_fake_engine(self):await self.scenario('C')
    async def test_J_actual_client_hook_fake_engine(self):await self.scenario('J')
