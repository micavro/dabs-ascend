import copy
import importlib.util
import sys
import time
import unittest
from unittest.mock import patch
from joint21.dependency import activate,BATCH
activate()
spec=importlib.util.spec_from_file_location('_old_policy_fixtures',BATCH/'tests/test_policy.py')
fixture_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture_module)
fixture,MODEL=fixture_module.fixture,fixture_module.MODEL
from joint21 import policy as P
from joint21.binding import bindings
from batching20.policy import choose_caps,scheduling_view,process_plan as old_composition
from joint18v2.common import action_key

def packet():
    s,a,c=fixture();a1=copy.deepcopy(a);a1['placement']['p']=1;a1['family']='known_dag_partial_group'
    composed=copy.deepcopy(a);composed['caps']=[1024,4096]
    ans={'action':composed,'evaluations':[{'action':a},{'action':a1}],
         'batching20':{'D0_action':a,'D0_schedule_unchanged':True}}
    return s,a,c,composed,ans

def evaluator(costs):
    def score(s,a,m,c,deadline=None):
        k=('remote' if a['placement']['p']==1 else 'home','mixed' if a['caps'][0]==1024 else 'fixed')
        v=costs[k]
        return {'rankable':v is not None,'sum_remaining_jct_ms':v,'cpu_wall_ms':.01}
    return score

class FeedbackTests(unittest.TestCase):
    def test_candidate_caps_depend_on_destination(self):
        s,a,c,co,ans=packet();other=P.distinct_alternative(s,c,a,ans['evaluations'])
        self.assertEqual(choose_caps(s,a,MODEL,c,'mixed_1024')[0],[1024,4096])
        self.assertEqual(choose_caps(s,other,MODEL,c,'mixed_1024')[0],[4096,4096])
    def test_complete_packet_selects_better_route(self):
        s,a,c,co,ans=packet()
        q=P.feedback(s,MODEL,c,ans,co,time.monotonic()+1,evaluator({('home','mixed'):100,('home','fixed'):110,('remote','fixed'):50}))
        self.assertTrue(q['joint21']['four_cells_complete']);self.assertEqual(q['action']['placement']['p'],1)
        self.assertEqual(q['action']['order'],a['order']);self.assertEqual(q['action']['admit'],a['admit'])
    def test_composition_wins_ties(self):
        s,a,c,co,ans=packet()
        q=P.feedback(s,MODEL,c,ans,co,time.monotonic()+1,evaluator({('home','mixed'):100,('home','fixed'):100,('remote','fixed'):100}))
        self.assertEqual(action_key(q['action']),action_key(co))
    def test_incomplete_never_wins(self):
        s,a,c,co,ans=packet()
        q=P.feedback(s,MODEL,c,ans,co,time.monotonic()+1,evaluator({('home','mixed'):100,('home','fixed'):None,('remote','fixed'):0}))
        self.assertFalse(q['joint21']['four_cells_complete']);self.assertEqual(q['action'],co)
    def test_expired_uses_C(self):
        s,a,c,co,ans=packet();q=P.feedback(s,MODEL,c,ans,co,time.monotonic()-1)
        self.assertEqual(q['action'],co)
    def test_no_alternative_no_search(self):
        s,a,c,co,ans=packet();ans['evaluations']=[{'action':a}]
        def fail(*args,**kw):raise AssertionError('should not score')
        q=P.feedback(s,MODEL,c,ans,co,time.monotonic()+1,fail);self.assertEqual(q['joint21']['feedback_calls'] if 'feedback_calls' in q['joint21'] else q['joint21']['scores'],[])
    def test_unknown_cache_does_not_cause_throttle(self):
        s,a,c,co,ans=packet();s['cache_unknown_count']=1
        q=P.feedback(s,MODEL,c,ans,co,time.monotonic()+1);self.assertEqual(q['action'],co)
    def test_no_future_data_used(self):
        s,a,c,co,ans=packet();s['nodes']['p']['gold_answer']='SECRET';s['nodes']['p']['true_future_length']=99999
        q=P.feedback(s,MODEL,c,ans,co,time.monotonic()+1,evaluator({('home','mixed'):100,('home','fixed'):110,('remote','fixed'):50}))
        self.assertEqual(q['action']['placement']['p'],1)
    def test_inputs_not_mutated(self):
        s,a,c,co,ans=packet();before=copy.deepcopy((s,a,c,co,ans))
        P.feedback(s,MODEL,c,ans,co,time.monotonic()+1,evaluator({('home','mixed'):100,('home','fixed'):110,('remote','fixed'):50}))
        self.assertEqual((s,a,c,co,ans),before)
    def test_D0_output_matches_old_wrapper(self):
        s,a,c=fixture();cc=dict(c,joint21_method='D',joint21_fixed_cap=4096)
        x=P.process_plan(copy.deepcopy(s),MODEL,cc,'D',time.monotonic()+2)
        y=old_composition(copy.deepcopy(s),MODEL,dict(c,batching20_policy='fixed_4096'),'D',time.monotonic()+2)
        self.assertEqual(x['action'],y['action'])
    def test_C_matches_old_composition(self):
        s,a,c=fixture();cc=dict(c,joint21_method='C')
        x=P.process_plan(copy.deepcopy(s),MODEL,cc,'D',time.monotonic()+2)
        y=old_composition(copy.deepcopy(s),MODEL,dict(c,batching20_policy='mixed_1024',batching20_output_priors={}),'D',time.monotonic()+2)
        self.assertEqual(x['action'],y['action'])
    def test_source_call_not_given_new_configuration(self):
        s,a,c=fixture();c.update(joint21_method='D',joint21_fixed_cap=4096,joint21_feedback_ms=8.)
        with patch.object(P,'composition_plan',return_value={'action':a}) as call:P.process_plan(s,MODEL,c,'D',time.monotonic()+1)
        self.assertFalse(any(k.startswith('joint21') for k in call.call_args.args[2]))
    def test_projection_cannot_change_admission(self):
        s,a,c,co,ans=packet();s['capacity_blocks'][1]=1
        self.assertIsNone(P.distinct_alternative(s,c,a,ans['evaluations']))
    def test_bindings_restore_on_error(self):
        import joint18v2.client as client
        old=client.process_plan,client.compare_iteration,client.stream
        with self.assertRaises(ValueError):
            with bindings():raise ValueError('fixture')
        self.assertEqual((client.process_plan,client.compare_iteration,client.stream),old)
