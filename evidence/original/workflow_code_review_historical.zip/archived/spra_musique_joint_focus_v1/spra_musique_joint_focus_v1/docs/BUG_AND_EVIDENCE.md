# 本次bug与证据分层

## 收到的材料

用户最后上传的是其他GPT的分析建议，没有`ONE_BATCH_EVIDENCE`实体。另有此前已交付源码包和阶段复算归档。本地没有GPU39连接，没有读取实际R4失败迭代。因此不宣称现场唯一根因已确定。

## 已直接核对的源码

`spra_stage19_musique_joint_v1/joint18v2/batchcheck.py`:

```
take=min(remaining,room//block*block)
```

`vLLM v0.6.3 / vllm/core/scheduler.py / _get_num_new_tokens`:

```
if remaining_token_budget < num_new_tokens:
    num_new_tokens = (remaining_token_budget // block_size) * block_size
```

官方来源（2026-10-10读取）：
https://raw.githubusercontent.com/vllm-project/vllm/v0.6.3/vllm/core/scheduler.py

参考是公开版本，不声称它与目标整个wheel字节完全一致。目标既有hook哈希与源码合同继续校验；后端不更换。

## 精确反例

remaining=13、available=1024：原检查器和正确规则都是13，因此附件这个例子不是现有公式的反例。

remaining=13、available=13：原检查器0；正确13。

remaining=31、available=31：原检查器16；正确31。

这种available可由total减已有decode和前面prefill后产生，不要求把配置cap改成非16倍数。本包测试在total4096、cap4096、一个decode和两个prefill下复现。

## 不属于本次已定位结论

- 未看到现场失败迭代，不能认定一定是上面的分支。
- `free_blocks_before`实际上在原schedule返回后读取，不能证明调用之前有多少内存余量。本包不使用它解释合法分配。
- 零抢占不意味着所有原生allocator分支都已由简化预测覆盖。
- 没有将不一致归为允许误差，也没有把源scheduler输出回填进预测。

## 自动验收分类

`matched_unchanged`：独立预测仍匹配。

`matched_tail_rule_correction`：旧预测不匹配，修正后恰好匹配，且其他不变量通过。

`unresolved_prediction_mismatch`：没有被这次修正解释，停止。

`invariant_violation`：预算/阶段/计数错误，停止。

`unsupported_preemption_or_swap`或`insufficient_or_malformed_evidence`：不予接受，不伪装为合法覆盖。

旧条件只读重核不改变任何JCT；新条件在独立核对后才打印最终接受。旧36格不由新批次补成“完成确认”。
