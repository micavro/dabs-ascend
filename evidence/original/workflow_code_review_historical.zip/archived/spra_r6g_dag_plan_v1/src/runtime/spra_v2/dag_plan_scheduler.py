from __future__ import annotations
import itertools,time
from collections import defaultdict
from dataclasses import dataclass

def lcp(a,b):
    n=min(len(a),len(b));i=0
    while i<n and a[i]==b[i]:i+=1
    return i

@dataclass
class Req:
    key:str
    workflow_id:str
    node:str
    tokens:tuple[int,...]
    out_tokens:int
    tail_ms:float

@dataclass
class Active:
    key:str
    workflow_id:str
    node:str
    replica:int
    start_ns:int
    base_ms:float
    tail_ms:float
    start_concurrency:int

class SlowdownCurve:
    def __init__(self,points:dict[int,float]):
        if 1 not in points: raise ValueError("need concurrency=1 calibration")
        base=float(points[1])
        self.points=sorted((int(k),max(1.0,float(v)/base)) for k,v in points.items())

    def __call__(self,k:int)->float:
        k=max(1,int(k));pts=self.points
        if k<=pts[0][0]:return pts[0][1]
        for (x0,y0),(x1,y1) in zip(pts,pts[1:]):
            if k<=x1:
                a=(k-x0)/max(1,x1-x0);return y0+a*(y1-y0)
        x0,y0=pts[-2];x1,y1=pts[-1]
        slope=(y1-y0)/max(1,x1-x0)
        return max(y1,y1+slope*(k-x1))

class DAGPlanScheduler:
    """Event-set DAG planner.

    Key difference from R6F:
    - every dependency-release set is planned atomically;
    - candidate cost uses empirically measured concurrency slowdown rather than
      serially summing standalone request latencies;
    - complete ready-set assignments are enumerated (4^|F|; |F|<=3 here);
    - objective is sum of predicted remaining workflow completion times,
      including currently active workflows and DAG downstream tails.

    No affinity/load weight is tuned.
    """
    def __init__(self,nreplicas,prefill_ms_per_token,decode_ms_per_token,slowdown,status_fn):
        self.n=nreplicas;self.prefill=float(prefill_ms_per_token);self.decode=float(decode_ms_per_token)
        self.slowdown=slowdown;self.status_fn=status_fn
        self.cached=[[] for _ in range(nreplicas)]
        self.active:dict[str,Active]={}
        self.decisions=[];self.plan_events=[]

    def match(self,r,tokens):
        best=0
        for old in self.cached[r]:best=max(best,lcp(tokens,old))
        return best

    def base_service(self,r,req):
        hit=self.match(r,req.tokens)
        return self.prefill*max(1,len(req.tokens)-hit)+self.decode*req.out_tokens,hit

    def live_counts(self):
        z=[self.status_fn(r) for r in range(self.n)]
        return [max(0,int(x.get("running") or 0)+int(x.get("waiting") or 0)) for x in z],z

    def reference(self,ready,counts):
        # EFT-like reference under the same concurrency model used by candidates.
        a={};extra=[0]*self.n
        for q in ready:
            vals=[]
            for r in range(self.n):
                b,_=self.base_service(r,q)
                k=counts[r]+extra[r]+1
                vals.append((b*self.slowdown(k),r))
            _,r=min(vals);a[q.key]=r;extra[r]+=1
        return a

    def evaluate(self,ready,assignment,counts):
        now=time.perf_counter_ns()
        new_count=[0]*self.n
        for q in ready:new_count[assignment[q.key]]+=1
        wf=defaultdict(float)
        # Existing active calls: adding requests slows their remaining service.
        for a in self.active.values():
            elapsed=(now-a.start_ns)/1e6
            old_sd=self.slowdown(max(1,a.start_concurrency))
            rem_base=max(0.0,a.base_ms-elapsed/max(old_sd,1e-9))
            k=max(1,counts[a.replica]+new_count[a.replica])
            rem=rem_base*self.slowdown(k)
            wf[a.workflow_id]=max(wf[a.workflow_id],rem+a.tail_ms)
        # Newly ready set: requests assigned to the same replica share one
        # concurrency level rather than being serialized.
        completions={}
        for q in ready:
            r=assignment[q.key];b,_=self.base_service(r,q)
            k=max(1,counts[r]+new_count[r])
            c=b*self.slowdown(k)
            completions[q.key]=c
            wf[q.workflow_id]=max(wf[q.workflow_id],c+q.tail_ms)
        return sum(wf.values()),completions

    def plan(self,ready:list[Req]):
        if not ready:raise ValueError("empty ready set")
        t0=time.perf_counter_ns();counts,live=self.live_counts()
        ref=self.reference(ready,counts)
        ref_phi,ref_comp=self.evaluate(ready,ref,counts)
        wfrem=defaultdict(float)
        for q in ready:wfrem[q.workflow_id]=max(wfrem[q.workflow_id],ref_comp[q.key]+q.tail_ms)
        slack={q.key:wfrem[q.workflow_id]-ref_comp[q.key]-q.tail_ms for q in ready}

        # Complete enumeration is cheap here: max ready-set width is 3 => 64.
        best=dict(ref);best_phi=ref_phi;evaluated=0
        for tup in itertools.product(range(self.n),repeat=len(ready)):
            cand={q.key:r for q,r in zip(ready,tup)}
            phi,_=self.evaluate(ready,cand,counts);evaluated+=1
            if phi<best_phi-1e-9:
                best_phi=phi;best=cand

        wall=(time.perf_counter_ns()-t0)/1e6
        evt={"ready":len(ready),"evaluated":evaluated,"reference_phi_ms":ref_phi,
             "returned_phi_ms":best_phi,
             "predicted_gain_pct":100*(ref_phi-best_phi)/ref_phi if ref_phi else 0.0,
             "planner_wall_ms":wall,"live_counts":counts,
             "assignment":dict(best),"reference_assignment":dict(ref)}
        self.plan_events.append(evt)
        out={}
        for q in ready:
            r=best[q.key];b,hit=self.base_service(r,q);k=max(1,counts[r]+sum(best[x.key]==r for x in ready))
            out[q.key]={"replica":r,"base_ms":b,"hit":hit,"slack_ms":slack[q.key],
                        "predicted_ms":b*self.slowdown(k),"start_concurrency":k,
                        "reference_phi_ms":ref_phi,"predicted_phi_ms":best_phi,
                        "planner_wall_ms":wall}
        return out

    def start(self,q:Req,choice):
        self.active[q.key]=Active(q.key,q.workflow_id,q.node,choice["replica"],time.perf_counter_ns(),
                                  choice["base_ms"],q.tail_ms,choice["start_concurrency"])
        self.decisions.append({"key":q.key,"workflow_id":q.workflow_id,"node":q.node,**choice})

    def finish(self,q:Req,replica:int):
        self.active.pop(q.key,None)
        self.cached[replica].append(tuple(q.tokens))
        if len(self.cached[replica])>512:self.cached[replica]=self.cached[replica][-512:]
