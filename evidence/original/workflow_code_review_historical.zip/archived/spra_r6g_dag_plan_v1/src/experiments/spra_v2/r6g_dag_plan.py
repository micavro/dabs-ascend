from __future__ import annotations
import argparse,asyncio,json,math,os,random,statistics as st,tempfile,time,sys
from collections import Counter
from pathlib import Path
import httpx

ROOT=Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from src.runtime.spra_v2.dag_plan_scheduler import DAGPlanScheduler,SlowdownCurve,Req

RUNTIME=Path("/home/wmy/sci/spra_core_exp/joint_e1")
MODEL="Qwen2.5-1.5B-Instruct"
ENDPOINTS=[f"http://127.0.0.1:{8000+i}" for i in range(4)]
PODS=[f"spra-vllm-{i}" for i in range(4)]
RATES=(8.0,12.0);BLOCKS=(1,2,3,4);WORKFLOWS=32;BUDGET=2048
OUTTOK={"root":32,"c1":160,"c2":128,"c3":96,"s1":48,"s2":48,"join":64}
SUCC={"root":["c1","s1","s2"],"c1":["c2"],"c2":["c3"],"c3":["join"],"s1":["join"],"s2":["join"],"join":[]}
SHARED=("Agent workflow shared context. This long context is intentionally identical across all "
        "nodes of one workflow so that vLLM automatic prefix caching can reuse previously computed "
        "KV blocks. It describes scheduling state, dependency readiness, tool outputs, observations, "
        "constraints, intermediate facts, and persistent agent memory. ")

class ConditionTransportError(RuntimeError):pass

def pct(xs,q):
    a=sorted(xs);p=(len(a)-1)*q;lo=int(math.floor(p));hi=int(math.ceil(p))
    return a[lo] if lo==hi else a[lo]*(hi-p)+a[hi]*(p-lo)

def atomic(path,data):
    fd,tmp=tempfile.mkstemp(prefix=path.name+".",dir=str(path.parent));os.close(fd)
    Path(tmp).write_text(json.dumps(data));os.replace(tmp,path)

def status(runtime,r):
    try:return json.loads((runtime/"backend"/f"spra-vllm-{r}.status.json").read_text())
    except:return {}

def validate(runtime):
    gs=[]
    for r in range(4):
        s=status(runtime,r)
        assert s.get("hook_version")=="spra-v2-telemetry-1",s
        assert int(s.get("num_gpu_blocks") or 0)==4096,s
        assert s.get("prefix_caching") is True,s
        gs.append(s.get("nvidia_visible_devices"))
    assert len(set(gs))==4

async def endpoints_healthy(timeout_s=3):
    async with httpx.AsyncClient(timeout=httpx.Timeout(timeout_s,connect=timeout_s),
                                 limits=httpx.Limits(max_connections=8,max_keepalive_connections=0)) as c:
        out=[]
        for ep in ENDPOINTS:
            try:out.append((await c.get(ep+"/health")).status_code==200)
            except Exception:out.append(False)
        return out

async def wait_idle(runtime,timeout_s=180):
    end=time.monotonic()+timeout_s
    while True:
        z=[status(runtime,r) for r in range(4)]
        if all(int(x.get("running") or 0)==0 and int(x.get("waiting") or 0)==0 for x in z):return
        if time.monotonic()>=end:raise RuntimeError("backend did not drain")
        await asyncio.sleep(.25)

def arrivals(rate,block):
    rng=random.Random(int(rate)*10000+block*131);gap=1/rate;xs=[]
    for i in range(WORKFLOWS):xs.append(max(0.0,i*gap+(rng.random()-.5)*.20*gap))
    xs.sort();xs[0]=0.0;return xs

def msgs(epoch,wid,node):
    shared=(f"CACHE_EPOCH={epoch}; WORKFLOW_PREFIX={wid};\n"+SHARED*30)
    return [{"role":"system","content":shared+f"\nCurrent node type: {node}. This is a controlled serving workload. Generate the exact bounded number of tokens requested by the API."},
            {"role":"user","content":f"workflow={wid}; node={node}. Continue deterministic synthetic agent reasoning about dependencies, scheduling, cached context, and intermediate state."}]

async def tokenize(client,m):
    r=await client.post(ENDPOINTS[0]+"/tokenize",json={"model":MODEL,"messages":m,"add_generation_prompt":True})
    r.raise_for_status();return tuple(r.json()["tokens"])

async def infer(client,r,m,out_tokens):
    p={"model":MODEL,"messages":m,"temperature":0.0,"seed":0,
       "max_tokens":out_tokens,"min_tokens":out_tokens,"ignore_eos":True,"stream":False}
    t=time.perf_counter_ns()
    try:
        x=await client.post(ENDPOINTS[r]+"/v1/chat/completions",json=p)
        t2=time.perf_counter_ns();x.raise_for_status();o=x.json();u=o.get("usage") or {}
        return {"latency_ms":(t2-t)/1e6,"request_id":o.get("id"),
                "prompt_tokens":u.get("prompt_tokens"),"output_tokens":u.get("completion_tokens")}
    except (httpx.ReadError,httpx.ConnectError,httpx.RemoteProtocolError,
            httpx.WriteError,httpx.PoolTimeout,httpx.ReadTimeout) as e:
        raise ConditionTransportError(f"replica={r} {type(e).__name__}:{e}") from e

async def calibrate(client,runtime):
    atomic(runtime/"control.json",{"case":"R6G/calibration","token_budget":BUDGET})
    async def one(label,reps,out):
        m=[{"role":"system","content":f"CAL={label}; "+("calibration context "*reps)},
           {"role":"user","content":"Perform bounded calibration inference."}]
        tok=await tokenize(client,m);x=await infer(client,0,m,out);return len(tok),x["latency_ms"]
    a1=await one("A1",80,1);a2=await one("A2",320,1)
    b1=await one("B1",200,16);b2=await one("B2",200,128)
    pre=max(.001,(a2[1]-a1[1])/max(1,a2[0]-a1[0]))
    dec=max(.001,(b2[1]-b1[1])/112.0)

    # Measured continuous-batching slowdown curve. Unique leading labels prevent APC.
    curve={}
    for k in (1,8,16,24):
        ms=[]
        reqs=[]
        for i in range(k):
            m=[{"role":"system","content":f"R6G-CONC-{k}-{i}; "+SHARED*30},
               {"role":"user","content":"Run fixed concurrency calibration."}]
            reqs.append(infer(client,0,m,64))
        xs=await asyncio.gather(*reqs)
        curve[k]=st.mean(x["latency_ms"] for x in xs)
        await asyncio.sleep(.2)
    await wait_idle(runtime)
    return {"prefill_ms_per_token":pre,"decode_ms_per_token":dec,
            "slowdown_raw_ms":curve,
            "points":{"a1":a1,"a2":a2,"b1":b1,"b2":b2}}

def dynamic_tail(sched,token_cache,i,node):
    memo={}
    def visit(n):
        if n in memo:return memo[n]
        vals=[]
        for child in SUCC[n]:
            q=Req(f"tail/{i}/{child}",f"wf{i:03d}",child,token_cache[(i,child)],OUTTOK[child],0)
            best=min(sched.base_service(r,q)[0] for r in range(4))
            vals.append(best+visit(child))
        memo[n]=max(vals,default=0.0);return memo[n]
    return visit(node)

async def execute_req(q,choice,sched,client,message,nodes):
    sched.start(q,choice)
    try:x=await infer(client,choice["replica"],message,q.out_tokens)
    except Exception:
        # Remove from shadow active set on invalid attempt.
        sched.active.pop(q.key,None);raise
    sched.finish(q,choice["replica"])
    nodes.append({"workflow_id":q.workflow_id,"node_id":q.node,"replica":choice["replica"],
                  "latency_ms":x["latency_ms"],"prompt_tokens":x["prompt_tokens"],
                  "output_tokens":x["output_tokens"],"matched_tokens":choice["hit"],
                  "slack_ms":choice["slack_ms"],"predicted_ms":choice["predicted_ms"],
                  "planner_wall_ms":choice["planner_wall_ms"]})
    return x

async def workflow(i,off,epoch,sched,token_cache,client,nodes,wfs):
    await asyncio.sleep(off);wid=f"wf{i:03d}";start=time.perf_counter_ns()

    def req(name):
        return Req(f"{wid}/{name}",wid,name,token_cache[(i,name)],OUTTOK[name],
                   dynamic_tail(sched,token_cache,i,name))

    # Root release event.
    qr=req("root");plan=sched.plan([qr])
    await execute_req(qr,plan[qr.key],sched,client,msgs(epoch,wid,"root"),nodes)

    # Atomic dependency-release event: c1, s1, s2 become ready together.
    ready=[req("c1"),req("s1"),req("s2")]
    plan=sched.plan(ready)
    by={q.node:q for q in ready}
    tasks={n:asyncio.create_task(execute_req(by[n],plan[by[n].key],sched,client,msgs(epoch,wid,n),nodes))
           for n in ("c1","s1","s2")}
    try:
        await tasks["c1"]
        q2=req("c2");p2=sched.plan([q2])
        await execute_req(q2,p2[q2.key],sched,client,msgs(epoch,wid,"c2"),nodes)
        q3=req("c3");p3=sched.plan([q3])
        await execute_req(q3,p3[q3.key],sched,client,msgs(epoch,wid,"c3"),nodes)
        await asyncio.gather(tasks["s1"],tasks["s2"])
        qj=req("join");pj=sched.plan([qj])
        await execute_req(qj,pj[qj.key],sched,client,msgs(epoch,wid,"join"),nodes)
    except Exception:
        for t in tasks.values():
            if not t.done():t.cancel()
        await asyncio.gather(*tasks.values(),return_exceptions=True)
        raise
    wfs.append({"workflow_id":wid,"jct_ms":(time.perf_counter_ns()-start)/1e6})

async def condition(rate,block,attempt,suite,runtime,cal):
    case=f"R6G/L{rate:g}/B{block}/A{attempt}";epoch=f"R6G-{rate:g}-{block}-A{attempt}"
    atomic(runtime/"control.json",{"case":case,"token_budget":BUDGET})
    out=suite/f"L{rate:g}_B{block}_A{attempt}";out.mkdir()
    limits=httpx.Limits(max_connections=384,max_keepalive_connections=96,keepalive_expiry=1.0)
    nodes=[];wfs=[]
    async with httpx.AsyncClient(timeout=httpx.Timeout(240,connect=5),limits=limits) as client:
        keys=[];reqs=[]
        for i in range(WORKFLOWS):
            wid=f"wf{i:03d}"
            for n in OUTTOK:
                keys.append((i,n));reqs.append(tokenize(client,msgs(epoch,wid,n)))
        vals=await asyncio.gather(*reqs);cache=dict(zip(keys,vals))
        sched=DAGPlanScheduler(4,cal["prefill_ms_per_token"],cal["decode_ms_per_token"],
                               SlowdownCurve(cal["slowdown_raw_ms"]),lambda r:status(runtime,r))
        tasks=[asyncio.create_task(workflow(i,arrivals(rate,block)[i],epoch,sched,cache,client,nodes,wfs))
               for i in range(WORKFLOWS)]
        t0=time.perf_counter_ns()
        try:await asyncio.gather(*tasks)
        except Exception:
            for t in tasks:
                if not t.done():t.cancel()
            await asyncio.gather(*tasks,return_exceptions=True);raise
        t1=time.perf_counter_ns()
    if len(wfs)!=WORKFLOWS or len(nodes)!=WORKFLOWS*7:
        raise RuntimeError(f"incomplete condition workflows={len(wfs)} nodes={len(nodes)}")
    with (out/"nodes.jsonl").open("w") as f:
        for x in nodes:f.write(json.dumps(x,separators=(",",":"))+"\n")
    with (out/"workflows.jsonl").open("w") as f:
        for x in wfs:f.write(json.dumps(x,separators=(",",":"))+"\n")
    (out/"decisions.json").write_text(json.dumps(sched.decisions,indent=2)+"\n")
    (out/"plan_events.json").write_text(json.dumps(sched.plan_events,indent=2)+"\n")
    j=[x["jct_ms"] for x in wfs];ot=sum(int(x["output_tokens"] or 0) for x in nodes);dur=(t1-t0)/1e9
    reps=Counter(x["replica"] for x in nodes);pe=sched.plan_events
    widths=Counter(x["ready"] for x in pe)
    s={"arrival_rate":rate,"block":block,"attempt":attempt,"method":"DAG-Plan",
       "mean_jct_ms":st.mean(j),"p95_jct_ms":pct(j,.95),"duration_s":dur,
       "output_tokens":ot,"output_tokens_s":ot/dur,
       "replica_assignments":{str(r):reps.get(r,0) for r in range(4)},
       "assignment_imbalance":max(reps.get(r,0) for r in range(4))-min(reps.get(r,0) for r in range(4)),
       "mean_planner_wall_ms":st.mean(x["planner_wall_ms"] for x in pe),
       "p95_planner_wall_ms":pct([x["planner_wall_ms"] for x in pe],.95),
       "mean_predicted_gain_pct":st.mean(x["predicted_gain_pct"] for x in pe),
       "ready_width_hist":{str(k):v for k,v in sorted(widths.items())},
       "width3_events":widths.get(3,0)}
    (out/"summary.json").write_text(json.dumps(s,indent=2)+"\n");return s

async def atomic_condition(rate,block,suite,runtime,cal):
    invalid=[]
    for attempt in range(1,4):
        if not all(await endpoints_healthy()):
            await wait_idle(runtime);await asyncio.sleep(.75);continue
        try:return await condition(rate,block,attempt,suite,runtime,cal)
        except Exception as e:
            rec={"attempt":attempt,"error":f"{type(e).__name__}:{e}"}
            invalid.append(rec);(suite/f"INVALID_L{rate:g}_B{block}_A{attempt}.json").write_text(json.dumps(rec,indent=2)+"\n")
            await wait_idle(runtime);await asyncio.sleep(.75)
    raise RuntimeError(f"condition failed rate={rate} block={block}: {invalid}")

def baselines():
    z={}
    for key,ptr,fn in [
        ("R6D","r6d_confirm_latest.txt","aggregate.json"),
        ("Preble","r6e_preble_latest.txt","aggregate.json"),
        ("R6F","r6f_joint_latest.txt","aggregate.json")]:
        p=ROOT/"metadata/spra_v2"/ptr
        if p.exists():
            d=Path(p.read_text().strip())/fn
            if d.exists():z[key]=json.loads(d.read_text())
    return z

async def run(args):
    runtime=args.runtime.resolve();validate(runtime)
    import fcntl
    lf=(runtime/"experiment.lock").open("a")
    try:fcntl.flock(lf,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit("runtime lock busy")
    old=json.loads((runtime/"control.json").read_text())
    stamp=time.strftime("%Y%m%dT%H%M%SZ",time.gmtime())
    suite=ROOT/"runs/spra_v2"/f"R6G_DAG_PLAN_{stamp}_{os.getpid()}";suite.mkdir(parents=True)
    try:
        await wait_idle(runtime)
        async with httpx.AsyncClient(timeout=httpx.Timeout(240,connect=5),
                                     limits=httpx.Limits(max_connections=128,max_keepalive_connections=32)) as c:
            cal=await calibrate(c,runtime)
        (suite/"calibration.json").write_text(json.dumps(cal,indent=2)+"\n")
        rows=[]
        for rate in RATES:
            for block in BLOCKS:
                print(f"CASE_START rate={rate:g} block={block} method=DAG-Plan",flush=True)
                x=await atomic_condition(rate,block,suite,runtime,cal);rows.append(x)
                print("CASE_DONE "+json.dumps(x,sort_keys=True),flush=True)
                atomic(runtime/"control.json",{"case":"R6G/idle-fixed","token_budget":BUDGET});await asyncio.sleep(.4)
    finally:
        atomic(runtime/"control.json",old);fcntl.flock(lf,fcntl.LOCK_UN);lf.close()
    base=baselines();agg={}
    for rate in RATES:
        xs=[x for x in rows if x["arrival_rate"]==rate];mj=st.mean(x["mean_jct_ms"] for x in xs)
        v={"repeats":4,"mean_jct_ms":mj,
           "mean_p95_jct_ms":st.mean(x["p95_jct_ms"] for x in xs),
           "mean_output_tokens_s":st.mean(x["output_tokens_s"] for x in xs),
           "mean_planner_wall_ms":st.mean(x["mean_planner_wall_ms"] for x in xs),
           "mean_predicted_gain_pct":st.mean(x["mean_predicted_gain_pct"] for x in xs)}
        k=str(rate)
        if "R6D" in base and k in base["R6D"]:
            for m,b in base["R6D"][k].items():
                v[f"gain_vs_{m}_pct"]=100*(b["mean_jct_ms"]-mj)/b["mean_jct_ms"]
        if "Preble" in base and k in base["Preble"]:
            b=base["Preble"][k]["Preble"]["mean_jct_ms"]
            v["gain_vs_Preble_pct"]=100*(b-mj)/b
        if "R6F" in base and k in base["R6F"]:
            b=base["R6F"][k]["DAG-Joint"]["mean_jct_ms"]
            v["gain_vs_R6F_pct"]=100*(b-mj)/b
        agg[k]={"DAG-Plan":v}
    (suite/"aggregate.json").write_text(json.dumps(agg,indent=2)+"\n")
    (ROOT/"metadata/spra_v2/r6g_dag_plan_latest.txt").write_text(str(suite)+"\n")
    print("RESULT="+str(suite));print("MEASURED_RUNS=8/8");print("AGGREGATE="+json.dumps(agg,sort_keys=True))

def selftest():
    assert sum(OUTTOK.values())==576 and len(SUCC["root"])==3
    c=SlowdownCurve({1:10,8:20,16:30,24:40});assert c(1)==1 and c(8)>=1
    print("SELFTEST_OK r6g atomic_ready_set=True measured_slowdown=True runs=8 gpu_requests=0")

def plan():
    print("R6G=DAG-Plan; structural correction of R6F, not score tuning")
    print("READY_EVENT=root then atomic {c1,s1,s2}, then c2, c3, join")
    print("CANDIDATES=complete 4^|ready-set| enumeration; max 64")
    print("OBJECTIVE=sum predicted remaining workflow completion times")
    print("SERVICE_MODEL=local prefill/decode calibration + measured concurrency slowdown at 1/8/16/24")
    print("BATCHING=FIXED 2048")
    print("RUNS=8 exact R6D arrival seeds")
    print("STOP_RULE=after R6G, freeze scheduler result; no further score/margin tuning")

def report():
    p=ROOT/"metadata/spra_v2/r6g_dag_plan_latest.txt";d=Path(p.read_text().strip())
    print("RESULT="+str(d));print((d/"aggregate.json").read_text())

def main():
    p=argparse.ArgumentParser();sp=p.add_subparsers(dest="cmd",required=True)
    sp.add_parser("selftest");sp.add_parser("plan");sp.add_parser("report")
    q=sp.add_parser("run");q.add_argument("--runtime",type=Path,default=RUNTIME)
    a=p.parse_args()
    if a.cmd=="selftest":selftest()
    elif a.cmd=="plan":plan()
    elif a.cmd=="report":report()
    else:asyncio.run(run(a))
if __name__=="__main__":main()
