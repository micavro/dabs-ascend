from __future__ import annotations
import argparse,asyncio,csv,hashlib,json,math,os,random,re,statistics as st,tempfile,time
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
import httpx

ROOT=Path(__file__).resolve().parents[3]
RUNTIME=Path("/home/wmy/sci/spra_core_exp/joint_e1")
MODEL="Qwen2.5-1.5B-Instruct"
ENDPOINTS=[f"http://127.0.0.1:{8000+i}" for i in range(4)]
PODS=[f"spra-vllm-{i}" for i in range(4)]
METHODS=("RR","EFT","Affinity","SPRA")
RATES=(8.0,12.0)
REPEATS=4
WORKFLOWS=32
BATCH_BUDGET=2048
OUTTOK={"root":32,"c1":160,"c2":128,"c3":96,"s1":48,"s2":48,"join":64}
CRITICAL={"root":True,"c1":True,"c2":True,"c3":True,"s1":False,"s2":False,"join":True}
CPR={"root":5,"c1":4,"c2":3,"c3":2,"s1":2,"s2":2,"join":1}
WORK_UNITS={n:900+10*t for n,t in OUTTOK.items()}
# Frozen before confirmatory execution. No post-result tuning.
CRITICAL_AFFINITY_MARGIN=3.0
SIDE_AFFINITY_MARGIN=0.75

SHARED=(
    "Agent workflow shared context. This long context is intentionally identical across all "
    "nodes of one workflow so that vLLM automatic prefix caching can reuse previously computed "
    "KV blocks. It describes scheduling state, dependency readiness, tool outputs, observations, "
    "constraints, intermediate facts, and persistent agent memory. "
)
METRIC_RE=re.compile(r'^vllm:gpu_prefix_cache_hit_rate(?:\{[^}]*\})?\s+([-+0-9.eE]+)\s*$',re.M)

def pct(xs,q):
    if not xs:return None
    a=sorted(xs);p=(len(a)-1)*q;lo=int(math.floor(p));hi=int(math.ceil(p))
    return a[lo] if lo==hi else a[lo]*(hi-p)+a[hi]*(p-lo)

def atomic_json(path:Path,data:dict):
    fd,tmp=tempfile.mkstemp(prefix=path.name+".",dir=str(path.parent));os.close(fd)
    Path(tmp).write_text(json.dumps(data));os.replace(tmp,path)

def make_arrivals(n,rate,seed):
    rng=random.Random(seed);gap=1.0/rate;xs=[]
    for i in range(n):
        xs.append(max(0.0,i*gap+(rng.random()-.5)*.20*gap))
    xs.sort();xs[0]=0.0
    return xs

def read_status(runtime:Path,r:int):
    try:return json.loads((runtime/"backend"/f"spra-vllm-{r}.status.json").read_text())
    except Exception:return {}

def validate(runtime:Path):
    ctl=json.loads((runtime/"control.json").read_text())
    if int(ctl.get("token_budget") or -1)!=BATCH_BUDGET:
        raise RuntimeError(f"need token_budget={BATCH_BUDGET}, got {ctl}")
    g=[]
    for i in range(4):
        s=read_status(runtime,i)
        if s.get("hook_version")!="spra-v2-telemetry-1":raise RuntimeError(f"pod{i}:hook")
        if int(s.get("num_gpu_blocks") or 0)!=4096:raise RuntimeError(f"pod{i}:blocks")
        if not s.get("prefix_caching"):raise RuntimeError(f"pod{i}:prefix")
        g.append(s.get("nvidia_visible_devices"))
    if len(set(g))!=4:raise RuntimeError("GPU UUIDs not unique")

def backend_rows(runtime,case,pod):
    rows=[]
    for p in sorted((runtime/"backend").glob(f"{pod}.*.jsonl")):
        for line in p.read_text(errors="ignore").splitlines():
            try:x=json.loads(line)
            except:continue
            if x.get("event")=="iteration" and x.get("case")==case:rows.append(x)
    rows.sort(key=lambda x:(x.get("ts_wall_ns") or 0,x.get("iteration") or 0))
    return rows

async def metric_snapshot(client,r):
    try:
        x=await client.get(ENDPOINTS[r]+"/metrics")
        m=METRIC_RE.search(x.text)
        return float(m.group(1)) if m else None
    except Exception:return None

def messages(epoch,wfid,node):
    shared=(f"CACHE_EPOCH={epoch}; WORKFLOW_PREFIX={wfid};\n"+SHARED*30)
    return [
        {"role":"system","content":shared+f"\nCurrent node type: {node}. Generate bounded deterministic serving work."},
        {"role":"user","content":f"workflow={wfid}; node={node}. Continue synthetic agent reasoning."},
    ]

async def infer(client,replica,msgs,out_tokens):
    payload={"model":MODEL,"messages":msgs,"temperature":0.0,"seed":0,
             "max_tokens":out_tokens,"min_tokens":out_tokens,"ignore_eos":True,"stream":False}
    t0=time.perf_counter_ns()
    try:
        r=await client.post(ENDPOINTS[replica]+"/v1/chat/completions",json=payload)
        t1=time.perf_counter_ns();r.raise_for_status();o=r.json();u=o.get("usage") or {}
        return {"status":"ok","request_id":o.get("id"),"latency_ms":(t1-t0)/1e6,
                "prompt_tokens":u.get("prompt_tokens"),"output_tokens":u.get("completion_tokens")}
    except Exception as e:
        return {"status":"error","request_id":None,"latency_ms":(time.perf_counter_ns()-t0)/1e6,
                "prompt_tokens":None,"output_tokens":None,"error":f"{type(e).__name__}:{e}"}

@dataclass
class Choice:
    replica:int;overhead_ms:float;affinity:bool;override:bool

class Dispatcher:
    def __init__(self,method,runtime):
        self.method=method;self.runtime=runtime;self.lock=asyncio.Lock();self.rr=0
        self.inflight=[0]*4;self.work=[0.0]*4;self.prefix_warm=[set() for _ in range(4)]
        self.decisions=[]

    def live(self,r):
        s=read_status(self.runtime,r);cap=max(1,float(s.get("num_gpu_blocks") or 4096))
        return {"running":int(s.get("running") or 0),"waiting":int(s.get("waiting") or 0),
                "kv_frac":float(s.get("kv_in_use_blocks") or 0)/cap,
                "inflight":self.inflight[r],"work":self.work[r]}

    def pressure(self,z):
        return (z["inflight"] + .75*z["running"] + 2.0*z["waiting"] +
                2.0*z["kv_frac"] + z["work"]/1500.0)

    async def choose(self,prefix_id,node):
        async with self.lock:
            t0=time.perf_counter_ns();snap={str(r):self.live(r) for r in range(4)}
            pressures={r:self.pressure(snap[str(r)]) for r in range(4)}
            best_any=min(range(4),key=lambda r:(pressures[r],r))
            warm=[r for r in range(4) if prefix_id in self.prefix_warm[r]]
            override=False
            if self.method=="RR":
                r=self.rr%4;self.rr+=1
            elif self.method=="EFT":
                score={}
                for x in range(4):
                    z=snap[str(x)]
                    score[x]=z["work"]+WORK_UNITS[node]+250*z["running"]+450*z["waiting"]
                r=min(range(4),key=lambda x:(score[x],x))
            elif self.method=="Affinity":
                pool=warm if warm else list(range(4))
                r=min(pool,key=lambda x:(pressures[x],x))
            elif self.method=="SPRA":
                if not warm:
                    r=best_any
                else:
                    best_warm=min(warm,key=lambda x:(pressures[x],x))
                    margin=CRITICAL_AFFINITY_MARGIN if CRITICAL[node] else SIDE_AFFINITY_MARGIN
                    if pressures[best_warm] <= pressures[best_any] + margin:
                        r=best_warm
                    else:
                        r=best_any;override=True
            else:raise ValueError(self.method)
            affinity=prefix_id in self.prefix_warm[r]
            self.inflight[r]+=1;self.work[r]+=WORK_UNITS[node]
            ov=(time.perf_counter_ns()-t0)/1e6
            self.decisions.append({"node":node,"critical":CRITICAL[node],"cpr":CPR[node],
                "prefix_id":prefix_id,"replica":r,"affinity_expected":affinity,
                "affinity_override_due_pressure":override,
                "decision_overhead_ms":ov,"pressures":pressures,"snapshot":snap})
            return Choice(r,ov,affinity,override)

    async def done(self,r,prefix_id,node):
        async with self.lock:
            self.inflight[r]-=1;self.work[r]-=WORK_UNITS[node];self.prefix_warm[r].add(prefix_id)

async def workflow(idx,arrival,epoch,disp,client,node_rows,wf_rows):
    await asyncio.sleep(arrival);wfid=f"wf{idx:03d}";prefix=wfid;start=time.perf_counter_ns()
    async def node(name):
        ch=await disp.choose(prefix,name)
        res=await infer(client,ch.replica,messages(epoch,wfid,name),OUTTOK[name])
        await disp.done(ch.replica,prefix,name)
        node_rows.append({"workflow_id":wfid,"node_id":name,"critical":CRITICAL[name],
                          "replica":ch.replica,"status":res["status"],"request_id":res["request_id"],
                          "latency_ms":res["latency_ms"],"prompt_tokens":res["prompt_tokens"],
                          "output_tokens":res["output_tokens"],"affinity_expected":ch.affinity,
                          "affinity_override_due_pressure":ch.override,
                          "decision_overhead_ms":ch.overhead_ms})
        return res
    root=await node("root")
    s1=asyncio.create_task(node("s1"));s2=asyncio.create_task(node("s2"))
    c1=await node("c1");c2=await node("c2");c3=await node("c3")
    a,b=await asyncio.gather(s1,s2);join=await node("join")
    end=time.perf_counter_ns();ok=all(x["status"]=="ok" for x in (root,c1,c2,c3,a,b,join))
    wf_rows.append({"workflow_id":wfid,"status":"ok" if ok else "error","jct_ms":(end-start)/1e6})

async def run_condition(method,rate,block,pos,idx,suite,runtime,arrivals):
    case=f"R6D/L{rate:g}/B{block}/P{pos}/{method}";epoch=f"R6D-{rate:g}-{block}-{idx}"
    atomic_json(runtime/"control.json",{"case":case,"token_budget":BATCH_BUDGET})
    out=suite/f"L{rate:g}_B{block}_P{pos}_{method}";out.mkdir()
    disp=Dispatcher(method,runtime);nodes=[];wfs=[]
    timeout=httpx.Timeout(240.0,connect=5.0)
    async with httpx.AsyncClient(timeout=timeout,limits=httpx.Limits(max_connections=512,max_keepalive_connections=128)) as client:
        before=await asyncio.gather(*(metric_snapshot(client,r) for r in range(4)))
        t0=time.perf_counter_ns()
        await asyncio.gather(*(workflow(i,arrivals[i],epoch,disp,client,nodes,wfs) for i in range(WORKFLOWS)))
        t1=time.perf_counter_ns()
        after=await asyncio.gather(*(metric_snapshot(client,r) for r in range(4)))
    await asyncio.sleep(.25)
    back={r:backend_rows(runtime,case,PODS[r]) for r in range(4)}
    for name,rows in (("nodes.jsonl",nodes),("workflows.jsonl",wfs)):
        with (out/name).open("w") as f:
            for x in rows:f.write(json.dumps(x,separators=(",",":"))+"\n")
    (out/"decisions.json").write_text(json.dumps(disp.decisions,indent=2)+"\n")
    for r,rows in back.items():
        with (out/f"backend_replica{r}.jsonl").open("w") as f:
            for x in rows:f.write(json.dumps(x,separators=(",",":"))+"\n")
    j=[x["jct_ms"] for x in wfs if x["status"]=="ok"];nl=[x["latency_ms"] for x in nodes if x["status"]=="ok"]
    reps=Counter(x["replica"] for x in nodes);ovs=[x["decision_overhead_ms"] for x in nodes]
    crit=[x for x in nodes if x["critical"] and x["node_id"]!="root"];side=[x for x in nodes if not x["critical"]]
    backsum={}
    for r,rows in back.items():
        backsum[str(r)]={"max_running":max([x.get("running_after_schedule") or 0 for x in rows],default=0),
                         "max_waiting":max([x.get("waiting_after_schedule") or 0 for x in rows],default=0),
                         "max_kv_frac":max([(x.get("kv_in_use_blocks_after_schedule") or 0)/4096 for x in rows],default=0)}
    dur=(t1-t0)/1e9;outputs=sum(int(x.get("output_tokens") or 0) for x in nodes)
    s={"arrival_rate":rate,"block":block,"position":pos,"method":method,
       "completed_workflows":sum(x["status"]=="ok" for x in wfs),
       "mean_jct_ms":st.mean(j),"p95_jct_ms":pct(j,.95),"mean_node_latency_ms":st.mean(nl),
       "duration_s":dur,"output_tokens":outputs,"output_tokens_s":outputs/dur,
       "workflow_throughput_s":WORKFLOWS/dur,
       "affinity_expected_fraction":sum(bool(x["affinity_expected"]) for x in nodes)/len(nodes),
       "critical_affinity_fraction":sum(bool(x["affinity_expected"]) for x in crit)/max(1,len(crit)),
       "side_affinity_fraction":sum(bool(x["affinity_expected"]) for x in side)/max(1,len(side)),
       "pressure_override_fraction":sum(bool(x["affinity_override_due_pressure"]) for x in nodes)/len(nodes),
       "replica_assignments":{str(i):reps.get(i,0) for i in range(4)},
       "assignment_imbalance":max(reps.get(i,0) for i in range(4))-min(reps.get(i,0) for i in range(4)),
       "decision_overhead_mean_ms":st.mean(ovs),"decision_overhead_p95_ms":pct(ovs,.95),
       "gpu_prefix_cache_hit_rate_before":before,"gpu_prefix_cache_hit_rate_after":after,
       "backend":backsum}
    (out/"summary.json").write_text(json.dumps(s,indent=2)+"\n");return s

async def confirm(args):
    runtime=args.runtime.resolve();validate(runtime)
    import fcntl
    lf=(runtime/"experiment.lock").open("a")
    try:fcntl.flock(lf,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit("runtime lock busy")
    old=json.loads((runtime/"control.json").read_text())
    stamp=time.strftime("%Y%m%dT%H%M%SZ",time.gmtime())
    suite=ROOT/"runs/spra_v2"/f"R6D_CONFIRM_{stamp}_{os.getpid()}";suite.mkdir(parents=True)
    rows=[];idx=0
    orders=[
        ("RR","EFT","Affinity","SPRA"),
        ("EFT","Affinity","SPRA","RR"),
        ("Affinity","SPRA","RR","EFT"),
        ("SPRA","RR","EFT","Affinity"),
    ]
    try:
        for rate in RATES:
            for block,order in enumerate(orders,1):
                arrivals=make_arrivals(WORKFLOWS,rate,seed=int(rate)*10000+block*131)
                for pos,method in enumerate(order,1):
                    idx+=1;print(f"CASE_START rate={rate:g} block={block} position={pos} method={method}",flush=True)
                    s=await run_condition(method,rate,block,pos,idx,suite,runtime,arrivals);rows.append(s)
                    print("CASE_DONE "+json.dumps(s,sort_keys=True),flush=True)
                    atomic_json(runtime/"control.json",{"case":"R6D/idle-fixed","token_budget":BATCH_BUDGET})
                    await asyncio.sleep(.4)
    finally:
        atomic_json(runtime/"control.json",old);fcntl.flock(lf,fcntl.LOCK_UN);lf.close()

    fields=sorted({k for r in rows for k,v in r.items() if not isinstance(v,(dict,list))})
    with (suite/"comparison.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in rows:w.writerow({k:r.get(k) for k in fields})
    agg={}
    for rate in RATES:
        rr=[r for r in rows if r["arrival_rate"]==rate and r["method"]=="RR"]
        rrmean=st.mean(x["mean_jct_ms"] for x in rr)
        agg[str(rate)]={}
        for m in METHODS:
            xs=[r for r in rows if r["arrival_rate"]==rate and r["method"]==m]
            mj=st.mean(x["mean_jct_ms"] for x in xs)
            agg[str(rate)][m]={
                "repeats":len(xs),"mean_jct_ms":mj,
                "mean_p95_jct_ms":st.mean(x["p95_jct_ms"] for x in xs),
                "gain_vs_rr_pct":100*(rrmean-mj)/rrmean,
                "mean_output_tokens_s":st.mean(x["output_tokens_s"] for x in xs),
                "mean_critical_affinity_fraction":st.mean(x["critical_affinity_fraction"] for x in xs),
                "mean_side_affinity_fraction":st.mean(x["side_affinity_fraction"] for x in xs),
                "mean_assignment_imbalance":st.mean(x["assignment_imbalance"] for x in xs),
                "mean_decision_overhead_ms":st.mean(x["decision_overhead_mean_ms"] for x in xs),
                "max_waiting_across_repeats":max(max(v["max_waiting"] for v in x["backend"].values()) for x in xs),
            }
    (suite/"aggregate.json").write_text(json.dumps(agg,indent=2)+"\n")
    (ROOT/"metadata/spra_v2/r6d_confirm_latest.txt").write_text(str(suite)+"\n")
    print("RESULT="+str(suite));print("MEASURED_RUNS=32/32")
    print("AGGREGATE="+json.dumps(agg,sort_keys=True))

def selftest():
    assert sum(OUTTOK.values())==576 and WORKFLOWS==32 and REPEATS==4
    assert CRITICAL["c1"] and not CRITICAL["s1"]
    assert CRITICAL_AFFINITY_MARGIN>SIDE_AFFINITY_MARGIN
    print("SELFTEST_OK r6d frozen_spra=critical-locality-protection rates=8,12 runs=32 gpu_requests=0")

def plan():
    print("===== R6D CONFIRMATORY REAL SCHEDULING =====")
    print("RATES=8,12 workflows/s WORKFLOWS=32")
    print("METHODS=RR,EFT,Affinity,SPRA")
    print("REPEATS=4 per rate; 4x4 counterbalanced method order")
    print("MEASURED_RUNS=2*4*4=32")
    print("SPRA_FROZEN_RULE=critical-path locality protection + off-critical load shedding")
    print(f"CRITICAL_AFFINITY_MARGIN={CRITICAL_AFFINITY_MARGIN}")
    print(f"SIDE_AFFINITY_MARGIN={SIDE_AFFINITY_MARGIN}")
    print("NO_POST_CONFIRM_TUNING=True")
    print("PRIMARY=mean workflow JCT; SECONDARY=P95 JCT, throughput, critical/side affinity, imbalance, waiting")
    print("NEXT=integrate exact published Preble baseline and public workflow validation")

def report():
    p=ROOT/"metadata/spra_v2/r6d_confirm_latest.txt"
    if not p.exists():raise SystemExit("no R6D result")
    d=Path(p.read_text().strip());print("RESULT="+str(d));print((d/"aggregate.json").read_text())

def main():
    p=argparse.ArgumentParser();sp=p.add_subparsers(dest="cmd",required=True)
    sp.add_parser("selftest");sp.add_parser("plan");sp.add_parser("report")
    q=sp.add_parser("confirm");q.add_argument("--runtime",type=Path,default=RUNTIME)
    a=p.parse_args()
    if a.cmd=="selftest":selftest()
    elif a.cmd=="plan":plan()
    elif a.cmd=="report":report()
    else:asyncio.run(confirm(a))
if __name__=="__main__":main()
