from __future__ import annotations
import argparse,json,os,tempfile,urllib.request
from pathlib import Path

EXPECTED_HOOK="spra-v2-telemetry-1"
PODS=[f"spra-vllm-{i}" for i in range(4)]
PORTS=[8000+i for i in range(4)]

def atomic(path:Path,data:dict):
    fd,tmp=tempfile.mkstemp(prefix=path.name+".",dir=str(path.parent));os.close(fd)
    Path(tmp).write_text(json.dumps(data));os.replace(tmp,path)

def get(url,timeout=3):
    with urllib.request.urlopen(url,timeout=timeout) as r:
        return r.status,r.read().decode(errors="replace")

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--runtime",type=Path,default=Path("/home/wmy/sci/spra_core_exp/joint_e1"))
    p.add_argument("--host",default="127.0.0.1")
    p.add_argument("--set-budget",type=int,default=2048,choices=(1024,2048,4096))
    a=p.parse_args()
    fail=[];gpus=[]
    print("===== R6B GPU39 GATE =====")
    for pod,port in zip(PODS,PORTS):
        sp=a.runtime/"backend"/f"{pod}.status.json"
        try:s=json.loads(sp.read_text())
        except Exception as e:
            fail.append(f"{pod}:status:{e}");continue
        row={k:s.get(k) for k in ("pod","hook_version","num_gpu_blocks","block_size",
                                   "max_num_seqs","prefix_caching","nvidia_visible_devices",
                                   "running","waiting","token_budget")}
        print("STATUS="+json.dumps(row,sort_keys=True))
        if s.get("hook_version")!=EXPECTED_HOOK:fail.append(f"{pod}:hook")
        if int(s.get("num_gpu_blocks") or 0)!=4096:fail.append(f"{pod}:kv_blocks")
        if not s.get("prefix_caching"):fail.append(f"{pod}:prefix")
        if int(s.get("block_size") or 0)!=16:fail.append(f"{pod}:block_size")
        gpus.append(s.get("nvidia_visible_devices"))
        try:
            hs,_=get(f"http://{a.host}:{port}/health")
            ms,body=get(f"http://{a.host}:{port}/v1/models")
            model_ok=bool(json.loads(body).get("data"))
            print(f"ENDPOINT pod={pod} port={port} health={hs} models={ms} model_ok={model_ok}")
            if hs!=200 or ms!=200 or not model_ok:fail.append(f"{pod}:endpoint")
        except Exception as e:fail.append(f"{pod}:endpoint:{e}")
    print(f"UNIQUE_GPU_UUIDS={len(set(gpus))}/4")
    if len(set(gpus))!=4:fail.append("gpu_uuid")
    if fail:
        print("FAILURES="+json.dumps(fail));print("R6B_GATE_READY=False")
        raise SystemExit(2)
    ctl=a.runtime/"control.json"
    old=json.loads(ctl.read_text())
    backup=a.runtime/"control.pre_r6b.json"
    if not backup.exists():backup.write_text(json.dumps(old,indent=2)+"\n")
    atomic(ctl,{"case":"R6B/idle-fixed","token_budget":a.set_budget})
    print("CONTROL="+json.dumps(json.loads(ctl.read_text()),sort_keys=True))
    print("MODEL_GENERATION_REQUESTS=0")
    print("R6B_GATE_READY=True")
if __name__=="__main__":main()
