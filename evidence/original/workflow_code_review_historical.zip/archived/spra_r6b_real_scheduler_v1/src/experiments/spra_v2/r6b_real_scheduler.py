from __future__ import annotations
import argparse,asyncio,csv,hashlib,json,math,os,random,statistics as st,tempfile,time
from collections import Counter,defaultdict
from dataclasses import dataclass
from pathlib import Path
import httpx

ROOT=Path(__file__).resolve().parents[3]
RUNTIME=Path("/home/wmy/sci/spra_core_exp/joint_e1")
MODEL="Qwen2.5-1.5B-Instruct"
ENDPOINTS=[f"http://127.0.0.1:{8000+i}" for i in range(4)]
PODS=[f"spra-vllm-{i}" for i in range(4)]
METHODS=("RR","EFT","Affinity","SPRA")
OUTPUT_TOKENS=64
BATCH_BUDGET=2048
WORKFLOWS=16
ARRIVAL_RATE=6.0
CLUSTERS=(0,1,0,2,0,1,0,2,0,1,0,2,0,1,0,0)
COMMON_SENTENCE=(
    "This is stable shared workflow context for automatic prefix-cache reuse. "
    "The request belongs to a multi-node agent workflow and executes bounded "
    "deterministic inference work before returning. "
)
ROLE_TEXT={
    "c1":"critical-chain stage one","c2":"critical-chain stage two",
    "c3":"critical-chain stage three","s1":"parallel side branch one",
    "s2":"parallel side branch two","join":"fan-in join stage",
}
CPR={"c1":4,"c2":3,"c3":2,"s1":2,"s2":2,"join":1}
WORK_UNITS={"c1":1000,"c2":1050,"c3":1050,"s1":980,"s2":980,"join":1150}

def pct(xs,q):
    if not xs:return None
    a=sorted(xs);p=(len(a)-1)*q;lo=int(math.floor(p));hi=int(math.ceil(p))
    return a[lo] if lo==hi else a[lo]*(hi-p)+a[hi]*(p-lo)

def atomic_json(path:Path,data:dict):
    fd,tmp=tempfile.mkstemp(prefix=path.name+".",dir=str(path.parent));os.close(fd)
    Path(tmp).write_text(json.dumps(data));os.replace(tmp,path)

def make_arrivals(n,rate,seed):
    rng=random.Random(seed);gap=1.0/rate;xs=[]
    for i in range(n):
        xs.append(max(0.0,i*gap+(rng.random()-.5)*.20*gap))
    xs.sort();xs[0]=0.0
    return xs

def read_status(runtime:Path,r:int):
    try:return json.loads((runtime/"backend"/f"spra-vllm-{r}.status.json").read_text())
    except Exception:return {}

def backend_rows(runtime:Path,case:str,pod:str):
    rows=[]
    for p in sorted((runtime/"backend").glob(f"{pod}.*.jsonl")):
        for line in p.read_text(errors="ignore").splitlines():
            try:x=json.loads(line)
            except:continue
            if x.get("event")=="iteration" and x.get("case")==case:rows.append(x)
    rows.sort(key=lambda x:(x.get("ts_wall_ns") or 0,x.get("iteration") or 0))
    return rows

def validate(runtime:Path):
    ctl=json.loads((runtime/"control.json").read_text())
    if int(ctl.get("token_budget") or -1)!=BATCH_BUDGET:
        raise RuntimeError(f"R6B requires fixed budget {BATCH_BUDGET}, got {ctl}")
    g=[]
    for i in range(4):
        s=read_status(runtime,i)
        if s.get("hook_version")!="spra-v2-telemetry-1":raise RuntimeError(f"pod{i} hook")
        if int(s.get("num_gpu_blocks") or 0)!=4096:raise RuntimeError(f"pod{i} blocks")
        if not s.get("prefix_caching"):raise RuntimeError(f"pod{i} prefix")
        g.append(s.get("nvidia_visible_devices"))
    if len(set(g))!=4:raise RuntimeError("GPU UUIDs are not unique")

def make_prompt(epoch:str,cluster:int,wfid:str,node:str):
    shared=(f"CACHE_EPOCH={epoch}; PREFIX_CLUSTER={cluster};\n"+COMMON_SENTENCE*12)
    system=shared+(
        "\nYou are executing "+ROLE_TEXT[node]+". "
        "Produce the bounded generation work requested by the server. "
        "Content quality is not evaluated in this controlled systems workload."
    )
    user=(
        f"workflow={wfid}; node={node}; cluster={cluster}. "
        "Perform deterministic synthetic reasoning about scheduling, dependency readiness, "
        "cache locality and queue balance. Return concise text."
    )
    return [{"role":"system","content":system},{"role":"user","content":user}]

async def infer(client:httpx.AsyncClient,endpoint:str,messages:list[dict]):
    payload={
        "model":MODEL,"messages":messages,"temperature":0.0,"seed":0,
        "max_tokens":OUTPUT_TOKENS,"min_tokens":OUTPUT_TOKENS,
        "ignore_eos":True,"stream":False,
    }
    t0=time.perf_counter_ns()
    try:
        r=await client.post(endpoint+"/v1/chat/completions",json=payload)
        t1=time.perf_counter_ns();r.raise_for_status();obj=r.json()
        usage=obj.get("usage") or {}
        text=((obj.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
        return {"status":"ok","request_id":obj.get("id"),"latency_ms":(t1-t0)/1e6,
                "prompt_tokens":usage.get("prompt_tokens"),"output_tokens":usage.get("completion_tokens"),
                "text_sha256":hashlib.sha256(text.encode()).hexdigest(),"error":None}
    except Exception as e:
        return {"status":"error","request_id":None,"latency_ms":(time.perf_counter_ns()-t0)/1e6,
                "prompt_tokens":None,"output_tokens":None,"text_sha256":None,
                "error":f"{type(e).__name__}:{e}"}

@dataclass
class Choice:
    replica:int
    overhead_ms:float
    affinity_expected:bool

class Dispatcher:
    def __init__(self,method:str,runtime:Path):
        self.method=method;self.runtime=runtime
        self.lock=asyncio.Lock();self.rr=0
        self.inflight=[0]*4;self.work=[0.0]*4
        self.prefix_warm=[set() for _ in range(4)]
        self.assignments=[0]*4;self.decisions=[]

    def live(self,r):
        s=read_status(self.runtime,r)
        cap=float(s.get("num_gpu_blocks") or 4096)
        return {"running":int(s.get("running") or 0),"waiting":int(s.get("waiting") or 0),
                "kv_frac":float(s.get("kv_in_use_blocks") or 0)/cap,
                "inflight":self.inflight[r],"work":self.work[r],
                "assignments":self.assignments[r],"status_case":s.get("case")}

    async def choose(self,prefix_id,cpr,work_units,node_key):
        async with self.lock:
            t0=time.perf_counter_ns()
            snap={str(r):self.live(r) for r in range(4)}
            comp={}
            if self.method=="RR":
                r=self.rr%4;self.rr+=1
                for x in range(4):comp[str(x)]={"rr_turn":x==r}
            elif self.method=="EFT":
                vals=[]
                for x in range(4):
                    z=snap[str(x)]
                    score=z["work"]+work_units+350*z["waiting"]+150*z["running"]
                    vals.append((score,x));comp[str(x)]={"eft_work_score":score}
                _,r=min(vals)
            elif self.method=="Affinity":
                warm=[x for x in range(4) if prefix_id in self.prefix_warm[x]]
                pool=warm if warm else list(range(4));vals=[]
                for x in pool:
                    z=snap[str(x)]
                    load=z["inflight"]+z["waiting"]+.5*z["running"]+2*z["kv_frac"]
                    vals.append((load,x));comp[str(x)]={"affinity":x in warm,"load":load}
                _,r=min(vals)
            elif self.method=="SPRA":
                vals=[];crit=max(0.0,min(1.0,cpr/4.0))
                for x in range(4):
                    z=snap[str(x)];warm=prefix_id in self.prefix_warm[x]
                    load=(z["inflight"]+.75*z["waiting"]+.35*z["running"]+
                          z["work"]/1200.0+2*z["kv_frac"])
                    load_weight=1.0+.9*crit
                    affinity_weight=1.35*(1.0-.55*crit)
                    score=load_weight*load-affinity_weight*(1.0 if warm else 0.0)
                    vals.append((score,x))
                    comp[str(x)]={"load":load,"criticality":crit,"load_weight":load_weight,
                                  "prefix_warm":warm,"affinity_weight":affinity_weight,"score":score}
                _,r=min(vals)
            else:raise ValueError(self.method)
            affinity=prefix_id in self.prefix_warm[r]
            self.inflight[r]+=1;self.work[r]+=work_units;self.assignments[r]+=1
            ov=(time.perf_counter_ns()-t0)/1e6
            self.decisions.append({"node_key":node_key,"method":self.method,"replica":r,
                "prefix_id":prefix_id,"critical_path_remaining":cpr,"work_units":work_units,
                "decision_overhead_ms":ov,"affinity_expected":affinity,
                "snapshot":snap,"components":comp})
            return Choice(r,ov,affinity)

    async def done(self,r,prefix_id,work_units):
        async with self.lock:
            self.inflight[r]-=1;self.work[r]-=work_units;self.prefix_warm[r].add(prefix_id)

async def warm_replicas(epoch,client):
    async def one(r):
        msgs=[{"role":"system","content":f"R6B_WARMUP_EPOCH={epoch}; unrelated context."},
              {"role":"user","content":"Return bounded warmup text."}]
        return await infer(client,ENDPOINTS[r],msgs)
    return await asyncio.gather(*(one(r) for r in range(4)))

async def execute_workflow(idx,arrival,epoch,disp,client,node_rows,wf_rows):
    await asyncio.sleep(arrival)
    wf_start=time.perf_counter_ns();wfid=f"wf{idx:03d}";cluster=CLUSTERS[idx]

    async def node(name):
        ready=time.perf_counter_ns();prefix=f"cluster-{cluster}"
        ch=await disp.choose(prefix,CPR[name],WORK_UNITS[name],f"{wfid}/{name}")
        start=time.perf_counter_ns()
        res=await infer(client,ENDPOINTS[ch.replica],make_prompt(epoch,cluster,wfid,name))
        end=time.perf_counter_ns()
        await disp.done(ch.replica,prefix,WORK_UNITS[name])
        node_rows.append({"workflow_id":wfid,"node_id":name,"cluster":cluster,"replica":ch.replica,
            "critical_path_remaining":CPR[name],"ready_ns":ready,"start_ns":start,"end_ns":end,
            "queue_to_dispatch_ms":(start-ready)/1e6,"latency_ms":res["latency_ms"],
            "status":res["status"],"request_id":res["request_id"],
            "prompt_tokens":res["prompt_tokens"],"output_tokens":res["output_tokens"],
            "text_sha256":res["text_sha256"],"affinity_expected":ch.affinity_expected,
            "decision_overhead_ms":ch.overhead_ms,"error":res["error"]})
        return res

    side1=asyncio.create_task(node("s1"));side2=asyncio.create_task(node("s2"))
    c1=await node("c1");c2=await node("c2");c3=await node("c3")
    s1,s2=await asyncio.gather(side1,side2);join=await node("join")
    wf_end=time.perf_counter_ns()
    ok=all(x["status"]=="ok" for x in (c1,c2,c3,s1,s2,join))
    wf_rows.append({"workflow_id":wfid,"cluster":cluster,"status":"ok" if ok else "error",
                    "jct_ms":(wf_end-wf_start)/1e6,"arrival_offset_s":arrival})

def collect_backend(runtime,case):
    return {r:backend_rows(runtime,case,PODS[r]) for r in range(4)}

def prefill_by_request(back):
    d=defaultdict(int)
    for rows in back.values():
        for row in rows:
            for c in row.get("calls") or []:
                if c.get("prefill") and c.get("id"):
                    d[c["id"]]+=int(c.get("scheduled_tokens") or 0)
    return d

async def run_condition(method,cond_idx,suite,runtime,arrivals):
    case=f"R6B/{cond_idx:02d}/{method}"
    epoch=f"E{cond_idx:04d}"
    atomic_json(runtime/"control.json",{"case":case,"token_budget":BATCH_BUDGET})
    out=suite/f"{cond_idx:02d}_{method}";out.mkdir()
    disp=Dispatcher(method,runtime);node_rows=[];wf_rows=[]
    timeout=httpx.Timeout(180.0,connect=5.0)
    limits=httpx.Limits(max_connections=256,max_keepalive_connections=64)
    async with httpx.AsyncClient(timeout=timeout,limits=limits) as client:
        warm=await warm_replicas(epoch,client)
        if any(x["status"]!="ok" for x in warm):
            raise RuntimeError(f"warmup failed for {method}: {warm}")
        await asyncio.sleep(.2)
        t0=time.perf_counter_ns()
        await asyncio.gather(*(execute_workflow(i,arrivals[i],epoch,disp,client,node_rows,wf_rows)
                               for i in range(WORKFLOWS)))
        t1=time.perf_counter_ns()
    await asyncio.sleep(.3)
    back=collect_backend(runtime,case)
    prefill=prefill_by_request(back)
    matched=0
    for n in node_rows:
        rid=n.get("request_id")
        n["actual_scheduled_prefill_tokens"]=prefill.get(rid)
        if rid in prefill:matched+=1
        if n.get("prompt_tokens") is not None and rid in prefill:
            n["estimated_cached_prompt_tokens"]=max(0,int(n["prompt_tokens"])-int(prefill[rid]))
        else:
            n["estimated_cached_prompt_tokens"]=None

    with (out/"nodes.jsonl").open("w") as f:
        for x in node_rows:f.write(json.dumps(x,separators=(",",":"))+"\n")
    with (out/"workflows.jsonl").open("w") as f:
        for x in wf_rows:f.write(json.dumps(x,separators=(",",":"))+"\n")
    (out/"decisions.json").write_text(json.dumps(disp.decisions,indent=2)+"\n")
    for r,rows in back.items():
        with (out/f"backend_replica{r}.jsonl").open("w") as f:
            for x in rows:f.write(json.dumps(x,separators=(",",":"))+"\n")

    j=[x["jct_ms"] for x in wf_rows if x["status"]=="ok"]
    nl=[x["latency_ms"] for x in node_rows if x["status"]=="ok"]
    tok=sum(int(x.get("output_tokens") or 0) for x in node_rows)
    prompt=sum(int(x.get("prompt_tokens") or 0) for x in node_rows)
    actual_pref=sum(int(x.get("actual_scheduled_prefill_tokens") or 0) for x in node_rows
                    if x.get("actual_scheduled_prefill_tokens") is not None)
    cache_saved=sum(int(x.get("estimated_cached_prompt_tokens") or 0) for x in node_rows)
    overhead=[x["decision_overhead_ms"] for x in disp.decisions]
    rep_counts=Counter(x["replica"] for x in node_rows)
    affinity=sum(bool(x.get("affinity_expected")) for x in node_rows)/max(1,len(node_rows))
    back_summary={}
    for r,rows in back.items():
        back_summary[str(r)]={
            "iterations":len(rows),
            "max_running":max([x.get("running_after_schedule") or 0 for x in rows],default=0),
            "max_waiting":max([x.get("waiting_after_schedule") or 0 for x in rows],default=0),
            "preemptions":sum(int(x.get("preempted") or 0) for x in rows),
            "max_kv_frac":max([(x.get("kv_in_use_blocks_after_schedule") or 0)/
                               max(1,(x.get("kv_capacity_blocks") or 4096)) for x in rows],default=0),
        }
    summary={
        "method":method,"case":case,"workflows":len(wf_rows),
        "completed_workflows":sum(x["status"]=="ok" for x in wf_rows),
        "mean_jct_ms":st.mean(j) if j else None,"p95_jct_ms":pct(j,.95),
        "mean_node_latency_ms":st.mean(nl) if nl else None,
        "duration_s":(t1-t0)/1e9,"workflow_throughput_s":len(wf_rows)/((t1-t0)/1e9),
        "output_tokens":tok,"output_tokens_s":tok/((t1-t0)/1e9),
        "prompt_tokens":prompt,"backend_prefill_request_matches":matched,
        "actual_scheduled_prefill_tokens":actual_pref,
        "estimated_cached_prompt_tokens":cache_saved,
        "estimated_prompt_compute_saved_fraction":cache_saved/max(1,prompt),
        "affinity_expected_fraction":affinity,
        "replica_assignments":{str(i):rep_counts.get(i,0) for i in range(4)},
        "assignment_imbalance_max_min":max([rep_counts.get(i,0) for i in range(4)])-
                                       min([rep_counts.get(i,0) for i in range(4)]),
        "decision_overhead_mean_ms":st.mean(overhead) if overhead else None,
        "decision_overhead_p95_ms":pct(overhead,.95),
        "backend":back_summary,
        "fixed_batch_budget":BATCH_BUDGET,"kv_blocks_per_replica":4096,
        "workload":{"workflows":WORKFLOWS,"arrival_rate":ARRIVAL_RATE,
                    "nodes_per_workflow":6,"output_tokens_per_node":OUTPUT_TOKENS,
                    "prefix_clusters":{"0":8,"1":4,"2":4}},
        "scope":"real four-replica controlled-DAG scheduling smoke",
    }
    (out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    return summary

async def suite_run(mode,args):
    runtime=args.runtime.resolve();validate(runtime)
    import fcntl
    lock=(runtime/"experiment.lock").open("a")
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit("runtime lock busy")
    old=json.loads((runtime/"control.json").read_text())
    stamp=time.strftime("%Y%m%dT%H%M%SZ",time.gmtime())
    suite=ROOT/"runs/spra_v2"/f"R6B_{mode.upper()}_{stamp}_{os.getpid()}";suite.mkdir(parents=True)
    rows=[]
    try:
        if mode=="smoke":
            orders=[METHODS]
        else:
            orders=[
                ("RR","EFT","Affinity","SPRA"),
                ("EFT","Affinity","SPRA","RR"),
                ("Affinity","SPRA","RR","EFT"),
                ("SPRA","RR","EFT","Affinity"),
            ]
        idx=0
        for block,order in enumerate(orders,1):
            arrivals=make_arrivals(WORKFLOWS,ARRIVAL_RATE,seed=610000+block*101)
            for pos,method in enumerate(order,1):
                idx+=1
                print(f"CASE_START block={block} position={pos} method={method}",flush=True)
                s=await run_condition(method,idx,suite,runtime,arrivals)
                s["block"]=block;s["position"]=pos;rows.append(s)
                print("CASE_DONE "+json.dumps(s,sort_keys=True),flush=True)
                atomic_json(runtime/"control.json",{"case":"R6B/idle-fixed","token_budget":BATCH_BUDGET})
                await asyncio.sleep(.5)
    finally:
        atomic_json(runtime/"control.json",old)
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()

    flat=[]
    for s in rows:
        flat.append({k:v for k,v in s.items() if k not in ("backend","workload","replica_assignments")})
    fields=sorted({k for x in flat for k in x})
    with (suite/"comparison.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(flat)

    agg={}
    for m in METHODS:
        rs=[r for r in rows if r["method"]==m]
        if not rs:continue
        agg[m]={
            "repeats":len(rs),
            "mean_jct_ms":st.mean(r["mean_jct_ms"] for r in rs),
            "mean_p95_jct_ms":st.mean(r["p95_jct_ms"] for r in rs),
            "mean_output_tokens_s":st.mean(r["output_tokens_s"] for r in rs),
            "mean_cached_prompt_fraction":st.mean(r["estimated_prompt_compute_saved_fraction"] for r in rs),
            "mean_affinity_expected_fraction":st.mean(r["affinity_expected_fraction"] for r in rs),
            "mean_decision_overhead_ms":st.mean(r["decision_overhead_mean_ms"] for r in rs),
            "assignment_imbalances":[r["assignment_imbalance_max_min"] for r in rs],
            "backend_prefill_match_fraction":st.mean(r["backend_prefill_request_matches"]/
                                                     max(1,WORKFLOWS*6) for r in rs),
        }
    (suite/"aggregate.json").write_text(json.dumps(agg,indent=2)+"\n")
    ptr=ROOT/"metadata/spra_v2"/f"r6b_{mode}_latest.txt"
    ptr.parent.mkdir(parents=True,exist_ok=True);ptr.write_text(str(suite)+"\n")
    print("RESULT="+str(suite))
    print(f"MEASURED_RUNS={len(rows)}/{len(rows)}")
    print("AGGREGATE="+json.dumps(agg,sort_keys=True))

def selftest():
    assert len(CLUSTERS)==WORKFLOWS
    assert Counter(CLUSTERS)==Counter({0:8,1:4,2:4})
    assert CPR["c1"]>CPR["c2"]>CPR["c3"]>=CPR["join"]
    assert OUTPUT_TOKENS==64 and BATCH_BUDGET==2048
    a=make_arrivals(16,6.0,1);assert len(a)==16 and a[0]==0
    print("SELFTEST_OK r6b methods=4 workflows=16 fixed_output_tokens=64 gpu_requests=0")

def plan():
    print("===== R6B REAL SCHEDULING PLAN =====")
    print("REPLICAS=4 endpoints=8000,8001,8002,8003")
    print("KV_BLOCKS_PER_REPLICA=4096 FIXED_BATCH_BUDGET=2048")
    print("METHODS=RR,EFT,Affinity,SPRA")
    print("WORKFLOW=controlled asymmetric DAG: c1->c2->c3; s1||s2; then join")
    print("WORKFLOWS=16 ARRIVAL_RATE=6 workflows/s NODES_PER_WORKFLOW=6")
    print("PREFIX_CLUSTERS=3 distribution=8,4,4")
    print("OUTPUT_TOKENS_PER_NODE=64 min_tokens=64 ignore_eos=true")
    print("SMOKE_RUNS=4")
    print("CONFIRM_RUNS=16 (4x4 counterbalanced order)")
    print("PREFIX_METRIC=backend scheduled prefill tokens matched by real request ID")
    print("SPRA=criticality-modulated live-load versus scheduler-maintained prefix-affinity tradeoff")
    print("NOTE=Affinity history is routing signal; actual reuse is evaluated from backend prefill work")

def report(kind):
    ptr=ROOT/"metadata/spra_v2"/f"r6b_{kind}_latest.txt"
    if not ptr.exists():raise SystemExit(f"no R6B {kind} result")
    d=Path(ptr.read_text().strip());print("RESULT="+str(d));print((d/"aggregate.json").read_text())

def main():
    p=argparse.ArgumentParser();sp=p.add_subparsers(dest="cmd",required=True)
    sp.add_parser("selftest");sp.add_parser("plan")
    for x in ("smoke","confirm"):
        q=sp.add_parser(x);q.add_argument("--runtime",type=Path,default=RUNTIME)
    r=sp.add_parser("report");r.add_argument("--kind",choices=("smoke","confirm"),required=True)
    a=p.parse_args()
    if a.cmd=="selftest":selftest()
    elif a.cmd=="plan":plan()
    elif a.cmd=="report":report(a.kind)
    else:asyncio.run(suite_run(a.cmd,a))
if __name__=="__main__":main()
