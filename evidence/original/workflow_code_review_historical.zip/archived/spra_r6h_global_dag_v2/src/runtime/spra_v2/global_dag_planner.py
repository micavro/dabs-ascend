from __future__ import annotations
import asyncio,itertools,statistics,time
from collections import defaultdict
from dataclasses import dataclass,field

def lcp(a,b):
    n=min(len(a),len(b));i=0
    while i<n and a[i]==b[i]:i+=1
    return i

@dataclass
class Req:
    key:str
    workflow_id:str
    node:str
    tokens:tuple[int,...]
    out_tokens:int
    tail_ms:float
    future:asyncio.Future|None=None
    ready_ns:int=field(default_factory=time.perf_counter_ns)

@dataclass
class Active:
    key:str
    workflow_id:str
    node:str
    replica:int
    start_ns:int
    base_ms:float
    tail_ms:float
    start_concurrency:int

class SlowdownCurve:
    def __init__(self,raw_ms:dict[int,float]):
        raw={int(k):float(v) for k,v in raw_ms.items()}
        if 1 not in raw:raise ValueError("concurrency calibration needs k=1")
        b=raw[1]
        self.points=sorted((k,max(1.0,v/b)) for k,v in raw.items())
    def __call__(self,k:int)->float:
        k=max(1,int(k));p=self.points
        if k<=p[0][0]:return p[0][1]
        for (x0,y0),(x1,y1) in zip(p,p[1:]):
            if k<=x1:
                a=(k-x0)/max(1,x1-x0);return y0+a*(y1-y0)
        x0,y0=p[-2];x1,y1=p[-1]
        return max(y1,y1+(y1-y0)/max(1,x1-x0)*(k-x1))

@dataclass
class PlanSnapshot:
    now_ns:int
    live:list[dict]
    measured_counts:list[int]
    active_jobs:list[list[tuple]]
    base:dict[tuple[str,int],tuple[float,int]]
    dummy_base:list[float]

class GlobalDAGPlanner:
    """Global central-frontier planner with one immutable snapshot per plan().

    All candidates in one scheduling epoch are compared against exactly the
    same live state, active-work remainder and prefix/service table. There is
    no status-file I/O inside candidate evaluation.
    """
    def __init__(self,prefill_ms,decode_ms,slowdown_curves,status_fn):
        self.n=len(prefill_ms)
        self.prefill=[float(x) for x in prefill_ms]
        self.decode=[float(x) for x in decode_ms]
        self.slow=[SlowdownCurve(x) for x in slowdown_curves]
        self.status_fn=status_fn
        self.cached=[[] for _ in range(self.n)]
        self.active:dict[str,Active]={}
        self.decisions=[];self.plan_events=[]

    def match(self,r,tokens):
        best=0
        for old in self.cached[r]:
            best=max(best,lcp(tokens,old))
        return best

    def base_service(self,r,q:Req):
        hit=self.match(r,q.tokens)
        base=self.prefill[r]*max(1,len(q.tokens)-hit)+self.decode[r]*q.out_tokens
        return base,hit

    def _ps_rollout(self,r,jobs):
        rem={x[0]:float(x[2]) for x in jobs if x[2]>1e-12}
        done={};wall=0.0
        while rem:
            n=len(rem);step=min(rem.values())
            wall+=step*self.slow[r](n)
            finished=[]
            for k in list(rem):
                rem[k]-=step
                if rem[k]<=1e-9:finished.append(k)
            for k in finished:
                done[k]=wall;rem.pop(k,None)
        return done

    def _snapshot(self,ready:list[Req])->PlanSnapshot:
        now=time.perf_counter_ns()
        live=[self.status_fn(r) for r in range(self.n)]  # exactly once/replica
        measured=[max(0,int(z.get("running") or 0)+int(z.get("waiting") or 0)) for z in live]

        active_jobs=[[] for _ in range(self.n)]
        for a in self.active.values():
            elapsed=(now-a.start_ns)/1e6
            progressed=elapsed/max(self.slow[a.replica](a.start_concurrency),1e-9)
            rem=max(0.0,a.base_ms-progressed)
            active_jobs[a.replica].append((a.key,a.workflow_id,rem,a.tail_ms,False))

        base={}
        for q in ready:
            for r in range(self.n):
                base[q.key,r]=self.base_service(r,q)

        dummy=[]
        for r in range(self.n):
            vals=[x[2] for x in active_jobs[r] if x[2]>0]
            if vals:dummy.append(statistics.median(vals))
            else:dummy.append(self.decode[r]*64+self.prefill[r]*128)
        return PlanSnapshot(now,live,measured,active_jobs,base,dummy)

    def _evaluate(self,ready,assignment,snap:PlanSnapshot):
        wf=defaultdict(float);completion={}
        for r in range(self.n):
            jobs=list(snap.active_jobs[r])
            shadow=len(jobs)
            extra=max(0,snap.measured_counts[r]-shadow)
            for j in range(extra):
                jobs.append((f"__live_{r}_{j}",f"__live_{r}_{j}",
                             snap.dummy_base[r],0.0,False))
            for q in ready:
                if assignment[q.key]==r:
                    b,_=snap.base[q.key,r]
                    jobs.append((q.key,q.workflow_id,b,q.tail_ms,True))
            done=self._ps_rollout(r,jobs)
            for jid,wid,base,tail,is_new in jobs:
                if jid.startswith("__live_"):continue
                c=done.get(jid,0.0)
                wf[wid]=max(wf[wid],c+tail)
                if is_new:completion[jid]=c
        return sum(wf.values()),completion

    def _complete_fastest(self,ready,partial,snap):
        out=dict(partial)
        for q in ready:
            if q.key not in out:
                out[q.key]=min(range(self.n),key=lambda r:(snap.base[q.key,r][0],r))
        return out

    def reference(self,ready,snap):
        a={}
        for q in sorted(ready,key=lambda x:(x.ready_ns,x.key)):
            best=None
            for r in range(self.n):
                cand=dict(a);cand[q.key]=r
                cand=self._complete_fastest(ready,cand,snap)
                phi,_=self._evaluate(ready,cand,snap)
                val=(phi,r)
                if best is None or val<best:best=val
            a[q.key]=best[1]
        return a

    def plan(self,ready:list[Req]):
        if not ready:raise ValueError("empty frontier")
        t0=time.perf_counter_ns()
        snap=self._snapshot(ready)

        ref=self.reference(ready,snap)
        ref_phi,ref_comp=self._evaluate(ready,ref,snap)
        wfrem=defaultdict(float)
        for q in ready:
            wfrem[q.workflow_id]=max(wfrem[q.workflow_id],ref_comp[q.key]+q.tail_ms)
        slack={q.key:wfrem[q.workflow_id]-ref_comp[q.key]-q.tail_ms for q in ready}

        groups=defaultdict(list)
        for q in ready:groups[q.workflow_id].append(q)
        ordered=sorted(groups.values(),
                       key=lambda g:(min(slack[q.key] for q in g),
                                     min(q.ready_ns for q in g),g[0].workflow_id))
        incumbent=dict(ref);current=ref_phi;evaluated=1
        for g in ordered:
            best=dict(incumbent);best_phi=current
            for tup in itertools.product(range(self.n),repeat=len(g)):
                cand=dict(incumbent)
                for q,r in zip(g,tup):cand[q.key]=r
                phi,_=self._evaluate(ready,cand,snap);evaluated+=1
                if phi<best_phi-1e-9:
                    best_phi=phi;best=cand
            incumbent,current=best,best_phi

        _,comp=self._evaluate(ready,incumbent,snap)
        wall=(time.perf_counter_ns()-t0)/1e6
        widths=defaultdict(int)
        for g in groups.values():widths[len(g)]+=1
        evt={"frontier_size":len(ready),"workflow_groups":len(groups),
             "group_width_hist":dict(widths),"evaluated":evaluated,
             "reference_phi_ms":ref_phi,"returned_phi_ms":current,
             "predicted_gain_pct":100*(ref_phi-current)/ref_phi if ref_phi else 0.0,
             "planner_wall_ms":wall,
             "snapshot_running_waiting":[snap.measured_counts[r] for r in range(self.n)],
             "reference_assignment":dict(ref),"assignment":dict(incumbent)}
        self.plan_events.append(evt)

        out={}
        assigned_counts=[sum(incumbent[z.key]==r for z in ready) for r in range(self.n)]
        for q in ready:
            r=incumbent[q.key];b,hit=snap.base[q.key,r]
            k=max(1,snap.measured_counts[r]+assigned_counts[r])
            out[q.key]={"replica":r,"base_ms":b,"hit":hit,"slack_ms":slack[q.key],
                        "predicted_completion_ms":comp[q.key],
                        "start_concurrency":k,"reference_phi_ms":ref_phi,
                        "predicted_phi_ms":current,"planner_wall_ms":wall,
                        "frontier_size":len(ready),"workflow_groups":len(groups)}
        return out

    def start(self,q:Req,ch):
        self.active[q.key]=Active(q.key,q.workflow_id,q.node,ch["replica"],
                                  time.perf_counter_ns(),ch["base_ms"],q.tail_ms,
                                  ch["start_concurrency"])
        self.decisions.append({"key":q.key,"workflow_id":q.workflow_id,
                               "node":q.node,**ch})

    def finish(self,q:Req,replica:int):
        self.active.pop(q.key,None)
        self.cached[replica].append(tuple(q.tokens))
        if len(self.cached[replica])>1024:
            self.cached[replica]=self.cached[replica][-1024:]

class CentralCoordinator:
    def __init__(self,planner:GlobalDAGPlanner,epoch_s=.010):
        self.planner=planner;self.epoch_s=float(epoch_s)
        self.pending:list[Req]=[];self.lock=asyncio.Lock()
        self.running=False;self.task=None

    async def start(self):
        self.running=True
        self.task=asyncio.create_task(self._loop())

    async def close(self):
        self.running=False
        if self.task:await self.task

    async def submit_many(self,reqs:list[Req]):
        loop=asyncio.get_running_loop()
        async with self.lock:
            for q in reqs:
                q.future=loop.create_future();self.pending.append(q)
        return await asyncio.gather(*(q.future for q in reqs))

    async def _loop(self):
        loop=asyncio.get_running_loop()
        nxt=loop.time()+self.epoch_s
        while self.running or self.pending:
            await asyncio.sleep(max(0.0,nxt-loop.time()))
            nxt+=self.epoch_s
            async with self.lock:
                batch=self.pending;self.pending=[]
            if not batch:continue
            try:plan=self.planner.plan(batch)
            except Exception as e:
                for q in batch:
                    if q.future and not q.future.done():q.future.set_exception(e)
                continue
            for q in batch:
                if q.future and not q.future.done():q.future.set_result(plan[q.key])
