import copy,time,unittest,sys
from collections import Counter
from pathlib import Path
from unittest.mock import patch
from case23.design import *
from case23.binding import bindings,rr_reference,rr_snapshot
from case23.dependency import activate
activate()
from batching20.policy import process_plan as original
from joint18v2 import client
from helpers import CFG,MODEL

def snap(R=4,count=0,n=8):
    nodes={f'n{i}':{'id':f'n{i}','wid':f'w{i}','parents':[],'state':'ready','phase':'prefill','prompt':32,
         'output':2,'max_output_tokens':96,'ready_at':1.,'prefix_hash':None} for i in range(n)}
    return {'replicas':R,'now':1.1,'nodes':nodes,'ready':list(nodes),'rr_submitted_count':count,'pressure':[0]*R,
            'reserved_blocks':[0]*R,'capacity_blocks':[4096]*R}

class DesignTests(unittest.TestCase):
    def test_native_case_ids_unique_for_every_condition(self):
        from case23.runner import attempt_dir
        names=[attempt_dir(Path('/tmp/CASE_uniq'),c,1).name+'/raw' for c in make_design()]
        self.assertEqual(len(names),len(set(names)))

    def test_exact_counts(self):self.assertEqual(Counter(c['phase'] for c in make_design()),{'rates':64,'replicas':48,'ablations':24})
    def test_unique_anchor(self):self.assertEqual(len([c for c in make_design() if c['rate']==4 and c['replicas']==4 and c['method'] in CORE]),16)
    def test_all_methods_same_question_order(self):self.assertTrue(all(c['packet_slice']==[0,16] and c['seed']==200201 for c in make_design()))
    def test_no_Joint_or_future_winner(self):self.assertFalse(any(c['method'] in ('Joint','J-Light') for c in make_design()))
    def test_C_is_frozen(self):self.assertEqual(METHODS['DAG-Batch'],{'scheduler':'D','policy':'mixed_1024','routing':'original_D0'})
    def test_active_prefix_sets(self):self.assertTrue(all(c['active_replica_ids']==list(range(c['replicas'])) for c in make_design()))
    def test_no_single_replica_lies(self):self.assertEqual(len([c for c in make_design() if c['replicas']==1]),16)
    def test_core_count(self):self.assertEqual(len(cells_for(make_design(),'core')),112)
    def test_invalid_phase(self):
        with self.assertRaises(ValueError):cells_for(make_design(),'best')
    def test_frozen_repetitions(self):
        p=protocol();p['repeats']=1
        with self.assertRaises(ValueError):make_design(p)
    def test_williams_positions(self):
        for col in zip(*WILLIAMS):self.assertEqual(set(col),{0,1,2,3})
    def test_williams_carryover(self):self.assertEqual(len({(a,b) for row in WILLIAMS for a,b in zip(row,row[1:])}),12)
    def test_replica_design_not_full_factorial(self):self.assertEqual({c['rate'] for c in cells_for(make_design(),'replicas')},{4.})
    def test_selected_scope_explicit(self):self.assertIn('favorable',protocol()['selection_reason'])
    def test_old_anchor_excluded(self):self.assertFalse(protocol()['historical_anchor_pooled_as_new_repeat'])
    def test_wave_at8_is_single_burst(self):
        from semantic19.workflow import arrival_offsets
        m=arrival_metadata(8.,arrival_offsets(16,8,200201,'wave'))
        self.assertEqual(m['cycles_touched'],1);self.assertEqual(m['finite_first_to_last_rate'],16.)
    def test_wave_at10_is_single_burst(self):
        from semantic19.workflow import arrival_offsets
        m=arrival_metadata(10.,arrival_offsets(16,10,200201,'wave'));self.assertEqual(m['cycles_touched'],1)
    def test_config_does_not_mutate_original(self):
        b=copy.deepcopy(CFG);p={'3':{'p75':8}};c=config_for(b,p,make_design()[0]);self.assertEqual(b,CFG);self.assertEqual(c['base_cap'],4096)

class BindingTests(unittest.TestCase):
    def test_original_D0_function_is_not_wrapped(self):
        with bindings('DAG-Batch'):self.assertIs(client.process_plan,original)
    def test_A_reference_unchanged(self):
        old=client.reference
        with bindings('Affinity'):self.assertIs(client.reference,old)
    def test_D_reference_unchanged(self):
        old=client.reference
        with bindings('DAG-Fixed'):self.assertIs(client.reference,old)
    def test_RR_round_robin(self):
        a=rr_reference(snap(),CFG);self.assertEqual(list(a['placement'].values()),[0,1,2,3,0,1,2,3])
    def test_RR_resumes_after_dispatch(self):
        a=rr_reference(snap(count=3),CFG);self.assertEqual(list(a['placement'].values())[:4],[3,0,1,2])
    def test_RR_not_counter_per_call(self):
        s=snap(count=3);self.assertEqual(rr_reference(s,CFG),rr_reference(s,CFG))
    def test_RR_single_replica(self):self.assertEqual(set(rr_reference(snap(R=1),CFG)['placement'].values()),{0})
    def test_RR_three_replicas(self):self.assertEqual(list(rr_reference(snap(R=3),CFG)['placement'].values())[:6],[0,1,2,0,1,2])
    def test_RR_reservation_holds_prefix(self):
        s=snap();s['reserved_blocks'][0]=4096;a=rr_reference(s,CFG)
        self.assertEqual(a['admit'],[]);self.assertEqual(len(a['resource_held']),8)
    def test_binding_restored_on_error(self):
        before=client.reference,client.process_plan,client.make_snapshot
        with self.assertRaises(RuntimeError):
            with bindings('RR'):raise RuntimeError('test')
        self.assertEqual((client.reference,client.process_plan,client.make_snapshot),before)
    def test_RR_cursor_includes_done_workflow(self):
        nodes={'gone':{'start':1.,'state':'done'},'ready':{'start':None,'state':'ready'}}
        with patch('case23.binding._NATIVE_SNAPSHOT',return_value={}):
            self.assertEqual(rr_snapshot(nodes)['rr_submitted_count'],1)
