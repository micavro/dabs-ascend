import copy,tempfile,unittest,json
from pathlib import Path
from case23.report import build,gain,write
from case23.design import make_design,CORE
from case23.batchcheck import prefill_chunk
from case23.runner import inactive_proof,environment_same
from case23.common import atomic,sha,verify_files

def rows():
    ds=[c for c in make_design() if c['replicas']==4 and c['rate']==4 and c['method'] in CORE]
    vals={'RR':4000.,'Affinity':3000.,'DAG-Fixed':2700.,'DAG-Batch':2500.}
    rs=[]
    for c in ds:
        rs.append({**c,'segment':'s','external_work_sha256':'same_external','output_signature':c['method'],
          'summary':{'mean_jct_ms':vals[c['method']],'p95_jct_ms':vals[c['method']]+100.,'output_tokens':123,
          'requests':53,'semantic_quality':{'final_em':.25,'final_f1':.3},'mean_critical_path_components_ms':{}}})
    return rs

class ReportTests(unittest.TestCase):
    def test_partial_not_complete(self):self.assertFalse(build(rows(),make_design())['core_complete'])
    def test_no_history_as_repeat(self):
        self.assertTrue(all(r['completed_repeats']==4 for r in build(rows(),make_design())['aggregates']))
    def test_gain_direction(self):self.assertAlmostEqual(gain(3000,2500),16.6666666667)
    def test_zero_quality_denominator_is_null(self):self.assertIsNone(gain(0,.25,True))
    def test_coexistence(self):self.assertTrue(all(c['two_gains_positive'] for c in build(rows(),make_design())['coexistence']))
    def test_negative_not_removed(self):
        rs=rows()
        for r in rs:
            if r['method']=='DAG-Batch':r['summary']['mean_jct_ms']=9999.
        z=build(rs,make_design());self.assertFalse(any(c['two_gains_positive'] for c in z['coexistence']))
        self.assertTrue(all(c['combined_gain_pct']<0 for c in z['coexistence']))
    def test_duplicate_rejected(self):
        r=rows()
        with self.assertRaises(ValueError):build(r+r[:1],make_design())
    def test_external_mismatch_rejected(self):
        r=rows();r[0]['external_work_sha256']='different'
        with self.assertRaises(ValueError):build(r,make_design())
    def test_outputs_difference_preserved(self):self.assertTrue(any(not r['raw_outputs_identical'] for r in build(rows(),make_design())['paired_details']))
    def test_csv_and_readme_created(self):
        with tempfile.TemporaryDirectory() as d:
            write(d,rows(),make_design());self.assertTrue((Path(d)/'paired_gains.csv').exists())
            self.assertIn('不能替代', (Path(d)/'REPORT.md').read_text())
    def test_p95_not_filled(self):
        a=build(rows(),make_design())['aggregates'][0];self.assertIsNone(a['p95_client_tpot_proxy_ms_mean'])

class EvidenceEdgeTests(unittest.TestCase):
    def test_exact_tail13(self):self.assertEqual(prefill_chunk(13,13),13)
    def test_exact_tail31(self):self.assertEqual(prefill_chunk(31,31),31)
    def test_truncated_tail(self):self.assertEqual(prefill_chunk(17,15),0)
    def test_unused_replica_traffic_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'joint18v2';p.mkdir();(p/'spra-vllm-3.events.jsonl').write_text('{"event":"accept"}\n')
            with self.assertRaises(ValueError):inactive_proof(d,{3:0})
    def test_unused_replica_empty_ok(self):
        with tempfile.TemporaryDirectory() as d:self.assertTrue(inactive_proof(d,{1:0,2:0,3:0})['pass'])
    def test_unused_replica_log_truncation(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'joint18v2';p.mkdir();(p/'spra-vllm-1.events.jsonl').write_text('')
            with self.assertRaises(ValueError):inactive_proof(d,{1:100})
    def test_hash_guard(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'a';p.write_text('a');h=sha(p);p.write_text('b')
            with self.assertRaises(ValueError):verify_files(d,{'a':h})
