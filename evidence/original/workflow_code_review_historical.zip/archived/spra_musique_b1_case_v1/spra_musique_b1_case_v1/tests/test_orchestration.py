"""Temporary-filesystem/mock-service tests. Synthetic results are discarded."""
from __future__ import annotations
import asyncio,contextlib,copy,io,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from concurrent.futures import ThreadPoolExecutor
from helpers import CFG,MODEL,PRIORS,dataset,FakeTokenizer,fake_complete
from case23 import runner as E
from case23.common import atomic,sha,load
from case23.design import make_design

class FlowTests(unittest.IsolatedAsyncioTestCase):
    def start(self,td):
        root=Path(td);data=root/'data';records,dm=dataset(data);fr=root/'OLD';fr.mkdir()
        atomic(fr/'model.json',MODEL);atomic(fr/'priors.json',PRIORS)
        mf={'D0_configuration':CFG,'dataset':str(data),'dataset_files':dm['files'],
            'dataset_manifest_sha256':sha(data/'manifest.json'),'files':{'model.json':sha(fr/'model.json'),'priors.json':sha(fr/'priors.json')}}
        atomic(fr/'manifest.json',mf)
        (root/'configs').mkdir();atomic(root/'configs/block1_ids.json',[r['id'] for r in records])
        (root/'analysis').mkdir();atomic(root/'analysis/HISTORICAL_CONTEXT.json',{'SYNTHETIC_TEST':True})
        runtime=root/'runtime';runtime.mkdir();(runtime/'joint18v2').mkdir()
        env=[{'pod':f'spra-vllm-{r}','pid':100+r,'boot_id':'MOCK','launch_id':'MOCK',
              'hook_source_sha256':E.old.HOOK,'scheduler_source_sha256':'MOCK','nvidia_visible_devices':f'MOCK-{r}',
              'hard_total':4096,'max_model_len':4096,'max_num_seqs':64,'block_size':16,'num_gpu_blocks':4096,
              'num_scheduler_steps':1,'prefix_caching':True,'chunked_prefill':True,'native_cache_allocator':'v1'} for r in range(4)]
        async def gate(*a,**k):return copy.deepcopy(env)
        async def warm(*a,**k):return None
        async def drain(*a,**k):return True
        calls=[];fault={'at':None,'after_complete':False}
        async def execute(client,rt,initial,cfg,nodes,folder,method,model,**kw):
            calls.append(str(folder))
            n=len(calls)
            if fault['at']==n and not fault['after_complete']:raise RuntimeError('SYNTHETIC_INCOMPLETE')
            z=await fake_complete(folder,nodes,kw['materializer'],cfg,method,initial,
                    delay=3. if cfg['batching20_policy']=='mixed_1024' else 1.)
            if fault['at']==n:raise RuntimeError('SYNTHETIC_AFTER_COMPLETE')
            return z
        stack=contextlib.ExitStack()
        stack.enter_context(patch.object(E,'ROOT',root));stack.enter_context(patch.object(E,'own_identity',return_value={}))
        stack.enter_context(patch.object(E,'activate',return_value={}))
        stack.enter_context(patch.object(E.old,'load_frozen',return_value=(fr,mf,MODEL,PRIORS)))
        stack.enter_context(patch.object(E,'all_gate',side_effect=gate))
        stack.enter_context(patch.object(E,'warmup',side_effect=warm))
        stack.enter_context(patch.object(E.live,'wait_drained',side_effect=drain))
        stack.enter_context(patch.object(E.live,'execute',side_effect=execute))
        stack.enter_context(patch.object(E,'ServerTokenizer',side_effect=lambda *a:FakeTokenizer()))
        stack.enter_context(patch.object(E,'ProcessPoolExecutor',side_effect=lambda *a,**kw:ThreadPoolExecutor(1)))
        stack.enter_context(patch.object(E,'archive',side_effect=lambda out:{'synthetic_archive_not_delivered':True}))
        return root,runtime,calls,fault,stack

    async def test_prepare_freezes_case_without_model_call(self):
        with tempfile.TemporaryDirectory() as td:
            root,rt,calls,fault,stack=self.start(td)
            with stack,contextlib.redirect_stdout(io.StringIO()):
                out=E.prepare();E.check(out);self.assertEqual(calls,[])
                self.assertEqual(len(load(out/'protocol.json')['selected_ids']),16)
                self.assertEqual(E.prepare(),out)

    async def test_complete_declared_rate_slice_keeps_negative_runs(self):
        with tempfile.TemporaryDirectory() as td:
            root,rt,calls,fault,stack=self.start(td)
            with stack,patch.object(E,'cells_for',side_effect=lambda ds,ph:[c for c in ds if c['phase']==ph][:16]),contextlib.redirect_stdout(io.StringIO()):
                out=E.prepare();await E.run(out,rt,'rates')
                self.assertEqual(len(calls),16);res=load(out/'result.json')
                self.assertFalse(res['core_complete']);self.assertEqual(res['accepted_conditions'],16)
                self.assertTrue(any(r['combined_gain_pct']<0 for r in res['coexistence']))
                await E.run(out,rt,'rates');self.assertEqual(len(calls),16)

    async def test_incomplete_needs_explicit_retry_and_does_not_repeat_good(self):
        with tempfile.TemporaryDirectory() as td:
            root,rt,calls,fault,stack=self.start(td)
            with stack,patch.object(E,'cells_for',side_effect=lambda ds,ph:[c for c in ds if c['phase']==ph][:4]),contextlib.redirect_stdout(io.StringIO()):
                out=E.prepare();fault['at']=3
                with self.assertRaisesRegex(RuntimeError,'SYNTHETIC_INCOMPLETE'):await E.run(out,rt,'rates')
                self.assertEqual(len(E.index(out,make_design())),2)
                fault['at']=None
                with self.assertRaisesRegex(ValueError,'incomplete attempt'):await E.run(out,rt,'rates')
                self.assertEqual(len(calls),3)
                await E.run(out,rt,'rates',retry=True)
                self.assertEqual(len(calls),5)
                self.assertEqual(len(E.index(out,make_design())),4)
                self.assertEqual(len(E.units(out,make_design()[2]['label'])),2)

    async def test_completed_raw_recovers_without_generation(self):
        with tempfile.TemporaryDirectory() as td:
            root,rt,calls,fault,stack=self.start(td)
            with stack,patch.object(E,'cells_for',side_effect=lambda ds,ph:[c for c in ds if c['phase']==ph][:4]),contextlib.redirect_stdout(io.StringIO()):
                out=E.prepare();fault.update(at=2,after_complete=True)
                with self.assertRaisesRegex(RuntimeError,'SYNTHETIC_AFTER_COMPLETE'):await E.run(out,rt,'rates')
                self.assertEqual(len(calls),2);fault['at']=None
                await E.run(out,rt,'rates')
                self.assertEqual(len(calls),4);self.assertEqual(len(E.index(out,make_design())),4)

    async def test_ablation_no_hidden_missing_main_baseline(self):
        with tempfile.TemporaryDirectory() as td:
            root,rt,calls,fault,stack=self.start(td)
            with stack,contextlib.redirect_stdout(io.StringIO()):
                out=E.prepare()
                with self.assertRaisesRegex(ValueError,'run_rates'):await E.run(out,rt,'ablations')
                self.assertEqual(calls,[])

    async def test_model_modified_after_freeze_stops(self):
        with tempfile.TemporaryDirectory() as td:
            root,rt,calls,fault,stack=self.start(td)
            with stack,contextlib.redirect_stdout(io.StringIO()):
                out=E.prepare();atomic(root/'OLD/model.json',{'wrong':True})
                with self.assertRaises(ValueError):await E.run(out,rt,'rates')
                self.assertEqual(calls,[])

    async def test_all136_conditions_and_shared_R4anchor(self):
        with tempfile.TemporaryDirectory() as td:
            root,rt,calls,fault,stack=self.start(td)
            with stack,contextlib.redirect_stdout(io.StringIO()):
                out=E.prepare();await E.run(out,rt,'all');r=load(out/'result.json')
                self.assertEqual(len(calls),136);self.assertTrue(r['complete']);self.assertTrue(r['core_complete'])
                anchor=[c for c in load(out/'index.json') if c['replicas']==4 and c['rate']==4 and c['phase']=='rates']
                self.assertEqual(len(anchor),16)
                await E.run(out,rt,'all');self.assertEqual(len(calls),136)

    async def test_complete_bad_check_cannot_retry(self):
        with tempfile.TemporaryDirectory() as td:
            root,rt,calls,fault,stack=self.start(td)
            with stack,contextlib.redirect_stdout(io.StringIO()):
                out=E.prepare();fault.update(at=1,after_complete=True)
                with self.assertRaises(RuntimeError):await E.run(out,rt,'rates')
                u=E.units(out,make_design()[0]['label'])[0]
                s=load(u/'raw/summary.json');s['request_correlation']='BAD';atomic(u/'raw/summary.json',s)
                fault['at']=None
                with self.assertRaisesRegex(ValueError,'correspondence'):await E.run(out,rt,'rates',True)
                self.assertEqual(len(calls),1)
