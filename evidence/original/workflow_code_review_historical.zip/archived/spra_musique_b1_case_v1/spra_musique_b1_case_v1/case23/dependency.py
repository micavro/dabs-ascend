"""Exact read-only loading of the already installed D0/typed/batching code."""
from __future__ import annotations
import os, sys
from pathlib import Path
from .common import load, sha
ROOT=Path(__file__).resolve().parents[1]
BATCH=Path(os.environ.get('MUSIQUE_BATCH_SOURCE',ROOT.parent/'spra_musique_d0_batching_v1')).resolve()

def activate():
    sys.dont_write_bytecode=True
    expected=load(ROOT/'dependency_identity.json')
    for rel,h in expected.items():
        p=BATCH/rel
        if not p.is_file() or sha(p)!=h:raise RuntimeError('frozen batching dependency missing/different: '+str(p)+'; do not redeploy or edit expected hashes')
    if str(BATCH) not in sys.path:sys.path.insert(0,str(BATCH))
    from batching20.dependency import activate as previous_activate, verify, own_identity
    previous_activate()
    return {'source':verify(),'batch':own_identity()}

def own_identity():
    fixed=['case23','tools','tests','configs']
    out={}
    for name in fixed:
        for p in sorted((ROOT/name).rglob('*')):
            if p.is_file() and p.suffix in ('.py','.json','.sh') and '__pycache__' not in p.parts:out[str(p.relative_to(ROOT))]=sha(p)
    for p in [ROOT/'dependency_identity.json',*ROOT.glob('*.sh')]:out[p.name]=sha(p)
    return out
