"""Validate physical execution evidence; descriptive mechanisms are not causal claims."""
from __future__ import annotations
import math, statistics
from collections import Counter
from pathlib import Path
from .common import atomic,load,files,verify_files,jsonl
from .audit import condition_verdict
from .design import METHODS
from .dependency import activate
activate()
from batching20 import telemetry
from typed19.quality import evaluate as quality_evaluate

def validate(raw,cell,cfg,packets,proof,model):
    raw=Path(raw)
    verdict=condition_verdict(raw)
    if not verdict.get('accepted'):return verdict
    ns=load(raw/'nodes.json');m=load(raw/'manifest.json');s=load(raw/'summary.json')
    if m['config']!=cfg or m['method']!=cell['scheduler'] or m.get('model_id')!=model.get('model_id'):
        raise ValueError('runtime config/method/model differs from frozen input')
    if load(raw/'status.json')['execution']!='complete':raise ValueError('not completed')
    expected={}
    for wi,p in enumerate(packets):
        keys=[f'w{wi:04d}/step{i+1}' for i in range(len(p['steps']))]
        for st in p['steps']:
            k=keys[st['position']];expected[k]=(p['id'],[keys[i] for i in st['parents']],proof['arrivals'][wi])
    if set(ns)!=set(expected) or set(m['input_nodes'])!=set(expected):raise ValueError('wrong workflow node set')
    if proof['ids']!=[p['id'] for p in packets]:raise ValueError('different question cohort')
    for k,(qid,parents,offset) in expected.items():
        for n in (ns[k],m['input_nodes'][k]):
            if n['dataset_id']!=qid or n['parents']!=parents or not math.isclose(n['arrival_offset'],offset,abs_tol=1e-10):raise ValueError('question/graph/arrival mismatch')
        if not 0<=ns[k]['replica']<cell['replicas']:raise ValueError('request used inactive replica')
    groups={}
    for n in ns.values():groups.setdefault(n['wid'],[]).append(n)
    jc=[1000*(max(n['finish'] for n in v)-v[0]['arrival']) for v in groups.values()]
    output=sum(n['stream']['usage']['completion_tokens'] for n in ns.values())
    if output!=s['output_tokens'] or len(groups)!=s['workflows'] or len(ns)!=s['requests']:raise ValueError('count mismatch')
    if not math.isclose(statistics.mean(jc),s['mean_jct_ms'],abs_tol=1e-5,rel_tol=1e-8):raise ValueError('JCT boundary differs; not retimed')
    controls={p['plan_id']:p for p in load(raw/'controls.json')};accepts={}
    cap=int(cell['policy'].split('_')[1]) if cell['policy'].startswith('fixed_') else None
    for e in jsonl(raw/'backend.jsonl'):
        if e.get('event')=='accept':accepts.setdefault(e['prompt_hash'],[]).append(e)
        if e.get('event')!='iteration' or not e.get('scheduled'):continue
        if e['total']!=4096:raise ValueError('hard total changed')
        if cap is not None and e.get('prefill_cap')!=cap:raise ValueError('fixed cap not maintained')
        if not 0<=e['replica']<cell['replicas']:raise ValueError('inactive replica event')
        if e.get('plan_reason')=='lease_ok':
            p=controls.get(e['plan_id'])
            if p is None:raise ValueError('missing control')
            t=e.get('effective_ns',e['begin_ns']);active=p['not_before_ns']<=t<p['action_expires_ns']
            want=p['caps'][e['replica']] if active else cfg['base_cap']
            if e['prefill_cap']!=want or (e['execution_phase']=='current_action')!=active:raise ValueError('cap lifetime mismatch')
    for n in ns.values():
        a=accepts.get(n['hash'],[])
        if len(a)!=1 or a[0]['replica']!=n['replica']:raise ValueError('native request route mismatch')
    if cell['method']=='RR':
        dispatched=sorted(ns.values(),key=lambda n:n['start'])
        if any(n['replica']!=i%cell['replicas'] for i,n in enumerate(dispatched)):
            raise ValueError('RR did not follow actual dispatch order')
    verdict.update(question_count=len(groups),actual_requests=len(ns),actual_output_tokens=output,
       complete_JCT_matches_nodes=True,active_replica_limit_verified=True,
       native_routes_verified=True,RR_dispatch_verified=cell['method']=='RR',
       no_performance_gain_required=True)
    return verdict

def mechanisms(raw,derived,cell):
    derived=Path(derived);derived.mkdir(exist_ok=True,parents=True)
    old=telemetry.atomic
    def save(path,obj):
        if Path(path).name!='batching_evidence.json':raise ValueError('unexpected telemetry write')
        atomic(derived/'batching_evidence.json',obj)
    telemetry.atomic=save
    try:z=telemetry.inspect_condition(raw,cell['policy'],cell['scheduler'])
    finally:telemetry.atomic=old
    ns=load(Path(raw)/'nodes.json');plans=list(jsonl(Path(raw)/'plans.jsonl'))
    roles={};workflow=[]
    for k,n in ns.items():
        roles.setdefault(str(n['replica']),0);roles[str(n['replica'])]+=1
    groups={}
    for n in ns.values():groups.setdefault(n['wid'],[]).append(n)
    for wid,v in sorted(groups.items()):
        workflow.append({'wid':wid,'dataset_id':v[0]['dataset_id'],
           'jct_ms':1000*(max(n['finish'] for n in v)-v[0]['arrival']),
           'output_tokens':sum(n['stream']['usage']['completion_tokens'] for n in v),
           'routes':{n['name']:n['replica'] for n in v}})
    z['route_assignments']=roles
    z['commit_fallback_reason_counts']=dict(Counter(str(p['commit_fallback']) for p in plans if p.get('commit_fallback')))
    z['causal_counterfactual_from_trace_claimed']=False
    z['historical_question_answers_replayed']=False
    z['D0_schedule_integrity_applicable']=cell['scheduler']=='D'
    if cell['scheduler']!='D':z['D0_schedule_integrity']['claim']='not applicable: A or RR (no D0 invocation)'
    atomic(derived/'workflow_details.json',workflow)
    atomic(derived/'mechanisms.json',z)
    return z

def output_signature(nodes):
    from .common import digest
    return digest([(k,n['stream']['text'],n['stream']['usage']['completion_tokens']) for k,n in sorted(nodes.items())])

def accepted_row(unit):
    unit=Path(unit);receipt=load(unit/'accepted.json')
    if receipt.get('measurement_accepted') is not True:raise ValueError('unaccepted attempt')
    verify_files(unit/'raw',receipt['raw_hashes'],exact=True)
    verify_files(unit,receipt['derived_hashes'])
    row=load(unit/'row.json')
    if row['label']!=receipt['label']:raise ValueError('acceptance label mismatch')
    return row
