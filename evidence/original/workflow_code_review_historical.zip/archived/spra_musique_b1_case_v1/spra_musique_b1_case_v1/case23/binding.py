"""Local binding: D0/C unchanged; RR alone replaces the A reference router.
No source files, clocks, native guards, or live backend code are modified.
"""
from __future__ import annotations
import copy
from contextlib import contextmanager
from .dependency import activate
activate()
from .batchcheck import compare_iteration
from batching20.policy import process_plan
from typed19.transport import stream
from joint18v2.actions import resources
from joint18v2.common import validate_action
import joint18v2.client as client
_NATIVE_REFERENCE=client.reference
_NATIVE_SNAPSHOT=client.make_snapshot

def rr_snapshot(nodes,*args,**kwargs):
    snap=_NATIVE_SNAPSHOT(nodes,*args,**kwargs)
    # Count only actually submitted requests, including completed workflows removed
    # from the current snapshot. Re-evaluation/fallback never advances a cursor.
    snap['rr_submitted_count']=sum(n.get('start') is not None for n in nodes.values())
    return snap

def rr_reference(s,cfg):
    r=s['replicas'];ready=sorted(s['ready'],key=lambda k:(s['nodes'][k]['ready_at'],k))
    start=s['rr_submitted_count']
    action={'family':'RR_FIFO','placement':{k:(start+i)%r for i,k in enumerate(ready)},
            'admit':list(ready),'order':[],'caps':[cfg['base_cap']]*r}
    a=resources(action,s,cfg)
    # RR follows actual admission order. When a designated next replica cannot
    # reserve a request, preserve the FIFO prefix rather than skip the RR cursor.
    allowed=set(a['admit']);prefix=[]
    for k in ready:
        if k not in allowed:break
        prefix.append(k)
    a['admit']=prefix;a['resource_held']=[k for k in ready if k not in set(prefix)]
    validate_action(a,s,cfg);return a

@contextmanager
def bindings(method):
    old=client.process_plan,client.stream,client.compare_iteration,client.reference,client.make_snapshot
    client.process_plan=process_plan;client.stream=stream;client.compare_iteration=compare_iteration
    if method=='RR':client.reference=rr_reference;client.make_snapshot=rr_snapshot
    try:yield
    finally:client.process_plan,client.stream,client.compare_iteration,client.reference,client.make_snapshot=old
