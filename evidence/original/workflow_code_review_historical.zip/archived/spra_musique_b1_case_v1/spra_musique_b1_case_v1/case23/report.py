from __future__ import annotations
import csv, math, statistics
from collections import defaultdict
from pathlib import Path
from .common import atomic
from .design import CORE,VARIANTS
METRICS=('mean_jct_ms','p95_jct_ms','mean_request_ttft_ms','p95_request_ttft_ms',
 'mean_node_time_to_first_content_ms','p95_node_time_to_first_content_ms',
 'mean_client_tpot_proxy_ms','p95_client_tpot_proxy_ms','cohort_workflows_s','cohort_tokens_s','cohort_duration_s')

def stat(vals):
    a=[float(x) for x in vals if x is not None and math.isfinite(float(x))]
    return {'n':len(a),'mean':statistics.mean(a) if a else None,
            'sd':statistics.stdev(a) if len(a)>1 else None,
            'min':min(a) if a else None,'max':max(a) if a else None}

def gain(base,new,higher=False):
    if base is None or new is None or base<=0:return None
    return 100*((new/base-1) if higher else (1-new/base))

def csvfile(path,rows,fields=None):
    rows=list(rows);fields=fields or sorted({k for r in rows for k in r})
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

def build(rows,design):
    by={r['label']:r for r in rows}
    if len(by)!=len(rows):raise ValueError('duplicate accepted condition')
    if not set(by)<=set(c['label'] for c in design):raise ValueError('result outside design')
    grouped=defaultdict(list);pairs=defaultdict(dict)
    for r in rows:
        c=r;grouped[(c['replicas'],c['rate'],c['method'])].append(r)
        pairs[(c['replicas'],c['rate'],c['repeat'])][c['method']]=r
    aggregates=[];details=[];phase_rows=[]
    for (R,L,M),rs in sorted(grouped.items()):
        a={'replicas':R,'rate':L,'method':M,'completed_repeats':len(rs),'expected_repeats':4}
        for f in METRICS:
            for k,v in stat([r['summary'].get(f) for r in rs]).items():a[f+'_'+k]=v
        for q in ('final_em','final_f1'):
            for k,v in stat([r['summary'].get('semantic_quality',{}).get(q) for r in rs]).items():a[q+'_'+k]=v
        aggregates.append(a)
        parts=sorted({p for r in rs for p in r['summary'].get('mean_critical_path_components_ms',{})})
        for p in parts:
            phase_rows.append({'replicas':R,'rate':L,'method':M,'phase':p,**stat([r['summary'].get('mean_critical_path_components_ms',{}).get(p) for r in rs])})
    comparisons=[('DAG-Fixed','Affinity','scheduling'),('DAG-Batch','DAG-Fixed','batching'),
                 ('DAG-Batch','Affinity','combined'),('DAG-Batch','RR','vs_RR')]
    for m in VARIANTS:comparisons.append((m,'DAG-Batch','ablation_vs_main'))
    coexist=[]
    for (R,L,T),g in sorted(pairs.items()):
        for candidate,baseline,kind in comparisons:
            if candidate not in g or baseline not in g:continue
            n,b=g[candidate],g[baseline]
            if n['external_work_sha256']!=b['external_work_sha256']:raise ValueError('paired external inputs differ')
            rec={'replicas':R,'rate':L,'repeat':T,'candidate':candidate,'baseline':baseline,'comparison':kind,
               'cross_segment':n['segment']!=b['segment'],
               'JCT_saved_ms':b['summary']['mean_jct_ms']-n['summary']['mean_jct_ms'],
               'raw_outputs_identical':n['output_signature']==b['output_signature'],
               'output_tokens_base':b['summary']['output_tokens'],'output_tokens_candidate':n['summary']['output_tokens']}
            for f in METRICS:rec[f+'_gain_pct']=gain(b['summary'].get(f),n['summary'].get(f),f in ('cohort_workflows_s','cohort_tokens_s'))
            for q in ('final_em','final_f1'):
                x=b['summary'].get('semantic_quality',{}).get(q);y=n['summary'].get('semantic_quality',{}).get(q)
                rec[q+'_relative_improvement_pct']=gain(x,y,True)
                rec[q+'_difference_percentage_points']=100*(y-x) if x is not None and y is not None else None
            details.append(rec)
        if all(k in g for k in ('Affinity','DAG-Fixed','DAG-Batch')):
            A,D,C=(g[k]['summary']['mean_jct_ms'] for k in ('Affinity','DAG-Fixed','DAG-Batch'))
            coexist.append({'replicas':R,'rate':L,'repeat':T,'two_gains_positive':C<D<A,
              'scheduling_gain_pct':gain(A,D),'batching_gain_pct':gain(D,C),'combined_gain_pct':gain(A,C),
              'combined_above10pct':gain(A,C)>10.})
    gp=defaultdict(list)
    for r in details:gp[(r['replicas'],r['rate'],r['candidate'],r['baseline'],r['comparison'])].append(r)
    paired=[]
    for (R,L,M,B,K),rr in sorted(gp.items()):
        row={'replicas':R,'rate':L,'candidate':M,'baseline':B,'comparison':K,
             'paired_repeats':len(rr),'cross_segment_pairs':sum(r['cross_segment'] for r in rr)}
        for f in ('JCT_saved_ms',*[x+'_gain_pct' for x in METRICS]):
            for k,v in stat([r[f] for r in rr]).items():row[f+'_'+k]=v
        paired.append(row)
    return {'schema':'musique-B1-sensitivity-result-1','scope':'selected MuSiQue Block1 16-question case study',
      'selection_after_historical_favorable_result':True,'all_MuSiQue_generalization_claimed':False,
      'implementation_frozen_as_C_before_new_measurements':True,'per_cell_best_of_Joint_and_C':False,
      'old12_68pct_in_new_aggregate':False,'accepted_conditions':len(rows),'planned_conditions':len(design),
      'core_complete':all(c['label'] in by for c in design if c['phase']!='ablations'),
      'optional_ablations_complete':all(c['label'] in by for c in design if c['phase']=='ablations'),
      'complete':len(rows)==len(design),'whole_dataset_statistical_claim':False,
      'errorbars':'sample SD across repeated executions of the same16 questions; not new questions or token-ITL CI',
      'outcomes_kept_regardless_of_sign':True,'capacity_established':False,
      'aggregates':aggregates,'paired_aggregates':paired,'paired_details':details,
      'coexistence':coexist,'critical_path_components':phase_rows}

def write(out,rows,design):
    out=Path(out);out.mkdir(exist_ok=True,parents=True);r=build(rows,design);atomic(out/'result.json',r)
    flat=[]
    for c in rows:
        s=c['summary'];row={k:c[k] for k in ('label','phase','replicas','rate','repeat','method','segment')}
        row.update({f:s.get(f) for f in METRICS});row.update(output_tokens=s['output_tokens'],requests=s['requests'],
                final_em=s.get('semantic_quality',{}).get('final_em'),final_f1=s.get('semantic_quality',{}).get('final_f1'))
        flat.append(row)
    csvfile(out/'conditions.csv',flat);csvfile(out/'aggregates.csv',r['aggregates']);csvfile(out/'paired_gains.csv',r['paired_details'])
    csvfile(out/'paired_aggregates.csv',r['paired_aggregates']);csvfile(out/'components.csv',r['critical_path_components'])
    lines=['# MuSiQue-B1-16：选定案例集结果','',
      '**范围：Block1在看到历史正结果之后被选中。本报告不能替代完整MuSiQue数据集结果。**',
      'DAG-Batch始终为原C（D₀＋Mixed1024），不逐测试点挑选Joint/C，不删除负值。',
      '历史12.68%为案例来源，不进入新的重复统计；既有四块整体接近零的结果保留在历史文件。','',
      f"主实验完成：{r['core_complete']}；额外消融完成：{r['optional_ablations_complete']}；接受{len(rows)}/{len(design)}格。",'',
      'R表示实际可路由副本数，始终使用物理副本0..R−1。其他服务保持启动但不接收被测生成请求。',
      'x轴rate为原周期波形的配置均值；N16在8/s与10/s下只覆盖第一段突发，并非稳态吞吐。',
      '同一16题、同一到达顺序重复四次；误差条为执行间标准差，不代表独立新题抽样误差。',
      '固定4096是共同回归参照，不宣称每种新负载下均为调优最优。所有控制成本计入JCT。','',
      '|副本|到达率|方法|JCT均值 ms|执行间SD ms|重复数|','|---:|---:|---|---:|---:|---:|']
    for a in r['aggregates']:
        sd=a['mean_jct_ms_sd'];lines.append(f"|{a['replicas']}|{a['rate']}|{a['method']}|{a['mean_jct_ms_mean']:.3f}|{sd:.3f}|{a['completed_repeats']}|" if sd is not None else f"|{a['replicas']}|{a['rate']}|{a['method']}|{a['mean_jct_ms_mean']:.3f}|N/A|{a['completed_repeats']}|")
    lines+=['','主比较分别报告调度(DAG-Fixed/Affinity)、batching(DAG-Batch/DAG-Fixed)、组合(DAG-Batch/Affinity)和RR。',
       'TTFT/TPOT/质量是辅助指标，不要求全部改善；TPOT保留客户端代理定义和有效样本数。',
       '每个条件的mechanisms.json记录实际放置与额度活动；这些观察不是每个动作的独立反事实。',
       '中断或失败保留attempt；只有预声明全部条件完成才称完整，不能按收益重试或提前停止。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return r
