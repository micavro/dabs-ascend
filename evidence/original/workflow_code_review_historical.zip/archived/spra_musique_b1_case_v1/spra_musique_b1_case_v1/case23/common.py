from __future__ import annotations
import hashlib, json, os, time, uuid
from pathlib import Path

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def digest(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def load(path): return json.loads(Path(path).read_text(encoding='utf-8'))

def atomic(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    t=p.with_name(p.name+'.tmp.'+uuid.uuid4().hex)
    try:
        with t.open('w',encoding='utf-8') as f:
            json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
        os.replace(t,p)
    finally:
        if t.exists():t.unlink()

def stamp(prefix):return prefix+'_'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'_'+uuid.uuid4().hex[:8]

def files(root):
    root=Path(root)
    return {str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts}

def verify_files(root,expected,exact=False):
    root=Path(root)
    for n,h in expected.items():
        if not (root/n).is_file() or (root/n).is_symlink() or sha(root/n)!=h:raise ValueError('file identity differs: '+str(root/n))
    if exact and files(root)!=expected:raise ValueError('record file set changed: '+str(root))

def jsonl(path):
    with Path(path).open(encoding='utf-8') as f:
        for i,line in enumerate(f,1):
            if line.strip():
                try:yield json.loads(line)
                except ValueError as e:raise ValueError(f'{path}:{i}: malformed JSON') from e

def compact(s):
    return {k:v for k,v in s.items() if k not in ('workflow_rows','unfinished_workflow_curve','request_latency_rows','quality_rows','typed_response_rows')}
