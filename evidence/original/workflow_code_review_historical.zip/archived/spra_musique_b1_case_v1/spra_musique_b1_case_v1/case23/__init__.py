"""Selected MuSiQue Block-1 sensitivity case; not a whole-dataset claim."""
REVISION = 'musique-B1-case-1'
CHECKER_REVISION = 'native-tail-capacity-check-1'
