"""Freeze the selected CASE, not a performance oracle or a dataset-wide result."""
from __future__ import annotations
import copy
from .common import digest,load
from .dependency import ROOT
CORE=('RR','Affinity','DAG-Fixed','DAG-Batch')
VARIANTS=('DAG-F1024','DAG-M2048','DAG-Completion')
METHODS={
 'RR':{'scheduler':'A','policy':'fixed_4096','routing':'request_round_robin'},
 'Affinity':{'scheduler':'A','policy':'fixed_4096','routing':'original_A'},
 'DAG-Fixed':{'scheduler':'D','policy':'fixed_4096','routing':'original_D0'},
 'DAG-Batch':{'scheduler':'D','policy':'mixed_1024','routing':'original_D0'},
 'DAG-F1024':{'scheduler':'D','policy':'fixed_1024','routing':'original_D0'},
 'DAG-M2048':{'scheduler':'D','policy':'mixed_2048','routing':'original_D0'},
 'DAG-Completion':{'scheduler':'D','policy':'completion_1024','routing':'original_D0'},
}
# Each main method occurs once in each position. All directed adjacent pairs once.
WILLIAMS=((0,1,3,2),(1,2,0,3),(2,3,1,0),(3,0,2,1))
ABLATION_ORDERS=((0,1,2),(1,2,0),(2,0,1),(2,1,0))

def protocol(): return load(ROOT/'configs/protocol.json')

def make_design(p=None):
    p=p or protocol()
    if p['repeats']!=4 or p['N']!=16 or p['rates']!=[2.,4.,8.,10.] or p['replica_counts']!=[1,2,3,4]:raise ValueError('unexpected frozen case design')
    result=[]
    def add(r,rate,phase,methods,repeat,indices):
        for pos,i in enumerate(indices,1):
            method=methods[i]
            result.append({'label':f'R{r}_L{int(rate)}_T{repeat}_{method}',
                'phase':phase,'replicas':r,'active_replica_ids':list(range(r)),
                'rate':float(rate),'repeat':repeat,'position':pos,'method':method,
                **METHODS[method],'N':16,'source_block':1,'seed':200201,'packet_slice':[0,16]})
    # Separate axes; R4/L4 is executed ONCE, later reused by scaling plots.
    for repeat in range(1,5):
        rates=p['rates'][repeat-1:]+p['rates'][:repeat-1]
        for rate in rates:add(4,rate,'rates',CORE,repeat,WILLIAMS[repeat-1])
    for repeat in range(1,5):
        sizes=[1,2,3];shift=(repeat-1)%3;sizes=sizes[shift:]+sizes[:shift]
        for r in sizes:add(r,4.,'replicas',CORE,repeat,WILLIAMS[repeat-1])
    for repeat in range(1,5):
        rates=[4.,8.] if repeat%2 else [8.,4.]
        for rate in rates:add(4,rate,'ablations',VARIANTS,repeat,ABLATION_ORDERS[repeat-1])
    if len({c['label'] for c in result})!=len(result):raise ValueError('duplicate condition')
    return result

def cells_for(design,phase):
    if phase=='all':return list(design)
    if phase=='core':return [c for c in design if c['phase'] in ('rates','replicas')]
    if phase not in ('rates','replicas','ablations'):raise ValueError('unknown phase')
    return [c for c in design if c['phase']==phase]

def config_for(base,priors,cell):
    c=copy.deepcopy(base);policy=cell['policy']
    c.update(replicas=cell['replicas'],workflow_count=16,arrival_rate=cell['rate'],
             base_cap=int(policy.split('_')[1]) if policy.startswith('fixed_') else 4096,
             batching20_policy=policy,batching20_output_priors=copy.deepcopy(priors))
    return c

def arrival_metadata(rate,offsets):
    span=offsets[-1]-offsets[0]
    return {'configured_cycle_mean_workflows_s':float(rate),'wave_active_rate':2*rate,
      'shape':'1s at 2*rate, then 1s idle; last partial cycle truncated after N16',
      'arrival_offsets_s':offsets,'first_arrival_s':offsets[0],'last_arrival_s':offsets[-1],
      'first_to_last_s':span,'finite_first_to_last_rate':(len(offsets)-1)/span if span else None,
      'cycles_touched':len({int(x//2) for x in offsets}),
      'finite_sample_rate_not_same_as_cycle_mean':True,'arrival_shape_not_production_trace':True}

def external_identity(packets,proof):
    obj={'ids':[p['id'] for p in packets],'arrival_offsets':proof['arrivals'],
         'evidence_hashes':[p['evidence_hash'] for p in packets],
         'graphs':[p['graph'] for p in packets], 'output_protocol':'typed_JSON_natural_EOS_max96'}
    return digest(obj)
