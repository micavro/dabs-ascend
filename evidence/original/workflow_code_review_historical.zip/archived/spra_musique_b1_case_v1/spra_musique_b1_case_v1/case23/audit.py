"""Post-run verification only. Never edits historical results or guesses missing data."""
from __future__ import annotations
import hashlib
import json
from collections import Counter
from pathlib import Path
from .batchcheck import compare_iteration
from .dependency import sha


def jsonl(path):
    with Path(path).open() as f:
        for line_no, line in enumerate(f, 1):
            if line.strip():
                try: yield json.loads(line)
                except ValueError as exc: raise ValueError(f'{path}:{line_no}: malformed JSON') from exc


def condition_verdict(folder):
    folder = Path(folder)
    required = ('nodes.json','backend.jsonl','summary.json','manifest.json','trace_capture.json')
    missing = [n for n in required if not (folder/n).is_file()]
    if missing:
        return {'accepted': False, 'folder': str(folder), 'classification': 'insufficient_evidence', 'missing': missing}
    hashes = {n: sha(folder/n) for n in required}
    nodes = json.loads((folder/'nodes.json').read_text())
    summary = json.loads((folder/'summary.json').read_text())
    capture = json.loads((folder/'trace_capture.json').read_text())
    errors = []
    for key in ('condition_valid','budget_invariants','control_time_match'):
        if summary.get(key) is not True: errors.append(key)
    if summary.get('request_correlation') != f'{len(nodes)}/{len(nodes)}': errors.append('request_correlation')
    if not nodes or any(n.get('state') != 'done' for n in nodes.values()): errors.append('incomplete_nodes')
    if capture.get('partial_lines',0) or capture.get('condition_failed'): errors.append('trace_capture_incomplete')
    for n in nodes.values():
        for parent in n.get('parents',[]):
            p = nodes[parent]
            b = n.get('parent_response_bindings',{}).get(str(p['step_position']+1))
            if not b or b.get('response') != p.get('stream',{}).get('text'): errors.append('parent_binding')
            if n.get('start') is not None and p.get('finish') is not None and n['start'] + 1e-6 < p['finish']:
                errors.append('dependency_timing')
    checks=[]; keys=set(); duplicate=False
    for event in jsonl(folder/'backend.jsonl'):
        if event.get('event') != 'iteration' or not event.get('scheduled'): continue
        key=tuple(event.get(k) for k in ('replica','pid','case','iteration'))
        if key in keys: duplicate=True
        keys.add(key)
        c=compare_iteration(event)
        if not c['match'] or c.get('legacy_match') is False:
            c['source_iteration']=event
        checks.append(c)
    if duplicate: errors.append('duplicate_iteration_identity')
    if not checks: errors.append('no_iterations')
    if len(checks)!=summary.get('native_next_batch_checked'): errors.append('iteration_count_changed')
    rejected=[c for c in checks if not c['match']]
    if rejected: errors.append('batch_correspondence_not_resolved')
    unchanged=all(sha(folder/n)==h for n,h in hashes.items())
    if not unchanged: errors.append('source_changed_during_read')
    return {'schema':'joint21-condition-verdict-1','folder':str(folder.resolve()),
            'accepted':not errors,'errors':sorted(set(errors)),
            'classification_counts':dict(Counter(c['classification'] for c in checks)),
            'iterations':len(checks),'matches':sum(c['match'] for c in checks),
            'legacy_matches':sum(c.get('legacy_match',False) for c in checks),
            'corrected_tail_rows':[c for c in checks if c['classification']=='matched_tail_rule_correction'],
            'unresolved_rows':rejected,'source_hashes':hashes,'source_files_unchanged':unchanged,
            'measured_performance_recomputed':False,'performance_values_changed':False,
            'GPU_REQUESTS':0,'NETWORK_REQUESTS':0,'LIVE_RUNTIME_READS':0,'LIVE_CHANGES':0}


def revalidate_suite(suite):
    suite=Path(suite)
    if not (suite/'frozen_protocol.json').is_file(): raise FileNotFoundError('missing original frozen_protocol.json: '+str(suite))
    candidates=sorted(p for p in suite.iterdir() if p.is_dir() and p.name.startswith('R'))
    if not candidates: raise ValueError('no saved measured conditions in interrupted suite')
    verdicts=[condition_verdict(p) for p in candidates]
    selected_files=['frozen_protocol.json','index.json','suite_status.json','cleanup.json']
    sources={n:sha(suite/n) for n in selected_files if (suite/n).is_file()}
    if not (suite/'cleanup.json').is_file(): raise ValueError('old suite has no cleanup evidence')
    clean=json.loads((suite/'cleanup.json').read_text())
    accepted=all(v['accepted'] for v in verdicts) and clean.get('backend_drained') is True
    return {'schema':'joint21-prior-readback-1','old_suite':str(suite.resolve()),'all_saved_conditions_revalidated':accepted,
            'old_suite_completed_by_this_tool':False,'old_result_files_modified':False,
            'saved_conditions':len(verdicts),'accepted_conditions':sum(v['accepted'] for v in verdicts),
            'conditions':verdicts,'suite_source_hashes':sources,
            'remaining_original_conditions_generated':0,'GPU_REQUESTS':0,'NETWORK_REQUESTS':0,'LIVE_CHANGES':0}
