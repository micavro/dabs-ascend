# MuSiQue-B1-16：到达率、副本数与Batching消融

**固定原Block1的16题/53个LLM节点，研究该选定案例集的重复性与适用条件。**
该子集是看到历史正结果之后选定，不能据此代表整个MuSiQue。历史12.68%作为案例来源保存，不当作本轮第5次重复；旧四块（包括负结果）不删除。

## 方法名称
|图表名|原实现|额度|
|---|---|---|
|RR|请求提交顺序轮询；不运行模型搜索|固定4096|
|Affinity|原A|固定4096|
|DAG-Fixed|原D₀|固定4096|
|DAG-Batch|原C：D₀＋Mixed1024|默认4096，满足原混合竞争条件时1024|

**本轮提前固定C为主方法，不能逐测试点取Joint/C更小值。**这验证工作流感知调度与自适应batching的组合，不冒称更强同步搜索已胜过同组件顺序组合。

## 矩阵
- `run_rates.sh`：R=4，rate=2/4/8/10，各4方法×4重复，64格。
- `run_replicas.sh`：rate=4，新增R=1/2/3，各4方法×4重复，48格。R4点复用上一步，不再生成。
- `run_ablations.sh`：可选；R4、rate4/8，额外fixed1024、Mixed2048、Completion1024三种D₀变体×4重复，24格。

主实验112格，全部含消融136格。每格固定同16题、同原图，共53个LLM请求；自然生成tokens不强制相同。主实验最多5936个正式请求，含消融7208个，预热另计。四次是同题同顺序的新执行，不是四个新Block。

N16在8/s、10/s的原wave下只经历首段突发。图横轴是配置周期均值，真实offset和首尾跨度单独记录；不声称稳态最大容量。详细约定见`docs/CASE_CONTRACT.md`。

## 前提与目录
代码放在GPU39：
`/home/wmy/sci/spra_paper_experiments_github/spra_musique_b1_case_v1`

旁边应保留已有的：
- `spra_musique_d0_batching_v1`（原D₀/Mixed实现及prepared/latest.json）；
- `spra_stage19_typed_handoff_v1`；
- `spra_stage19_musique_joint_v1`（含现有compiled MuSiQue数据）。

读取既有冻结模型，不重拟合；准备过程将该16题的完整公开输入导出为`frozen/selected.public.json`，DAG和文档一并保留。不会下载新数据、复制模型权重或将标准答案交给调度器。原标签只用于请求全部结束后的评分。

后端沿用`/home/wmy/sci/spra_core_exp/joint_e1`。接口为127.0.0.1:8000–8003；四张GPU需保持独占。不同R使用前R个实例，不删除Pod。不要stage/run_apply/重启。非活跃副本不得运行其他被测任务，程序会核对其新增生成事件。

## 开始
```bash
conda activate spra-exp
cd /home/wmy/sci/spra_paper_experiments_github/spra_musique_b1_case_v1
mkdir -p logs
bash run_checks.sh
bash run_prepare.sh
python -B tools/run_case.py gate
```

`run_prepare.sh`只读已有模型、先验、数据并保存冻结清单，生成请求为0。默认先复用原D₀批处理包的prepared/latest.json；找不到时停止，不自动重做profile。也不需要回头重核历史A，当前历史案例验收状态已作为记录保留，本轮独立测量。

## 到达率实验：建议先完成这一批
```bash
set -o pipefail
bash run_rates.sh 2>&1 | tee "logs/rates_$(date -u +%Y%m%dT%H%M%SZ).log"
```
预期：`B1_CASE_PREPARED`，`B1_CASE_WARMUP`，64条`B1_CASE_CONDITION_ACCEPTED`，`B1_CASE_RESULT`，`CLEANUP`，`B1_CASE_ARCHIVE`。

所有主方法在四次重复中各占一次运行位置。每个新运行段、首次使用某个R之前做3R个固定预热请求（普通2R，guided JSON R），不按结果追加。

## 副本曲线
```bash
set -o pipefail
bash run_replicas.sh 2>&1 | tee "logs/replicas_$(date -u +%Y%m%dT%H%M%SZ).log"
```
增加48格，完成后`core_complete=true`。单GPU也保留全部方法：DAG路由没有跨卡空间，但准入、顺序和batching机制及其成本都真实保留。模型按物理0..R−1使用原曲线，不重训或假设除以R。

## 可选消融
```bash
set -o pipefail
bash run_ablations.sh 2>&1 | tee "logs/ablations_$(date -u +%Y%m%dT%H%M%SZ).log"
```
需先有rate4/8的DAG-Fixed与DAG-Batch四次主测量，用来配对。此要求只是复用基线，不是要求它们先有正收益。新24格结束后`optional_ablations_complete=true`。

## 断点续跑
重复对应入口即可恢复同一个case run：
```bash
bash run_rates.sh
# 或显式：
bash run_replicas.sh --resume runs/MUSIQUE_B1_CASE_实际目录
```
已接受条件校验文件后跳过，不再生成。完整执行的原始记录可补后处理。实际请求中断时明确使用：
```bash
bash run_rates.sh --resume runs/MUSIQUE_B1_CASE_实际目录 --retry-incomplete
```
它只允许尚未完成的attempt重试，旧attempt留档。完整但校验失败、完整但性能较差，不能重试。数据/代码/模型hash不符时不能改hash放行。

## 输出与作图
每个条件保存`raw/`中的nodes、plans、backend、controls、原生summary等；`derived/`中有结构化答案、完整指标、workflow路由/JCT/生成量和batching作用证据。控制台压缩为主要指标，原始答文保留在`derived/answers.log`，不是删除。

运行目录始终更新：
- `conditions.csv`：全部已接受条件；
- `aggregates.csv`：各点/方法Mean和执行间SD；
- `paired_gains.csv`：调度、batching增量、组合、RR与消融配对；
- `paired_aggregates.csv`：逐次配对收益均值/SD；
- `components.csv`：完整关键路径时延分解；
- `result.json`、`REPORT.md`：范围、完成进度、全部正负结果；
- `frozen/selected.public.json`：独立提取的16题输入；
- `last_archive.json`：最新阶段归档地址及SHA。

完成后可离线作图（需环境已有matplotlib，缺失不影响实验结果，也不会自动安装）：
```bash
bash run_figures.sh
```
PNG与SVG图位于run/figures，包括JCT/TTFT/TPOT代理/吞吐的到达率和副本曲线，并提供图注文本。作图不调用服务器，不将缺失数据补成好结果，不减掉计算时间。P95图是每次P95的平均，不是汇总逐token的ITL。误差条是四次执行SD，不是总体置信区间。

作图后重新归档可执行：
```bash
python -B tools/run_case.py archive
```
阶段归档的完成标记分开，未跑消融不影响主矩阵112格可完整报告。任一正结果都不会让程序提前结束；负结果不触发调参或换题。没有收益保证，也不要求所有辅助指标同时改善。

## 测试范围
详见TEST_RESULTS.txt与TEST_SCOPE.json。CPU/mock执行不等于目标vLLM/GPU验证。保留原生尾块检查器及全部时序/资源约束；本包不增加新的收益/质量/TPOT晋级门槛。
