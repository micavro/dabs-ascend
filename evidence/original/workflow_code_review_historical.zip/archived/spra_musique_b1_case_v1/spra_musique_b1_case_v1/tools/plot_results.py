#!/usr/bin/env python3
"""Render saved results only. No model/server calls or filtering by improvement."""
from __future__ import annotations
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

CORE=('RR','Affinity','DAG-Fixed','DAG-Batch')
METRICS={'mean_jct_ms':'Mean workflow JCT (ms)', 'p95_jct_ms':'P95 workflow JCT (ms)',
 'mean_request_ttft_ms':'Mean request TTFT (ms)', 'p95_request_ttft_ms':'P95 request TTFT (ms)',
 'mean_node_time_to_first_content_ms':'Mean eligible-to-first-content (ms)',
 'mean_client_tpot_proxy_ms':'Mean client TPOT proxy (ms/token)',
 'p95_client_tpot_proxy_ms':'P95 client TPOT proxy (ms/token)',
 'cohort_workflows_s':'Cohort completion throughput (workflows/s)',
 'cohort_tokens_s':'Cohort output throughput (tokens/s)'}

def render(run):
    run=Path(run);res=json.loads((run/'result.json').read_text());out=run/'figures';out.mkdir(exist_ok=True)
    rows=res['aggregates'];written=[]
    for axis in ('rates','replicas'):
        xkey='rate' if axis=='rates' else 'replicas'
        choose=lambda r:r['replicas']==4 if axis=='rates' else r['rate']==4.
        for metric,ylabel in METRICS.items():
            fig,ax=plt.subplots(figsize=(6.4,4.1));drawn=False
            for i,m in enumerate(CORE):
                rs=sorted((r for r in rows if r['method']==m and choose(r) and r[metric+'_mean'] is not None),key=lambda r:r[xkey])
                if not rs:continue
                x=[r[xkey] for r in rs];y=[r[metric+'_mean'] for r in rs]
                ax.errorbar(x,y,yerr=[r[metric+'_sd'] or 0. for r in rs],marker=('o','s','^','D')[i],capsize=3,label=m)
                drawn=True
            if not drawn:plt.close(fig);continue
            ax.set_xlabel('Configured cycle-mean arrival rate (workflow/s)' if axis=='rates' else 'Active replicas')
            ax.set_ylabel(ylabel);ax.set_xticks([2,4,8,10] if axis=='rates' else [1,2,3,4]);ax.legend(fontsize=9)
            for s in ax.spines.values():s.set_visible(True)
            fig.tight_layout()
            for ext in ('svg','png'):
                path=out/f'{axis}_{metric}.{ext}';fig.savefig(path,dpi=220);written.append(str(path.name))
            plt.close(fig)
    (out/'CAPTIONS.txt').write_text(
      'All panels: MuSiQue-B1-16, a subset selected after observing a favorable historical Block1. '
      'These are conditional case-study measurements, not a whole-dataset estimate. '
      'Markers: means of completed repeated executions; error bars: sample standard deviations, not confidence intervals. '
      'Missing conditions are not imputed. P95 panels average per-condition P95, not pooled token ITL. '
      'Rate panels keep four active replicas; replica panels keep configured4/s. N16 and exact question order remain fixed. '
      'Wave is 2*rate for1s then idle1s; 8/s and10/s N16 cohorts end within their first active wave. '
      'Throughput is finite-cohort completion/output rate, not sustained maximum capacity. '
      'DAG-Batch is fixed C=D0+Mixed1024, never the per-point best of different algorithms.\n',encoding='utf-8')
    print('B1_CASE_FIGURES='+json.dumps({'directory':str(out),'files':written,'source_records_changed':False}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);render(p.parse_args().run)
