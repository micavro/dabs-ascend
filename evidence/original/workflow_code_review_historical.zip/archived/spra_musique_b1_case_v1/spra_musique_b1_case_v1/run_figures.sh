#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ "$#" -gt 0 ]; then
  python -B tools/plot_results.py "$@"
else
  RUN=$(python -B -c 'import json;print(json.load(open("records/latest.json"))["directory"])')
  python -B tools/plot_results.py --run "$RUN"
fi
