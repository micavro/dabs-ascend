#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python -B -u tools/run_case.py run --phase ablations "$@"
