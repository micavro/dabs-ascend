本目录默认不含真实MuSiQue样本。CPU端先执行 tools/fetch_musique.py，再执行 tools/pack_dataset.py。
只有官方下载或显式导入的数据会进入compiled；tests中的样例均为标注为假的单元测试夹具。
