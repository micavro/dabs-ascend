# MuSiQue：冻结 D₀ 的 adaptive batching 增量实验

版本：`musique-d0-batching-1`。历史检查点：`MUSIQUE_SCHEDULING_D0_20261010`。

**本包只增加客户端 batching 额度试验。不要执行 stage、run_apply、重启、重新下载数据、重新训练模型或重新做语义 smoke。**

## 1. 研究约定

主指标是完整 workflow Mean JCT，包含动态输入、中央排队、D₀计算、batching计算、通信、主动等待和实际执行。TTFT、节点完整首内容时延、客户端 TPOT 代理、P95、吞吐和质量并列记录，不作为当前候选选择的否决条件。质量相对提升使用 `(new / reference - 1)*100`，基准为零时为 null。

历史结果：MuSiQue D 对 A 的四块平均配对 JCT 改善为13.3038%，旧 Joint 为10.9876%。精确数值以 `analysis/D0_checkpoint.json` 为准。它们是历史开发证据，不作为本次同期分母。

当前要测试：

`D₀ + Adaptive` 对 `同一 D₀ + 开发期最佳已测 Fixed` 的额外 JCT 收益。

D₀的源码、调度候选、评分函数、旧模型、长度先验和现有观察/执行器保持不变。通过48个依赖文件的固定哈希验证，而不是拷贝重写一个近似D₀。每次调用原始 `semantic19.selector.choose(...,'D',...)`，保存它给出的完整动作；后处理只能改 caps。逐次比较 placement、admit、order 的哈希。原生提交复查导致的fallback独立计数，不隐瞒。

**冻结策略不等于冻结历史轨迹，也不能保证在新的到达率/生成内容下仍有13.3%收益。**batching改变执行状态后，相同D₀会正常作出不同后续选择。不同fixed敏感性条件的实际cap不同，但D₀评分中的参照cap仍为4096；不因扫描fixed而调优调度模型或修改D₀规则。

本实验不是重新搜索放置×额度。它是冻结D₀后的batching条件增量实验，不能单独证明新的同步Joint优化器优于旧Decoupled。

## 2. 三个有限的 batching 假设

所有自适应策略在未满足条件时采用4096，不按统计分位数生成无限规则表，不增加在线batching rollout。

| 代码名称 | 当前D₀放置以后何时减小cap | 减小到 |
|---|---|---:|
| `mixed_2048` | 同副本已有decode，且已准入/正在执行的prefill中，估计未缓存query总量超过2048 | 2048 |
| `mixed_1024` | 同上，阈值1024 | 1024 |
| `completion_1024` | 同副本有超过1024的未缓存prefill，并有预计在剩余动作窗口内完成、能结束workflow或释放后继的已有decode | 1024 |

前缀未知、状态过旧、没有实际prefill、没有已有decode、剩余窗口不足，都保持4096。完成预测使用旧冻结模型的decode步时、旧开发集的输出p75和已观测token进度，不读取真实未来EOS。p75被超越时只给至少1步的估计并明确记录；这是需要实测检验的有限启发式，不是可信的未来完成时间标签。

两种Mixed是解释性基准；Completion利用workflow完成/依赖释放信息。它们都保持同一个D₀。取舍通过完整实机JCT决定，不要求每个decode请求不变，也不要求每一项TTFT/TPOT都变好。旧D₀内部已有的模型guard不改动；新增batching不再增加硬TPOT质量否决。

硬总额度4096、合法cap256/512/1024/2048/4096、200ms绝对节拍和动作到期协议不变。自适应动作到期回到4096；已经执行的放置、KV和DAG进度保留。固定cap敏感性条件则把当前与续行cap都设为同一档，使其确实是固定cap，而不是一个脉冲。

## 3. 依赖和位置

GPU39上应已经存在：

```
/home/wmy/sci/spra_paper_experiments_github/
  spra_stage19_musique_joint_v1/       # 原执行器、D₀、数据
  spra_stage19_typed_handoff_v1/       # 已完成profile的typed应用
  spra_musique_d0_batching_v1/         # 本包，新目录
```

默认直接读取 `spra_stage19_typed_handoff_v1/prepared/latest.json` 指向的旧冻结profile。检查它确实属于该typed版本、数据hash一致、best_fixed_cap=4096。复制model.json和priors.json的**原始字节**，不拟合新模型，不重跑旧profile。

目标后端：`/home/wmy/sci/spra_core_exp/joint_e1` 的现有 `joint18v2`。四个HTTP端口8000–8003。要求现有hook哈希为 `78ca1d716c5701a9f83ba7dc0b22669b6b50a38bd54626a56642130cd1684418`。

CPU下载目录：`/home/wmy/paper/sci/`。SSH：`wqx@10.18.2.128:8822`，密钥`/home/wmy/ustc87`。

需要的Python包仅为已使用的httpx等原依赖。新增实验本身没有安装、下载、Kubernetes写入或模型切换入口。

## 4. 开发与冻结验证

固定条件：N16、真实原始MuSiQue分解、自然JSON答案、max96、真实父输出、4K上下文、2700文档预算。不得强制长输出、注入标准父答案、按正确性筛题。

### 开发：54条件

现有32个train问题，分为两个16题block；两块与全部方法共享相同外部问题/到达偏移。每个block分别在2、4、8 workflow/s下运行9种条件：

- A-F4096（同期参照，非声称各新rate的最优A）。
- D₀ + 5档固定cap。
- D₀ + 3种自适应cap规则。

`3 rates × 2 blocks × 9 = 54`。顺序预先确定，rate顺序和方法位置轮换。2/s保留原回归点；4/s、8/s仅改变到达强度。N仍为16，因此不是稳态容量测定。

全部54条件结束以后，为每个rate选择最优已测D₀固定cap；为全部三个rate共同选择**一张**自适应规则（按等rate/等block的配对JCT改善），不只挑最好看的rate。另冻结Mixed两种规则中较好的一种用于比较。即使最好的规则仍是负收益，也不删除、不重试、不改阈值。

### 冻结验证：最多60条件，自动合并完全相同的方法别名

复用现有64个dev问题，4块×16题，每块在全部3个rate下运行5个报告角色：

1. A-F4096。
2. D0-F4096，冻结调度回归锚点。
3. D0-BestFixed，该rate在train选出的固定cap。
4. D0-Mix，train选出的Mixed规则。
5. D0-Adaptive，train选出的全局最佳自适应规则。

若BestFixed就是4096，只执行一个相同条件，同时挂两个角色；若Adaptive就是Mix，两者也指向同一真实条件，不伪装成独立样本。依选择结果为36–60个独立条件，冻结前全部展开打印。

**这64题此前已在旧pilot使用过。验证是新策略冻结后的新执行，不是全新未见问题的独立holdout，也不作统计显著性承诺。**不下载更多数据，不把这一限制隐瞒为“新数据确认”。本包没有用其新运行结果反过来选策略。

每个完整suite之前固定8个普通服务预热请求和4个相同JSON schema预热请求，独立留档，不按速度增加预热次数。原来有过warmup，也不等于永远排除本suite服务路径状态差异。

## 5. 推荐命令

CPU上将代码zip上传到128。GPU39解压后：

```bash
conda activate spra-exp
cd /home/wmy/sci/spra_paper_experiments_github/spra_musique_d0_batching_v1
mkdir -p logs
bash run_checks.sh
bash run_prepare.sh
python -B tools/run_batching.py gate
bash run_develop.sh 2>&1 | tee logs/develop.log
```

开发成功会输出 `BATCH_DEVELOPMENT_FROZEN` 和排空确认。接着：

```bash
bash run_confirm.sh 2>&1 | tee logs/confirm.log
```

外层推荐`set -euo pipefail`，避免tee掩盖错误。正确性失败会停止，不会自动换seed或重试。可通过gate而D₀回退多/自适应负收益不是中止条件；这些是要保存的结果。

非标准路径：

```bash
STAGE19_SOURCE=/实际/原Stage19目录 \
STAGE19_TYPED_SOURCE=/实际/typed目录 \
bash run_prepare.sh --prepared /实际/typed冻结profile目录 --dataset /实际/compiled目录
```

其他命令须使用同样环境。profile找不到时指定现有路径，不要重跑旧标定。哈希不符时停止，不要编辑expected hashes。

重复执行已完整结束的develop/confirm只打印 `SUITE_ALREADY_COMPLETE`，不再次发送GPU请求。准备产物已存在且不一致时明确报错；不覆盖旧产物。

## 6. 输出与判断

正式统计以 `D0_BATCH_CONDITION_DONE` 为准。继承client的CONDITION_DONE和质量的TYPED_RESPONSE是底层明细，不能再次计成独立条件。

主要对照：

- D0-F4096 vs A-F4096：调度优势是否保留。
- D0-Adaptive vs D0-F4096：相对旧调度底座的增量。
- D0-Adaptive vs D0-BestFixed：自适应是否超过开发集调优的固定cap。
- D0-Adaptive vs D0-Mix：结构感知额度规则与压力规则的区别；若角色相同，差值应精确为零。
- D0-Adaptive vs A-F4096：完整方法性能。

每个条件保存完整nodes、plans、controls、backend、真实父绑定、质量、TTFT/TPOT代理和JCT分解。`batching_evidence.json`新增：D₀前后调度hash、worker选择与native commit fallback、逐cap mixed/prefill/decode-only活动、严格逻辑binding、真实host时长、回到共同续行的变化。

固定cap变更次数不等于有效batching：要同时看有prefill、是否真约束工作以及完整JCT是否改善。host时长不叫CUDA时间，TPOT是已有客户端代理，N/A不填0。

结果的主百分比为同block配对，再对block/率等权平均。质量相对提升/百分点分别记录，零基准不计算相对百分比。

## 7. 封存

confirm成功完成后，自动打印：

```
MUSIQUE_D0_BATCHING_RESULT=...
CLEANUP={"backend_drained":true,...}
MUSIQUE_BATCHING_ARCHIVE={"path":"...zip","sha256":"...",...}
```

归档含**全部本轮开发与验证的原始记录**、冻结模型、配置、选择收据、CSV、Markdown报告和校验清单；所有正负rate均保留。它不是整个服务器备份，也不把“归档完成”叫作“获得收益”。旧D₀检查点和旧run从不覆盖。

若自适应没有增量，报告写明`retain_D0_checkpoint; batching_increment_not_established`，而不是牺牲已有效的调度结果。若出现增量，仍需按作用范围表述，不把启发式胜出扩大为普适保证。
