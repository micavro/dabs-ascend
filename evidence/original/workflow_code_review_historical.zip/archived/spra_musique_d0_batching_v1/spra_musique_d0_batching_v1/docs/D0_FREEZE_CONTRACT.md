# D₀冻结与因果比较边界

冻结的是mapping function、参考评分配置和原模型，不是路由轨迹。原方法调用 `semantic19.selector.choose(snapshot, model, cfg, 'D', deadline)`。批次辅助字段在调用前移除，base_cap恢复4096，其余时间窗口与真实状态维持原执行器行为。

固定cap敏感性：D₀先在冻结4096参照下选调度；仅改实际cap。续行cap与所测fixed一致。该方法不能称为“每档cap重新优化的调度”；它回答的是冻结D₀下额外控制的条件效果。

每个正常返回的方案保存原D₀动作和caps变更后的调度hash。不允许改变placement/admit/order。原client的缓存损失、资源、过期复查可能回退到原生reference；这些不被覆盖为D₀选择，分别计数。额外计算与状态反馈仍然可能影响性能，故不保证保持过去13.30%的点估计。

D₀原有的模型guard属于冻结调度的一部分，未在本包删除。新的batching规则不以质量、TPOT百分比或“所有指标都改善”为选择门槛，模型在Completion规则中仅估计本轮内可能结束的decode，不重新拟合也不重排D₀调度。

D0-Mix和D0-Adaptive只诊断额度的选择规则；本包不声称同时重优化放置，所以也不把它们直接等同过去的Decoupled与Joint搜索器。

所有方法共同使用原4K/模型/JSON自然输出/缓存观察/执行器/HTTP和计量。A没有人为增加D₀或batching搜索。确认中相同执行规则合并为别名而不是重复独立采样。正式增量优先看D0-Adaptive对开发期D0-BestFixed；旧A不作新测量的分母。
