import json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from batching20.dependency import ROOT,SOURCE,TYPED,own_identity
from batching20 import experiment as E

class CLITests(unittest.TestCase):
    def test_plan_never_reads_runtime(self):
        p=subprocess.run([sys.executable,'-B',str(ROOT/'tools/run_batching.py'),'plan','--runtime','/never/runtime'],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr);self.assertEqual(json.loads(p.stdout)['development_conditions'],54)
    def test_preflight_no_generation(self):
        p=subprocess.run([sys.executable,'-B',str(ROOT/'tools/run_batching.py'),'preflight','--runtime','/never/runtime'],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr);self.assertIn('"GPU_REQUESTS": 0',p.stdout)
    def test_missing_freeze_diagnostic(self):
        with tempfile.TemporaryDirectory() as td,patch.object(E,'ROOT',Path(td)):
            with self.assertRaisesRegex(FileNotFoundError,'run_prepare'):E.load_frozen()
    def test_runtime_paths_correct(self):
        text=(ROOT/'tools/run_batching.py').read_text();self.assertIn("if __name__=='__main__'",text)
    def test_new_policy_module_not_backend(self):
        from batching20.binding import client
        self.assertEqual(Path(client.__file__).resolve(),SOURCE/'joint18v2/client.py')
    def test_identity_detects_input_change(self):
        from batching20 import dependency as D
        with tempfile.TemporaryDirectory() as td,patch.object(D,'SOURCE',Path(td)):
            with self.assertRaisesRegex(RuntimeError,'dependency differs'):D.verify()
    def test_hash_inputs_exclude_results(self):
        self.assertFalse(any(k.startswith(('runs/','prepared/','records/')) for k in own_identity()))
    def test_archive_without_confirmation_fails(self):
        with tempfile.TemporaryDirectory() as td,patch.object(E,'ROOT',Path(td)):
            with self.assertRaises(FileNotFoundError):E.seal()
