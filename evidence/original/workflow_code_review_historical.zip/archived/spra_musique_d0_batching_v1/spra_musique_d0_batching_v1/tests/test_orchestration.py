"""Full suite orchestration with synthetic disk artifacts and mocked GPU execution.

These tests check the real orchestration, frozen artifacts, no retries, role aliases
and sealing. They do not supply performance evidence or real MuSiQue examples.
"""
from __future__ import annotations
import asyncio,contextlib,copy,io,json,sys,tempfile,unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from batching20.dependency import ROOT,SOURCE,TYPED,sha,own_identity
from batching20 import experiment as E
from joint18v2.common import atomic,load
from semantic19.dataset import compile_record
sys.path.insert(0,str(TYPED/'tests'))
from test_typed_contract import fixture,FakeTokenizer

class OrchestrationTests(unittest.IsolatedAsyncioTestCase):
    def setup_artifacts(self,root):
        for rel in own_identity():
            target=root/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/rel).read_bytes())
        (root/'configs').mkdir(exist_ok=True);(root/'configs/protocol.json').write_bytes((ROOT/'configs/protocol.json').read_bytes())
        dataset=root/'dataset';dataset.mkdir();rows={}
        for name,N in [('profile',32),('pilot',64)]:
            rows[name]=[]
            for i in range(N):
                x=fixture();x['id']=f'SYNTHETIC_{name}_{i}'
                p,g=compile_record(x);rows[name].append(p)
            (dataset/(name+'.public.jsonl')).write_text(''.join(json.dumps(x)+'\n' for x in rows[name]))
        (dataset/'evaluation_gold.jsonl').write_text('')
        mf={'files':{p.name:sha(p) for p in dataset.iterdir() if p.is_file()},'counts':{'profile':32,'pilot':64}}
        atomic(dataset/'manifest.json',mf)
        old=root/'oldprofile';old.mkdir()
        model={'models':{str(r):{'coef':[10.,0.,0.,0.,0.,0.]} for r in range(4)}}
        priors={'3':{'p75':8}}
        atomic(old/'model.json',model);atomic(old/'priors.json',priors);atomic(old/'manifest.json',{'fixture':True})
        oldmf={'best_fixed_cap':4096,'dataset_manifest_sha256':sha(dataset/'manifest.json'),
               'files':{n:sha(old/n) for n in ('model.json','priors.json')}}
        runtime=root/'runtime';(runtime/'joint18v2').mkdir(parents=True)
        return dataset,old,model,priors,oldmf,runtime

    async def flow(self,fail=False):
        t=E.typed_runner()
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);dataset,old,model,priors,oldmf,runtime=self.setup_artifacts(root)
            calls=[]
            async def gate(client,runtime,R):return [{'hook_source_sha256':E.HOOK}]*4
            async def warm(*a):return None
            async def drained(*a):return True
            async def execute(client,runtime,initial,cfg,nodes,folder,method,model,executor=None,materializer=None):
                calls.append(cfg['batching20_policy'])
                if fail and len(calls)==3:raise RuntimeError('synthetic execution failure')
                folder.mkdir(parents=True)
                for k,n in nodes.items():
                    await materializer(k,nodes)
                    n.update(state='done',stream={'text':'{"answer":"Paris"}','usage':{'completion_tokens':8}},replica=0)
                val={'fixed_256':135,'fixed_512':115,'fixed_1024':110,'fixed_2048':105,'fixed_4096':100,
                     'mixed_2048':99,'mixed_1024':98,'completion_1024':97}[cfg['batching20_policy']]
                if method=='A':val=120
                summary={'condition_valid':True,'workflows':16,'mean_jct_ms':val,'p95_jct_ms':val+20,
                  'native_next_batch_matches':1,'native_next_batch_checked':1,'output_tokens':len(nodes)*8,
                  'cohort_duration_s':1.,'cohort_tokens_s':len(nodes)*8,'cohort_workflows_s':16}
                atomic(folder/'nodes.json',nodes);atomic(folder/'manifest.json',{'fixture':True})
                (folder/'backend.jsonl').write_text('');return summary,[]
            def quality(nodes,dataset,duration):return {'semantic_quality':{'final_em':0.,'final_f1':0.},'quality_rows':[]}
            def inspect(*a):return {'D0_schedule_integrity':{'pass':True},'native_cap_binding_candidates':1}
            with patch.object(E,'ROOT',root),patch.object(t,'prepared',return_value=(old,model,priors,oldmf)),contextlib.redirect_stdout(io.StringIO()):
                prepared=E.freeze_inputs(dataset)
                self.assertEqual((prepared/'model.json').read_bytes(),(old/'model.json').read_bytes())
                with patch.object(E,'gate',gate),patch.object(E,'warmup',warm),patch.object(E,'wait_drained',drained),\
                     patch.object(E,'ServerTokenizer',lambda *a:FakeTokenizer()),patch.object(E,'execute',execute),\
                     patch.object(E,'quality_evaluate',quality),patch.object(E,'inspect_condition',inspect),\
                     patch.object(E,'ProcessPoolExecutor',lambda *a,**k:ThreadPoolExecutor(1)):
                    if fail:
                        with self.assertRaisesRegex(RuntimeError,'synthetic execution'):await E.live('develop',runtime)
                        self.assertEqual(len(calls),3)
                        self.assertFalse((root/'records/develop_latest.json').exists())
                        run=next((root/'runs').iterdir())
                        self.assertEqual(load(run/'suite_status.json')['completed_conditions'],2)
                        self.assertTrue(load(run/'cleanup.json')['backend_drained'])
                    else:
                        await E.live('develop',runtime)
                        self.assertEqual(len(calls),54)
                        before=len(calls);await E.live('develop',runtime)
                        self.assertEqual(len(calls),before)
                        await E.live('confirm',runtime)
                        self.assertEqual(len(calls),102) # 48 unique confirmation conditions
                        archive=list((root/'archives').glob('*.zip'))
                        self.assertEqual(len(archive),1)
                        import zipfile
                        with zipfile.ZipFile(archive[0]) as z:
                            self.assertIsNone(z.testzip())
                            self.assertIn('confirmation/batching_result.json',z.namelist())
                            self.assertIn('ARCHIVE_SHA256SUMS',z.namelist())
                        cf=Path(load(root/'records/confirm_latest.json')['directory'])
                        report=load(cf/'batching_result.json')
                        self.assertGreater(report['mean_batch_increment_pct_all_rates'],0.)
                        self.assertFalse(report['formal_significance_established'])
    async def test_prepare_develop_confirm_and_seal(self):await self.flow()
    async def test_failure_keeps_two_conditions_no_retry(self):await self.flow(fail=True)
    async def test_mismatched_D0_fixed_cap_refused(self):
        t=E.typed_runner()
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);dataset,old,m,p,mf,rt=self.setup_artifacts(root);mf['best_fixed_cap']=1024
            with patch.object(E,'ROOT',root),patch.object(t,'prepared',return_value=(old,m,p,mf)):
                with self.assertRaisesRegex(ValueError,'checkpoint cap4096'):E.freeze_inputs(dataset)
    async def test_no_quality_recovery_loop(self):
        # The complete flow uses zero quality throughout and still seals.
        self.assertEqual(E.protocol()['quality_selection_weight'],0)
