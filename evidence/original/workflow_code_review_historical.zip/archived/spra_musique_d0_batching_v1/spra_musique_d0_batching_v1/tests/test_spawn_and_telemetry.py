import copy,json,multiprocessing,tempfile,time,unittest
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from unittest.mock import patch
from batching20.policy import process_plan,scheduling_hash
from batching20.telemetry import inspect_condition
from test_policy import fixture,MODEL

class SpawnTests(unittest.TestCase):
    def test_real_spawn_worker_imports_overlay(self):
        s,a,c=fixture();c['batching20_policy']='fixed_1024'
        with ProcessPoolExecutor(1,mp_context=multiprocessing.get_context('spawn')) as ex:
            z=ex.submit(process_plan,s,MODEL,c,'D',time.monotonic()+5).result(timeout=10)
        self.assertEqual(z['action']['caps'],[1024,1024]);self.assertTrue(z['batching20']['D0_schedule_unchanged'])

class EvidenceTests(unittest.TestCase):
    def create(self,p,cap=4096,modified=False,fallback=None):
        s,a,c=fixture();b=copy.deepcopy(a);b['caps']=[cap]*2
        if modified:b['placement']['p']=1
        plan={'decision_index':1,'action':b,'commit_fallback':fallback,'batching20':{'D0_action':a,
            'D0_schedule_hash':scheduling_hash(a),'emitted_schedule_hash':scheduling_hash(a),
            'additional_wall_ms':.1,'evidence':{'reason':'evaluated','replicas':[]}}}
        (p/'plans.jsonl').write_text(json.dumps(plan)+'\n')
        event={'event':'iteration','replica':0,'pid':1,'case':'x','iteration':1,
            'scheduled':[{}],'prefill_cap':cap,'prefill_logical_tokens':cap,'decode_tokens':1,
            'total':4096,'remaining_prefill_in_before':6000,'execution_phase':'current_action'}
        (p/'backend.jsonl').write_text(json.dumps(event)+'\n')
    def test_decode_only_not_binding(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);self.create(p,1024)
            e=json.loads((p/'backend.jsonl').read_text());e['prefill_logical_tokens']=0
            (p/'backend.jsonl').write_text(json.dumps(e)+'\n')
            r=inspect_condition(p,'mixed_1024','D');self.assertEqual(r['per_cap']['1024']['strict_binding_candidates'],0)
    def test_strict_binding_recorded(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);self.create(p,1024);r=inspect_condition(p,'mixed_1024','D')
            self.assertEqual(r['per_cap']['1024']['strict_binding_candidates'],1)
    def test_nonfallback_route_mutation_fails(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);self.create(p,1024,True)
            with self.assertRaisesRegex(RuntimeError,'without native fallback'):inspect_condition(p,'mixed_1024','D')
    def test_real_commit_fallback_not_hidden(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);self.create(p,1024,True,'resource_state_changed');r=inspect_condition(p,'mixed_1024','D')
            self.assertEqual(r['D0_schedule_integrity']['commit_fallback_receipts'],1)
    def test_wrong_fixed_cap_fails(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);self.create(p,512)
            with self.assertRaisesRegex(RuntimeError,'fixed sensitivity'):inspect_condition(p,'fixed_1024','D')
