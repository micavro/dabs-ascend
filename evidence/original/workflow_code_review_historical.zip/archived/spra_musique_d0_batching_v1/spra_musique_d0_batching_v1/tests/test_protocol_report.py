import copy,json,tempfile,unittest
from pathlib import Path
from batching20.dependency import ROOT
from batching20.protocol import development_design,confirmation_design,validate_rows,select,key
from batching20.report import build_confirmation_report,gain,compare,write_tables
P=json.loads((ROOT/'configs/protocol.json').read_text())

def rows_fixture():
    times={'fixed_256':130,'fixed_512':115,'fixed_1024':108,'fixed_2048':105,'fixed_4096':100,
           'mixed_2048':98,'mixed_1024':99,'completion_1024':96}
    rows=[]
    for d in development_design(P):
        val=120 if d['scheduler']=='A' else times[d['policy']]
        s={'condition_valid':True,'D0_schedule_integrity':{'pass':True},'workflows':16,'mean_jct_ms':val,
           'p95_jct_ms':150,'mean_request_ttft_ms':40,'mean_client_tpot_proxy_ms':12,'cohort_tokens_s':10,
           'cohort_workflows_s':1.,'output_tokens':128,'semantic_quality':{'final_em':.1,'final_f1':.2}}
        rows.append({**d,'external_work_sha256':str((d['rate'],d['block'])),'summary':s,'folder':'/fake/'+d['label']})
    return rows

class ProtocolTests(unittest.TestCase):
    def test_full_development_count(self):self.assertEqual(len(development_design(P)),54)
    def test_all_five_caps_and_three_policies(self):
        ds=development_design(P)
        for r in P['rates']:
            for b in (1,2):self.assertEqual(len([d for d in ds if d['rate']==r and d['block']==b]),9)
    def test_each_block_same_external_seed(self):
        for b in (1,2):self.assertEqual(len({d['seed'] for d in development_design(P) if d['block']==b}),1)
    def test_not_always_A_first(self):self.assertGreater(len({d['name'] for d in development_design(P) if d['position']==1}),1)
    def test_all_rates_retained(self):self.assertEqual({d['rate'] for d in development_design(P)},{2.,4.,8.})
    def test_complete_required(self):
        with self.assertRaises(ValueError):select(rows_fixture()[:-1],P)
    def test_duplicates_rejected(self):
        rows=rows_fixture();rows[-1]=copy.deepcopy(rows[0])
        with self.assertRaises(ValueError):select(rows,P)
    def test_scheduling_mutation_rejected(self):
        rows=rows_fixture();rows[0]['summary']['D0_schedule_integrity']['pass']=False
        with self.assertRaises(ValueError):select(rows,P)
    def test_mismatched_external_work_rejected(self):
        rows=rows_fixture();rows[0]['external_work_sha256']='bad'
        with self.assertRaises(ValueError):select(rows,P)
    def test_best_global_rule(self):
        s=select(rows_fixture(),P);self.assertEqual(s['adaptive_policy'],'completion_1024');self.assertEqual(s['mixed_policy'],'mixed_2048')
    def test_quality_not_gate(self):
        rows=rows_fixture()
        for r in rows:
            if r['policy']=='completion_1024':r['summary']['semantic_quality']={'final_em':0.,'final_f1':0.}
        self.assertEqual(select(rows,P)['adaptive_policy'],'completion_1024')
    def test_TPOT_not_gate(self):
        rows=rows_fixture()
        for r in rows:
            if r['policy']=='completion_1024':r['summary']['mean_client_tpot_proxy_ms']=9999.
        self.assertEqual(select(rows,P)['adaptive_policy'],'completion_1024')
    def test_negative_not_retried_or_dropped(self):
        rows=rows_fixture()
        for r in rows:
            if not r['policy'].startswith('fixed_'):r['summary']['mean_jct_ms']+=100
        s=select(rows,P);self.assertFalse(s['positive_development_mean']);self.assertEqual(len(s['adaptive_scores']),3)
    def test_baseline_not_weakened(self):self.assertEqual(select(rows_fixture(),P)['best_fixed_per_rate'],{'2':4096,'4':4096,'8':4096})
    def test_alias_not_counted_twice(self):
        s=select(rows_fixture(),P);d=confirmation_design(P,s)
        self.assertEqual(len(d),48)
        for r in P['rates']:
            for b in range(1,5):
                g=[x for x in d if x['rate']==r and x['block']==b]
                self.assertEqual(sum(len(x['roles']) for x in g),5)
    def test_all_duplicate_roles_share_exact_condition(self):
        s=select(rows_fixture(),P);s['adaptive_policy']=s['mixed_policy']
        ds=confirmation_design(P,s);self.assertEqual(len(ds),36)
        self.assertTrue(any(x['roles']==['D0-Mix','D0-Adaptive'] for x in ds))
    def test_confirmation_no_unseen_claim(self):self.assertTrue(P['confirmation_questions_previously_used'])
    def test_relative_quality_zero_denominator_null(self):self.assertIsNone(gain(0,.2,True))
    def test_secondary_null_not_zero(self):
        a={'mean_jct_ms':100,'mean_client_tpot_proxy_ms':None};b={'mean_jct_ms':90,'mean_client_tpot_proxy_ms':None}
        self.assertIsNone(compare(a,b)['gain_pct']['mean_client_tpot_proxy_ms'])
    def test_percentage_vs_percentage_point(self):
        z=compare({'semantic_quality':{'final_em':.1,'final_f1':.2}},{'semantic_quality':{'final_em':.2,'final_f1':.3}})
        self.assertAlmostEqual(z['quality_relative_gain_pct']['final_em'],100.)
        self.assertAlmostEqual(z['quality_absolute_change_pp']['final_em'],10.)
    def test_confirmation_report_keeps_negative(self):
        s=select(rows_fixture(),P);rr=[]
        for d in confirmation_design(P,s):
            val=100 if d['scheduler']=='A' else 90
            if 'D0-Adaptive' in d['roles']:val=95
            rr.append({**d,'summary':{'mean_jct_ms':val,'semantic_quality':{'final_em':0.,'final_f1':0.}}})
        report=build_confirmation_report(rr,P,s)
        self.assertLess(report['mean_batch_increment_pct_all_rates'],0)
        self.assertGreater(report['mean_total_gain_pct_all_rates'],0)
        self.assertFalse(report['full_joint_placement_reoptimization_tested'])
    def test_write_condition_csv(self):
        with tempfile.TemporaryDirectory() as td:
            write_tables(td,rows_fixture());self.assertEqual(len((Path(td)/'conditions.csv').read_text().splitlines()),55)
