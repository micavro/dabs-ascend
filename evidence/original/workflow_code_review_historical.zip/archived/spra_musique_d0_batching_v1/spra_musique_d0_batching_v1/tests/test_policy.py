from __future__ import annotations
import copy,json,time,unittest
from pathlib import Path
from unittest.mock import patch
from batching20.dependency import activate,TYPED,sha,verify
activate()
from batching20 import policy as P
from semantic19.selector import choose as original_D
CFG=json.loads((TYPED/'configs/semantic.json').read_text())
MODEL={'models':{'0':{'coef':[10.,0.,0.,0.,0.,0.]},'1':{'coef':[10.,0.,0.,0.,0.,0.]}}}

def fixture():
    now=time.monotonic()
    n=lambda k,w,state,p=3000,o=8:{'id':k,'wid':w,'state':state,'prompt':p,'output':o,
        'output_done':0,'computed':0,'parents':[],'prefix_hash':None,'share':0,
        'ready_at':now-.01,'arrival':now-.02,'replica':None,'compiled_successors':[],
        'phase':'prefill','max_output_tokens':96,'output_is_estimate':True}
    ns={'d':n('d','wd','submitted',3000,8),'p':n('p','wp','ready',3000,8)}
    ns['d'].update(replica=0,computed=3000,phase='decode',output_done=5)
    s={'nodes':ns,'ready':['p'],'replicas':2,'now':now,'state_ages_s':[.002,.003],
       'cache_evidence':[],'cache_unknown_count':0,'capacity_blocks':[4096]*2,
       'reserved_blocks':[200,0],'prefix_history':{},'pressure':[1,0],
       'current_caps':[4096,4096],'inflight_batches':[],'queue_order':{'0':['d'],'1':[]},'decision_index':1}
    a={'placement':{'p':0},'admit':['p'],'order':['p'],'caps':[4096,4096],'family':'reference'}
    c=copy.deepcopy(CFG);c.update(base_cap=4096,action_horizon_ms=200.,apply_delay_ms=10.)
    return s,a,c

class PolicyTests(unittest.TestCase):
    def test_fixed_all_levels(self):
        s,a,c=fixture()
        for cap in (256,512,1024,2048,4096):self.assertEqual(P.choose_caps(s,a,MODEL,c,'fixed_'+str(cap))[0],[cap,cap])
    def test_bad_policy_rejected(self):
        with self.assertRaises(ValueError):P.policy_spec('mixed_8192')
    def test_mixed_only_on_competing_replica(self):
        s,a,c=fixture();self.assertEqual(P.choose_caps(s,a,MODEL,c,'mixed_1024')[0],[1024,4096])
    def test_post_placement_not_preplacement(self):
        s,a,c=fixture();a['placement']['p']=1
        self.assertEqual(P.choose_caps(s,a,MODEL,c,'mixed_1024')[0],[4096,4096])
    def test_no_decode_keeps_base(self):
        s,a,c=fixture();s['nodes'].pop('d');self.assertEqual(P.choose_caps(s,a,MODEL,c,'mixed_1024')[0],[4096]*2)
    def test_no_prefill_keeps_base(self):
        s,a,c=fixture();a['admit']=[];self.assertEqual(P.choose_caps(s,a,MODEL,c,'mixed_1024')[0],[4096]*2)
    def test_waiting_prefill_submitted_counted(self):
        s,a,c=fixture();s['nodes']['p'].update(state='submitted',replica=0);a['placement']={};a['admit']=[];s['ready']=[]
        self.assertEqual(P.choose_caps(s,a,MODEL,c,'mixed_1024')[0],[1024,4096])
    def test_small_prefill_no_forced_switch(self):
        s,a,c=fixture();s['nodes']['p']['prompt']=512
        self.assertEqual(P.choose_caps(s,a,MODEL,c,'mixed_1024')[0],[4096]*2)
    def test_known_cache_reduces_opportunity_not_cold_guess(self):
        s,a,c=fixture();s['nodes']['p']['prefix_hash']='h';s['cache_evidence']=[{'prefix_hash':'h','replica':0,'tokens':2800,'known':True,'observed_age_s':.002}]
        self.assertEqual(P.choose_caps(s,a,MODEL,c,'mixed_1024')[0],[4096]*2)
    def test_unknown_cache_not_treated_as_cold(self):
        s,a,c=fixture();s['nodes']['p']['prefix_hash']='h'
        self.assertEqual(P.choose_caps(s,a,MODEL,c,'mixed_1024')[0],[4096]*2)
    def test_stale_keeps_reference(self):
        s,a,c=fixture();s['state_ages_s']=[2.,0.];self.assertEqual(P.choose_caps(s,a,MODEL,c,'mixed_1024')[0],[4096]*2)
    def test_invalid_age_keeps_reference(self):
        s,a,c=fixture();s['state_ages_s']=[float('nan'),0.];self.assertEqual(P.choose_caps(s,a,MODEL,c,'mixed_1024')[0],[4096]*2)
    def test_completion_sink(self):
        s,a,c=fixture();self.assertEqual(P.choose_caps(s,a,MODEL,c,'completion_1024')[0],[1024,4096])
    def test_no_finish_within_window(self):
        s,a,c=fixture();s['nodes']['d']['output']=96
        self.assertEqual(P.choose_caps(s,a,MODEL,c,'completion_1024')[0],[4096]*2)
    def test_unresolved_other_parent_not_unlock(self):
        s,a,c=fixture();s['nodes']['d']['compiled_successors']=['p'];s['nodes']['p']['parents']=['d','z']
        s['nodes']['z']={**s['nodes']['d'],'id':'z','state':'blocked'}
        p=P.completion_opportunity('d',s['nodes'],10.,200.)
        self.assertFalse(p['eligible'])
    def test_unknown_future_EOS_not_read(self):
        s,a,c=fixture();s['nodes']['d']['true_future_output_tokens']=99999
        self.assertEqual(P.choose_caps(s,a,MODEL,c,'completion_1024')[0],[1024,4096])
    def test_all_inputs_immutable(self):
        s,a,c=fixture();before=copy.deepcopy((s,a,c,MODEL));P.choose_caps(s,a,MODEL,c,'completion_1024')
        self.assertEqual((s,a,c,MODEL),before)
    def test_wrapper_never_changes_schedule(self):
        s,a,c=fixture();c['batching20_policy']='mixed_1024'
        with patch.object(P,'frozen_d0_choose',return_value={'action':a,'wall_ms':1}):
            ans=P.process_plan(s,MODEL,c,'D',time.monotonic()+1)
        self.assertEqual(P.scheduling_view(a),P.scheduling_view(ans['action']))
        self.assertEqual(ans['action']['caps'],[1024,4096]);self.assertEqual(a['caps'],[4096]*2)
    def test_wrapper_frozen_D0_cfg_reference4096(self):
        s,a,c=fixture();c.update(base_cap=512,batching20_policy='fixed_512')
        with patch.object(P,'frozen_d0_choose',return_value={'action':a}) as f:
            ans=P.process_plan(s,MODEL,c,'D',time.monotonic()+1)
        self.assertEqual(f.call_args.args[2]['base_cap'],4096)
        self.assertNotIn('batching20_policy',f.call_args.args[2]);self.assertEqual(ans['action']['caps'],[512]*2)
    def test_wrapper_no_late_batch_proposal(self):
        s,a,c=fixture();c['batching20_policy']='mixed_1024'
        with patch.object(P,'frozen_d0_choose',return_value={'action':a}):
            ans=P.process_plan(s,MODEL,c,'D',time.monotonic()-1)
        self.assertEqual(ans['action']['caps'],[4096]*2)
    def test_original_D0_equivalent_for_fixed4096(self):
        s,a,c=fixture()
        # Identical input/model/config, generous *test* deadline, exact original function.
        expected=original_D(copy.deepcopy(s),MODEL,copy.deepcopy(c),'D',time.monotonic()+3)
        cc=copy.deepcopy(c);cc['batching20_policy']='fixed_4096'
        actual=P.process_plan(copy.deepcopy(s),MODEL,cc,'D',time.monotonic()+3)
        self.assertEqual(actual['action'],expected['action'])
    def test_binding_restores(self):
        from batching20.binding import bindings
        import joint18v2.client as c
        old=c.process_plan,c.stream
        with bindings():self.assertIs(c.process_plan,P.process_plan)
        self.assertEqual((c.process_plan,c.stream),old)
    def test_binding_restores_exception(self):
        from batching20.binding import bindings
        import joint18v2.client as c
        old=c.process_plan,c.stream
        try:
            with bindings():raise ValueError('test')
        except ValueError:pass
        self.assertEqual((c.process_plan,c.stream),old)
    def test_source_identity(self):self.assertEqual(len(verify()),48)

class FrozenLengthPriorTests(unittest.TestCase):
    def test_prior_is_separate_from_scheduler_rolling_estimate(self):
        s,a,c=fixture();s['nodes']['d'].update(output=96,output_done=6,hop_count=3)
        c['batching20_output_priors']={'3':{'p75':8}}
        caps,e=P.choose_caps(s,a,MODEL,c,'completion_1024')
        self.assertEqual(caps,[1024,4096]);self.assertEqual(s['nodes']['d']['output'],96)
        self.assertEqual(e['replicas'][0]['workflow_finish_probes'][0]['length_source'],'frozen_development_p75')
    def test_prior_not_passed_into_frozen_D0_selector(self):
        s,a,c=fixture();c.update(batching20_policy='completion_1024',batching20_output_priors={'3':{'p75':8}})
        with patch.object(P,'frozen_d0_choose',return_value={'action':a}) as f:
            P.process_plan(s,MODEL,c,'D',time.monotonic()+1)
        self.assertNotIn('batching20_output_priors',f.call_args.args[2])
