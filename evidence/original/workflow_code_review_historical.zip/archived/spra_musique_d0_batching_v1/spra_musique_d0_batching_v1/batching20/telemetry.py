"""Post-condition evidence, never a new CPU/GPU performance experiment."""
from __future__ import annotations
import json, statistics
from collections import Counter,defaultdict
from pathlib import Path
from .policy import scheduling_view, scheduling_hash, policy_spec, REFERENCE_CAP
from .dependency import activate
activate()
from joint18v2.batchcheck import binding_evidence
from joint18v2.common import quantile,atomic

def jsonl(path):
    p=Path(path)
    if not p.is_file():return []
    out=[]
    for i,line in enumerate(p.read_text().splitlines(),1):
        if line.strip():
            try:out.append(json.loads(line))
            except ValueError as ex:raise ValueError(f'{p}:{i} malformed JSON') from ex
    return out

def inspect_condition(folder, policy, scheduler):
    folder=Path(folder);plans=jsonl(folder/'plans.jsonl');events=jsonl(folder/'backend.jsonl')
    checks=[];reason_counts=Counter();opportunity=0;selected=0;wall=[];lost_after_commit=0
    for p in plans:
        b=p.get('batching20')
        if not b:continue
        a=b['D0_action'];unchanged=b['D0_schedule_hash']==b['emitted_schedule_hash']==scheduling_hash(a)
        if not unchanged:raise RuntimeError('worker mutated D0 scheduling fields')
        commit_same=scheduling_view(a)==scheduling_view(p['action'])
        fallback=bool(p.get('commit_fallback'))
        if not commit_same and not fallback:raise RuntimeError('batching changed validated scheduling without native fallback')
        checks.append({'decision_index':p['decision_index'],'D0_schedule_unchanged':unchanged,
               'commit_matches_D0':commit_same,'native_commit_fallback':p.get('commit_fallback'),
               'D0_schedule_hash':b['D0_schedule_hash'],'emitted_caps':p['action']['caps']})
        if fallback:lost_after_commit+=1
        selected+=int(any(c!=REFERENCE_CAP for c in p['action']['caps']) and not fallback)
        wall.append(b['additional_wall_ms'])
        ev=b.get('evidence',{})
        reason_counts[ev.get('reason','missing')]+=1
        for r in ev.get('replicas',[]):
            reason_counts['replica:'+r.get('reason','missing')]+=1
            opportunity+=int(r.get('reason') in ('mixed_cold_prefill_test','preserve_near_completion_or_dependency_release'))
    its=[e for e in events if e.get('event')=='iteration' and e.get('scheduled')]
    engines={(e.get('replica'),e.get('pid'),e.get('case'),e.get('iteration')):e for e in events if e.get('event')=='engine_step'}
    phases=Counter();bycap=defaultdict(lambda:{'iterations':0,'with_prefill':0,'mixed':0,'decode_only':0,
        'logical_prefill_tokens':0,'decode_tokens':0,'strict_binding_candidates':0,'host_ms':0.,'host_samples':0})
    applied=Counter();expiration=0;prev={}
    for e in its:
        ph='mixed' if e['prefill_logical_tokens'] and e['decode_tokens'] else 'prefill_only' if e['prefill_logical_tokens'] else 'decode_only'
        phases[ph]+=1;cap=e.get('prefill_cap');row=bycap[str(cap)];row['iterations']+=1
        row['with_prefill']+=int(e['prefill_logical_tokens']>0);row['mixed']+=int(ph=='mixed');row['decode_only']+=int(ph=='decode_only')
        row['logical_prefill_tokens']+=e['prefill_logical_tokens'];row['decode_tokens']+=e['decode_tokens']
        row['strict_binding_candidates']+=int(binding_evidence(e)['binding_candidate'])
        st=engines.get((e.get('replica'),e.get('pid'),e.get('case'),e.get('iteration')))
        if st and not st.get('engine_error'):
            row['host_ms']+=st['engine_host_ms'];row['host_samples']+=1
        if e.get('execution_phase')=='current_action':applied[str(cap)]+=1
        pr=prev.get(e['replica'])
        if pr and pr.get('prefill_cap')!=cap and e.get('execution_phase')=='common_continuation':expiration+=1
        prev[e['replica']]=e
    spec=policy_spec(policy)
    if spec['kind']=='fixed' and any(e.get('prefill_cap')!=spec['cap'] for e in its):
        raise RuntimeError('fixed sensitivity control did not keep the declared cap')
    result={'schema':'musique-d0-batching-evidence-1','policy':policy,'scheduler':scheduler,
        'D0_schedule_integrity':{'pass':True,'worker_receipts':len(checks),'commit_fallback_receipts':lost_after_commit,
          'claim':'same source D0 function before cap overlay; native fallbacks separately retained',
          'historical_route_trace_frozen':False},
        'batch_policy_decisions':len(checks),'cap_restriction_plans_committed':selected,
        'opportunity_replica_decisions':opportunity,'reason_counts':dict(reason_counts),
        'batch_policy_wall_ms':{'n':len(wall),'mean':statistics.mean(wall) if wall else 0.,'p95':quantile(wall,.95),'max':max(wall,default=0.)},
        'iteration_phase_counts':dict(phases),'per_cap':dict(bycap),'current_window_caps':dict(applied),
        'observed_cap_changes_to_common_continuation':expiration,
        'cap_binding_is_logical_not_GPU_utilization':True,'exact_cap_counterfactual_executed':False,
        'no_decision_time_subtracted_from_JCT':True,'checks':checks}
    atomic(folder/'batching_evidence.json',result)
    return {k:v for k,v in result.items() if k!='checks'}
