"""Small, measurable cap-only hypotheses, NOT model-certified improvements.

D0 is called first, unmodified. The policy receives its entire chosen action and
current observed progress. It may change caps, never placement/admission/order.
The real development suite, not a self-score, selects a policy by complete JCT.
"""
from __future__ import annotations
import copy, hashlib, json, math, time
from .dependency import activate
activate()
from semantic19.selector import choose as frozen_d0_choose
from joint18v2.model import predict
from joint18v2.common import validate_action

REFERENCE_CAP = 4096
ADAPTIVE = ('mixed_2048', 'mixed_1024', 'completion_1024')
FIXED = tuple('fixed_' + str(x) for x in (256,512,1024,2048,4096))
SCHEDULE_KEYS = ('placement','admit','order')

def scheduling_view(a):
    return {k: copy.deepcopy(a[k]) for k in SCHEDULE_KEYS}

def scheduling_hash(a):
    return hashlib.sha256(json.dumps(scheduling_view(a),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def policy_spec(name):
    if name in FIXED: return {'name':name,'kind':'fixed','cap':int(name.split('_')[1])}
    if name in ADAPTIVE:
        return {'name':name, 'kind':'completion' if name.startswith('completion') else 'mixed',
                'cap':int(name.split('_')[-1])}
    raise ValueError('unknown preregistered batching policy: ' + str(name))

def completion_opportunity(key, nodes, step_ms, remaining_window_ms, output_priors=None):
    """Estimated finish within this action window AND unlocks a successor or sink.

Uses current output progress and the frozen training prior, not actual future EOS.
A response reaching the output prior is not declared completed. Existing client
raises its estimate as observed output grows; we still require at least one step.
"""
    n = nodes[key]
    prior=(output_priors or {}).get(str(n.get('hop_count')), {})
    expected_total=max(1, int(prior.get('p75', n.get('output',1))))
    estimate = max(1, expected_total - int(n.get('output_done', 0)))
    completion_ms = estimate * step_ms
    successors = [k for k, x in nodes.items() if key in x.get('parents', []) and x.get('state') != 'done']
    released = [k for k in successors if all(p == key or nodes[p].get('state') == 'done' for p in nodes[k].get('parents', []))]
    sink = not n.get('compiled_successors', successors)
    eligible = bool((sink or released) and completion_ms <= remaining_window_ms)
    return {'node':key,'estimated_remaining_tokens':estimate,'estimated_finish_ms':completion_ms,
            'is_sink':sink,'would_release':released,'eligible':eligible,'future_EOS_known':False,
            'length_source':'frozen_development_p75' if prior else 'snapshot_output_estimate',
            'observed_output_exceeds_p75':bool(prior and n.get('output_done',0)>=expected_total)}

def choose_caps(snapshot, action, model, cfg, policy):
    spec = policy_spec(policy); R = snapshot['replicas']; caps = [REFERENCE_CAP] * R
    evidence = {'policy':policy,'cap_only':True,'post_D0_placement':True,'replicas':[],
                'additional_online_search_calls':0,'real_gain_guaranteed':False}
    if spec['kind'] == 'fixed':
        return [spec['cap']]*R, {**evidence,'reason':'fixed_cap'}
    ages = snapshot.get('state_ages_s', [])
    window = max(0., float(cfg.get('action_horizon_ms', 200.)) - float(cfg.get('apply_delay_ms', 0.)))
    if len(ages) != R or any(not math.isfinite(x) or x < -.005 or x > cfg['snapshot_max_age_s'] for x in ages):
        return caps, {**evidence,'reason':'stale_or_missing_observation_keeps_4096'}
    if snapshot.get('cache_unknown_count', 0):
        return caps, {**evidence,'reason':'unknown_cache_keeps_4096'}
    if window <= 0: return caps, {**evidence,'reason':'no_remaining_window'}
    nodes = snapshot['nodes']; placements = action['placement']; admitted = set(action['admit'])
    for r in range(R):
        dec, pre = [], []
        for k,n in nodes.items():
            if n.get('state') == 'submitted': where = n.get('replica')
            elif k in admitted and n.get('state') == 'ready': where = placements[k]
            else: continue
            if where != r: continue
            if n.get('phase') == 'decode': dec.append(k)
            else:
                rem = max(0, int(n['prompt']) - int(n.get('computed',0)))
                if not rem: continue
                h = n.get('prefix_hash'); observed = None
                for e in snapshot.get('cache_evidence', []):
                    if e.get('prefix_hash') == h and e.get('replica') == r and e.get('known'):
                        age = float(e.get('observed_age_s', 0.))
                        if age <= cfg.get('cache_evidence_max_age_s', .12):
                            observed = int(e.get('tokens',0))
                            break
                if h and observed is None:
                    pre.append({'node':k,'logical_remaining':rem,'known':False}); continue
                overlap = max(0, min(int(n['prompt']), observed or 0) - int(n.get('computed',0)))
                # A last query token may still be computed; the native scheduler charges
                # logical work separately. This is an opportunity estimate, not a FLOP count.
                new_work = max(1, rem - min(overlap,max(0,rem-1)))
                pre.append({'node':k,'logical_remaining':rem,'observed_cached_remaining':overlap,
                            'uncached_query_proxy':new_work,'known':True})
        row={'replica':r,'decode_nodes':dec,'prefill':pre,'selected_cap':REFERENCE_CAP,
             'remaining_window_ms':window,'scope':'observed state, cache-adjusted opportunity proxy'}
        if not pre or not dec: row['reason']='not_mixed_keeps_4096'
        elif any(not x['known'] for x in pre): row['reason']='unknown_prefix_keeps_4096'
        elif sum(x['uncached_query_proxy'] for x in pre) <= spec['cap']:
            row['reason']='too_little_new_prefill_to_justify_throttling'
        elif spec['kind']=='mixed':
            caps[r]=spec['cap'];row['reason']='mixed_cold_prefill_test'
        else:
            context=sum(nodes[k]['prompt']+nodes[k].get('output_done',0) for k in dec)
            try: step=float(predict(model,r,0,len(dec),context,0,0))
            except (KeyError,TypeError,ValueError,IndexError,OverflowError): step=float('nan')
            if not math.isfinite(step) or step<=0: row['reason']='unusable_finish_estimate_keeps_4096'
            else:
                probes=[completion_opportunity(k,nodes,step,window,cfg.get('batching20_output_priors')) for k in dec]
                row.update(decode_step_ms=step,workflow_finish_probes=probes)
                if any(p['eligible'] for p in probes):
                    caps[r]=spec['cap'];row['reason']='preserve_near_completion_or_dependency_release'
                else: row['reason']='no_predicted_finish_in_window_keeps_4096'
        row['selected_cap']=caps[r];evidence['replicas'].append(row)
    evidence.update(reason='evaluated',changed_replicas=[r for r,c in enumerate(caps) if c!=REFERENCE_CAP])
    return caps,evidence

def process_plan(snapshot, model, cfg, method, deadline):
    """Picklable client worker entry; the D0 mapping/guards/model are unmodified.

The D0 reference remains 4096 even in a fixed-cap sensitivity condition. Actual
state/current_caps remain observed, not fabricated. This freezes a policy, not a
historical sequence of decisions or a no-regression theorem.
"""
    if method != 'D': raise ValueError('batching adapter may only augment frozen D0')
    dcfg = {k:v for k,v in cfg.items() if not k.startswith('batching20_')}
    dcfg['base_cap'] = REFERENCE_CAP
    ans = frozen_d0_choose(snapshot, model, dcfg, 'D', deadline)
    before = copy.deepcopy(ans['action']); started = time.monotonic()
    name = cfg.get('batching20_policy', 'fixed_4096'); spec = policy_spec(name)
    if spec['kind'] != 'fixed' and time.monotonic() >= deadline:
        caps=[REFERENCE_CAP]*snapshot['replicas']; ev={'policy':name,'reason':'no_budget_time_after_D0','replicas':[]}
    else:
        bcfg=dict(dcfg)
        bcfg['batching20_output_priors']=cfg.get('batching20_output_priors',{})
        caps,ev = choose_caps(snapshot,before,model,bcfg,name)
    after = copy.deepcopy(before); after['caps'] = caps
    if scheduling_view(before) != scheduling_view(after): raise RuntimeError('batching changed D0 scheduling')
    validate_action(after, snapshot, dcfg)
    ans['action'] = after
    ans['batching20'] = {'policy':name,'D0_action':before,'D0_schedule_hash':scheduling_hash(before),
          'emitted_schedule_hash':scheduling_hash(after),'D0_schedule_unchanged':True,
          'D0_reference_cap':REFERENCE_CAP,'additional_wall_ms':1000*(time.monotonic()-started),
          'evidence':ev,'no_online_batch_rollout':True,'source_D0_guards_unchanged':True,
          'TPOT_quality_not_batch_selection_vetoes':True}
    return ans
