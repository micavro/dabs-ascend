"""Process-local binding only; restores all imported names on exit."""
from __future__ import annotations
from contextlib import contextmanager
from .dependency import activate
activate()
from .policy import process_plan
from typed19.transport import stream
import joint18v2.client as client

@contextmanager
def bindings():
    old = client.process_plan, client.stream
    client.process_plan = process_plan; client.stream = stream
    try: yield
    finally: client.process_plan, client.stream = old
