from __future__ import annotations
import copy, hashlib, json, math
from .policy import FIXED, ADAPTIVE

def key(r): return format(float(r), 'g')
def load_name(name): return 'R' + key(name)

def development_design(protocol):
    names=['A-F4096']+['D0-F'+p.split('_')[1] for p in FIXED]+['D0-'+p for p in ADAPTIVE]
    out=[]
    # Predeclared, not result-dependent. Rates and method positions vary across blocks.
    for block in (1,2):
        rates=list(protocol['rates'])
        if block==2: rates.reverse()
        for r in rates:
            ri=protocol['rates'].index(r); shift=(ri*3+(block-1)*4)%len(names)
            order=names[shift:]+names[:shift]
            if block==2:order=list(reversed(order))
            for pos,name in enumerate(order,1):
                policy='fixed_4096' if name=='A-F4096' else ('fixed_'+name[4:] if name.startswith('D0-F') else name[3:])
                out.append({'rate':float(r),'block':block,'position':pos,'name':name,
                    'scheduler':'A' if name=='A-F4096' else 'D','policy':policy,
                    'packet_slice':[(block-1)*16,block*16],'seed':200100+block,
                    'label':f'R{key(r)}_B{block}_{pos}_{name}'})
    return out

def confirmation_design(protocol,selection):
    out=[]
    for block in range(1,5):
        rates=list(protocol['rates']);rates=rates[(block-1)%3:]+rates[:(block-1)%3]
        for r in rates:
            fixed='fixed_'+str(selection['best_fixed_per_rate'][key(r)])
            roles=[('A-F4096','A','fixed_4096'),('D0-F4096','D','fixed_4096'),
                ('D0-BestFixed','D',fixed),('D0-Mix','D',selection['mixed_policy']),
                ('D0-Adaptive','D',selection['adaptive_policy'])]
            unique={}
            for role,sched,p in roles:unique.setdefault((sched,p),[]).append(role)
            cells=[{'scheduler':s,'policy':p,'roles':v} for (s,p),v in unique.items()]
            shift=(block-1+protocol['rates'].index(r))%len(cells);cells=cells[shift:]+cells[:shift]
            if block%2==0:cells.reverse()
            for pos,cell in enumerate(cells,1):
                out.append({**cell,'name':cell['roles'][0],'rate':float(r),'block':block,'position':pos,
                    'packet_slice':[(block-1)*16,block*16],'seed':200200+block,
                    'label':f'R{key(r)}_B{block}_{pos}_{cell["roles"][0]}'})
    return out

def validate_rows(rows, design):
    expected={d['label'] for d in design}
    if len(rows)!=len(design) or {r['label'] for r in rows}!=expected:
        raise ValueError('suite missing or duplicates; no partial winner selection')
    for row in rows:
        s=row['summary']
        if not s.get('condition_valid') or not s.get('D0_schedule_integrity',{}).get('pass',False):
            raise ValueError('invalid execution or schedule integrity')
        if s.get('workflows')!=16:raise ValueError('expected N16')
        if not math.isfinite(s['mean_jct_ms']) or s['mean_jct_ms']<=0:raise ValueError('invalid JCT')
    groups={}
    for r in rows:groups.setdefault((r['rate'],r['block']),[]).append(r)
    for group in groups.values():
        if len({r['external_work_sha256'] for r in group})!=1:
            raise ValueError('external questions/arrival offsets differ within paired block')
    return True

def select(rows,protocol):
    validate_rows(rows,development_design(protocol))
    by={(key(r['rate']),r['block'],r['scheduler'],r['policy']):r['summary'] for r in rows}
    best={};fixed_table={}
    for rate in protocol['rates']:
        kr=key(rate);candidates=[]
        for p in FIXED:
            mean=sum(by[kr,b,'D',p]['mean_jct_ms'] for b in (1,2))/2
            candidates.append({'policy':p,'mean_jct_ms':mean})
        win=min(candidates,key=lambda c:(c['mean_jct_ms'],c['policy']!='fixed_4096',-int(c['policy'].split('_')[1])))
        best[kr]=int(win['policy'].split('_')[1]);fixed_table[kr]=candidates
    scores=[]
    for p in ADAPTIVE:
        gs=[];byrate={}
        for rate in protocol['rates']:
            kr=key(rate);g=[]
            for b in (1,2):
                ref=by[kr,b,'D','fixed_'+str(best[kr])]['mean_jct_ms'];v=by[kr,b,'D',p]['mean_jct_ms']
                g.append(100*(ref-v)/ref)
            byrate[kr]=sum(g)/2;gs.extend(g)
        scores.append({'policy':p,'mean_paired_gain_vs_best_fixed_pct':sum(gs)/len(gs),
                       'by_rate':byrate,'positive_blocks':sum(v>0 for v in gs),'blocks':len(gs)})
    ranked=sorted(scores,key=lambda r:(-r['mean_paired_gain_vs_best_fixed_pct'],r['policy']))
    mixed=next(x for x in ranked if x['policy'].startswith('mixed_'))
    return {'schema':'musique-d0-batch-selection-1','best_fixed_per_rate':best,'fixed_table':fixed_table,
            'adaptive_policy':ranked[0]['policy'],'mixed_policy':mixed['policy'],'adaptive_scores':ranked,
            'selection_metric':'complete mean workflow JCT, equal-rate/equal-block normalized gains',
            'quality_or_TPOT_used_for_selection':False,'selected_even_if_negative':True,
            'positive_development_mean':ranked[0]['mean_paired_gain_vs_best_fixed_pct']>0,
            'all_rates_retained':True,'heldout_outcomes_used':False,'development_repeated_until_win':False}
