"""Prepare -> complete declared development -> freeze -> paired validation -> seal.

No package installation, dataset download, backend deployment or automatic retries.
"""
from __future__ import annotations
import argparse,asyncio,copy,csv,fcntl,hashlib,json,multiprocessing,os,statistics,sys,time,uuid,zipfile
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from types import SimpleNamespace
from .dependency import ROOT,SOURCE,TYPED,activate,verify,sha,own_identity,typed_runner
activate()
from . import REVISION
from .policy import policy_spec, REFERENCE_CAP
from .protocol import development_design,confirmation_design,validate_rows,select,key
from .report import write_tables,build_confirmation_report
from .telemetry import inspect_condition
from .binding import bindings
from semantic19.dataset import load_public
from typed19.workflow import ServerTokenizer,compile_packets,instantiate
from typed19.quality import evaluate as quality_evaluate
from joint18v2.common import atomic,load,digest
from joint18v2.client import gate,execute,wait_drained,token_pool
HOOK='78ca1d716c5701a9f83ba7dc0b22669b6b50a38bd54626a56642130cd1684418'

def protocol():return load(ROOT/'configs/protocol.json')
def stamp(prefix):return prefix+'_'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'_'+uuid.uuid4().hex[:8]
def compact(s):return {k:v for k,v in s.items() if k not in ('workflow_rows','unfinished_workflow_curve','request_latency_rows','quality_rows','typed_response_rows')}
def worker_ready():return os.getpid()

def preflight():
    dependencies=verify();t=typed_runner()
    result={'pass':True,'source_files_verified':len(dependencies),'D0_source_sha256':dependencies['source/semantic19/selector.py'],
       'new_revision':REVISION,'source_scheduler_changed':False,'backend_changed':False,
       'GPU_REQUESTS':0,'NETWORK_REQUESTS':0,'LIVE_RUNTIME_READS':0}
    print('BATCHING_PREFLIGHT='+json.dumps(result),flush=True);return result

def freeze_inputs(dataset,prepared=None):
    dependencies=verify();t=typed_runner();p=protocol()
    olddir,model,priors,mf=t.prepared(SimpleNamespace(prepared=prepared))
    if mf['best_fixed_cap']!=REFERENCE_CAP:
        raise ValueError('expected recorded D0 checkpoint cap4096; different artifact supplied, no source changed')
    dataset=Path(dataset).resolve()
    if sha(dataset/'manifest.json')!=mf['dataset_manifest_sha256']:raise ValueError('checkpoint dataset mismatch')
    train,dm=load_public(dataset,'profile');test,_=load_public(dataset,'pilot')
    if len(train)!=32 or len(test)!=64:raise ValueError('expected existing 32 train / 64 dev compiled subsets')
    if {r['id'] for r in train}&{r['id'] for r in test}:raise ValueError('development/confirmation overlap')
    cf=load(TYPED/'configs/semantic.json');cf['base_cap']=REFERENCE_CAP;cf['workflow_count']=16
    if cf['hard_total']!=4096 or cf['epoch_s']!=.2 or cf['replicas']!=4:raise ValueError('D0 environment mismatch')
    snapshot={'revision':REVISION,'checkpoint':p['checkpoint'],'source_prepared':str(Path(olddir).resolve()),
       'source_manifest_sha256':sha(Path(olddir)/'manifest.json'),'dataset':str(dataset),
       'dataset_manifest_sha256':sha(dataset/'manifest.json'),'dataset_files':dm['files'],
       'source_hashes':dependencies,'adapter_hashes':own_identity(),
       'D0_configuration':cf,'protocol':p,'train_ids':[r['id'] for r in train],
       'validation_ids':[r['id'] for r in test],
       'no_new_questions_downloaded':True,'validation_questions_previously_seen':True,
       'model_refitted':False,'new_quality_or_TPOT_veto':False}
    for name in ('model.json','priors.json'):
        if sha(Path(olddir)/name)!=mf['files'][name]:raise ValueError('old frozen artifact changed')
    prior_pointer=ROOT/'prepared/latest.json'
    if prior_pointer.is_file():
        prev=Path(load(prior_pointer)['directory']);old=load(prev/'manifest.json')
        for k,v in snapshot.items():
            if old.get(k)!=v:raise ValueError('a different preparation already exists; preserve it and use a new package directory')
        if sha(prev/'model.json')!=old['files']['model.json'] or sha(prev/'priors.json')!=old['files']['priors.json']:
            raise ValueError('prepared model/priors changed')
        print('D0_FROZEN_REUSED='+str(prev));return prev
    out=ROOT/'prepared'/stamp('D0_FROZEN');out.mkdir(parents=True)
    # Copy original bytes, not a reserialization with a new model identity.
    for name in ('model.json','priors.json'):(out/name).write_bytes((Path(olddir)/name).read_bytes())
    (out/'source_profile_manifest.json').write_bytes((Path(olddir)/'manifest.json').read_bytes())
    atomic(out/'config.json',cf);atomic(out/'protocol.json',p)
    snapshot['files']={x:sha(out/x) for x in ('model.json','priors.json','source_profile_manifest.json','config.json','protocol.json')}
    atomic(out/'manifest.json',snapshot);atomic(prior_pointer,{'directory':str(out.resolve())})
    print('D0_FROZEN='+json.dumps({'directory':str(out),'D0_reference_cap':REFERENCE_CAP,
       'development_conditions':len(development_design(p)),'model_bytes_unchanged':True,
       'new_GPU_requests':0,'no_backend_restart':True}),flush=True)
    return out

def load_frozen():
    pointer=ROOT/'prepared/latest.json'
    if not pointer.is_file():raise FileNotFoundError('run_prepare.sh first; no new GPU calibration required')
    d=Path(load(pointer)['directory']);mf=load(d/'manifest.json')
    if mf['source_hashes']!=verify() or mf['adapter_hashes']!=own_identity():raise ValueError('source changed after D0 preparation')
    if mf['protocol']!=protocol():raise ValueError('protocol changed after freeze')
    for name,h in mf['files'].items():
        if sha(d/name)!=h:raise ValueError('frozen artifact changed: '+name)
    dataset=Path(mf['dataset'])
    if sha(dataset/'manifest.json')!=mf['dataset_manifest_sha256']:raise ValueError('dataset changed after freeze')
    for name,h in mf['dataset_files'].items():
        if sha(dataset/name)!=h:raise ValueError('dataset file changed: '+name)
    return d,mf,load(d/'model.json'),load(d/'priors.json')

def find_completed(command,freeze):
    point=ROOT/'records'/(command+'_latest.json')
    if not point.is_file():return None
    q=load(point);r=Path(q['directory'])
    if q['frozen_manifest_sha256']!=sha(freeze/'manifest.json'):raise ValueError('existing suite pointer belongs to another frozen experiment')
    if load(r/'suite_status.json')['status']!='complete':raise ValueError('suite pointer not complete')
    return r

def read_selection(frozen):
    dev=find_completed('develop',frozen)
    if dev is None:raise FileNotFoundError('complete run_develop.sh first')
    receipt=load(dev/'selection_receipt.json')
    for path,h in receipt['files'].items():
        if sha(dev/path)!=h:raise ValueError('development selection material changed')
    s=load(dev/'selection.json')
    # Selection must remain reproducible from *all* declared development rows.
    if s!=select(load(dev/'index.json'),protocol()):raise ValueError('selection differs from preregistered JCT rule')
    return dev,s

async def warmup(client,runtime,initial,cfg,out,tokenizer):
    from tools.experiment import warm_nodes,FixedWarmup,salt
    pool=await token_pool(client,cfg['model'])
    for i,prof in enumerate(((512,32),(3328,64)),1):
        ns=warm_nodes(cfg,pool,prof,salt(pool))
        await execute(client,runtime,initial,cfg,ns,out/'SERVICE_WARMUP'/f'P{i}','Forced',None,mechanism=FixedWarmup())
    print('SERVICE_WARMUP_COMPLETE=True REQUESTS=8 MEASURED=False',flush=True)
    await typed_runner().warm_schema(client,runtime,initial,cfg,out,tokenizer,pool)

def verify_semantic(nodes):
    bound=0
    for n in nodes.values():
        if n['state']!='done':raise ValueError('incomplete semantic node')
        for parent in n['parents']:
            b=n.get('parent_response_bindings',{}).get(str(nodes[parent]['step_position']+1))
            if not b or b['response']!=nodes[parent]['stream']['text']:raise ValueError('real parent binding changed')
            bound+=1
    return bound

async def live(command,runtime):
    import httpx
    frozen,mf,model,priors=load_frozen();cfg=copy.deepcopy(mf['D0_configuration']);p=mf['protocol'];dataset=Path(mf['dataset'])
    if command=='gate':
        async with httpx.AsyncClient(timeout=30,trust_env=False) as client:
            ss=await gate(client,runtime,4)
            if any(s.get('hook_source_sha256')!=HOOK for s in ss):raise ValueError('native hook differs; do not deploy anything')
        print('GATE_READY=True MODEL_GENERATION_REQUESTS=0 BACKEND_CHANGED=False');return
    old=find_completed(command,frozen)
    if old is not None:
        print('SUITE_ALREADY_COMPLETE='+str(old)+' NO_NEW_GPU_REQUESTS=True');return
    dev=selection=None
    if command=='confirm':dev,selection=read_selection(frozen)
    design=development_design(p) if command=='develop' else confirmation_design(p,selection)
    split='profile' if command=='develop' else 'pilot'
    records,dm=load_public(dataset,split)
    runtime=Path(runtime)
    if not runtime.is_dir():raise FileNotFoundError('runtime directory missing; no fake status or directory will be created')
    with (runtime/'experiment.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        with bindings():
            async with httpx.AsyncClient(timeout=httpx.Timeout(180,connect=5,pool=10),trust_env=False,
                    limits=httpx.Limits(max_connections=192,max_keepalive_connections=64,keepalive_expiry=2)) as client:
                initial=await gate(client,runtime,4)
                if any(s.get('hook_source_sha256')!=HOOK for s in initial):raise ValueError('native hook differs')
                out=ROOT/'runs'/stamp('D0_BATCH_'+command.upper());out.mkdir(parents=True)
                print('RESULT='+str(out),flush=True)
                atomic(out/'environment.json',initial);atomic(out/'dataset_manifest.json',dm)
                atomic(out/'frozen_protocol.json',{'revision':REVISION,'command':command,'design':design,'config':cfg,
                  'frozen_manifest':str(frozen/'manifest.json'),'frozen_manifest_sha256':sha(frozen/'manifest.json'),
                  'no_quality_or_TPOT_gate':True,'all_declared_conditions_completed_before_selection':True,
                  'D0_source_unchanged':True,'no_guaranteed_real_nonregression':True,
                  'code_hashes':{**verify(),**own_identity()},'existing_question_validation':command=='confirm'})
                atomic(out/'suite_status.json',{'status':'running','expected_conditions':len(design)})
                if selection is not None:
                    atomic(out/'selection.json',selection);atomic(out/'selection_receipt.json',{'development':str(dev),'sha256':sha(dev/'selection.json')})
                rows=[];executor=None;success=False
                try:
                    tok=ServerTokenizer(client,cfg['model'])
                    packets,info=await compile_packets(records,tok,cfg);atomic(out/'packet_preparation.json',info)
                    executor=ProcessPoolExecutor(1,mp_context=multiprocessing.get_context('spawn'))
                    await asyncio.get_running_loop().run_in_executor(executor,worker_ready)
                    await warmup(client,runtime,initial,cfg,out,tok)
                    print('BATCH_SUITE_BEGIN='+json.dumps({'phase':command,'measured_conditions':len(design),'rates':p['rates'],'N':16}),flush=True)
                    for cell in design:
                        load_frozen()  # source/model/data freeze checked between conditions, never rewritten
                        cc=copy.deepcopy(cfg);cc['arrival_rate']=cell['rate'];cc['workflow_count']=16
                        cc['batching20_policy']=cell['policy']
                        cc['batching20_output_priors']=priors
                        spec=policy_spec(cell['policy'])
                        cc['base_cap']=spec['cap'] if spec['kind']=='fixed' else REFERENCE_CAP
                        lo,hi=cell['packet_slice'];ps=packets[lo:hi]
                        if len(ps)!=16:raise ValueError('declared question cohort unavailable')
                        nodes,materialize,proof=await instantiate(ps,tok,cc,cell['seed'],priors)
                        external=digest({'ids':[q['id'] for q in ps],'arrival_offsets':proof['arrivals'],
                            'evidence_hashes':[q['evidence_hash'] for q in ps],
                            'graphs':[q['graph'] for q in ps], 'output_protocol':'typed_JSON_natural_EOS_max96'})
                        folder=out/cell['label'];start_record={**cell,'external_work_sha256':external}
                        print('D0_BATCH_CONDITION_START='+json.dumps(start_record),flush=True)
                        summary,events=await execute(client,runtime,initial,cc,nodes,folder,cell['scheduler'],model,
                                       executor=executor if cell['scheduler']=='D' else None,materializer=materialize)
                        if not summary['condition_valid']:raise RuntimeError('invalid native condition')
                        if summary['native_next_batch_matches']!=summary['native_next_batch_checked']:raise RuntimeError('native batch correspondence failure')
                        edges=verify_semantic(nodes)
                        telemetry=inspect_condition(folder,cell['policy'],cell['scheduler'])
                        # Quality remains recorded, never a gate or data-selection criterion.
                        quality=quality_evaluate(nodes,dataset,summary['cohort_duration_s'])
                        summary.update(quality);summary.update(telemetry)
                        summary.update(semantic_edges_verified=edges,source_questions=[q['id'] for q in ps],
                           batching_experiment_revision=REVISION,method_label=cell['name'],D0_frozen_model_sha256=mf['files']['model.json'],
                           external_work_sha256=external,output_work_forced_equal=False,quality_or_TPOT_not_selection_gate=True)
                        atomic(folder/'semantic_proof.json',proof);atomic(folder/'quality.json',quality)
                        atomic(folder/'summary.json',summary)
                        rows.append({**cell,'folder':str(folder.resolve()),'external_work_sha256':external,'summary':compact(summary)})
                        atomic(out/'index.json',rows);write_tables(out,rows)
                        print('D0_BATCH_CONDITION_DONE='+json.dumps({**cell,'external_work_sha256':external,**compact(summary)},ensure_ascii=False),flush=True)
                    validate_rows(rows,design)
                    if command=='develop':
                        chosen=select(rows,p);atomic(out/'selection.json',chosen)
                        atomic(out/'selection_receipt.json',{'files':{n:sha(out/n) for n in ('index.json','selection.json','frozen_protocol.json')}})
                        print('BATCH_DEVELOPMENT_FROZEN='+json.dumps(chosen),flush=True)
                    else:
                        report=build_confirmation_report(rows,p,selection)
                        atomic(out/'batching_result.json',report);write_tables(out,rows,report)
                        print('MUSIQUE_D0_BATCHING_RESULT='+json.dumps(report),flush=True)
                    atomic(out/'suite_status.json',{'status':'complete','measured_conditions':len(rows),'all_positive_and_negative_retained':True})
                    success=True
                except BaseException as ex:
                    atomic(out/'suite_status.json',{'status':'failed','completed_conditions':len(rows),'error':repr(ex),'automatic_retry':False})
                    raise
                finally:
                    if executor:executor.shutdown(wait=True,cancel_futures=True)
                    atomic(runtime/'joint18v2/control.json',{'enabled':False})
                    try:dr=await wait_drained(runtime,initial)
                    except Exception:dr=False
                    unchanged=verify()==mf['source_hashes'] and own_identity()==mf['adapter_hashes']
                    cleanup={'backend_drained':dr,'source_files_unchanged':unchanged,'scheduler_model_unchanged':sha(frozen/'model.json')==mf['files']['model.json'],
                             'backend_code_changed':False,'old_runs_overwritten':False}
                    atomic(out/'cleanup.json',cleanup);print('CLEANUP='+json.dumps(cleanup),flush=True)
                    if not dr or not unchanged:raise RuntimeError('cleanup/identity incomplete; stop and keep all records')
                if success:
                    atomic(ROOT/'records'/(command+'_latest.json'),{'directory':str(out.resolve()),'frozen_manifest_sha256':sha(frozen/'manifest.json')})
    if command=='confirm':seal()

def seal():
    frozen,mf,_,_=load_frozen();dev,selection=read_selection(frozen);conf=find_completed('confirm',frozen)
    if conf is None:raise FileNotFoundError('complete confirmation first; no partial seal')
    out=ROOT/'archives';out.mkdir(parents=True,exist_ok=True)
    name=stamp('MUSIQUE_D0_BATCHING_ARCHIVE')+'.zip';dest=out/name
    sources=[]
    for label,path in [('frozen',frozen),('development',dev),('confirmation',conf)]:
        for f in sorted(path.rglob('*')):
            if f.is_file() and not f.is_symlink():sources.append((f,label+'/'+str(f.relative_to(path))))
    for rel in own_identity():sources.append((ROOT/rel,'code/'+rel))
    for base in (ROOT/'docs',ROOT/'analysis'):
        for f in sorted(base.rglob('*')):
            if f.is_file() and f.suffix not in ('.py','.json','.sh'):sources.append((f,'code/'+str(f.relative_to(ROOT))))
    if (ROOT/'README.md').is_file():sources.append((ROOT/'README.md','code/README.md'))
    hashes={arc:sha(f) for f,arc in sources}
    with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f,arc in sources:z.write(f,arc)
        z.writestr('ARCHIVE_SHA256SUMS',''.join(h+'  '+n+'\n' for n,h in sorted(hashes.items())))
        z.writestr('ARCHIVE_SCOPE.json',json.dumps({'all_raw_current_development_and_confirmation_records':True,
               'real_success_not_inferred_from_archive_completion':True,
               'source_dependency_hashes':mf['source_hashes'],'dataset_manifest_sha256':mf['dataset_manifest_sha256'],
               'historical_checkpoint':mf['checkpoint'],'model_source':mf['source_prepared'],
               'entire_server_disk_backup':False},indent=2))
    checksum=sha(dest);dest.with_suffix(dest.suffix+'.sha256').write_text(checksum+'  '+dest.name+'\n')
    print('MUSIQUE_BATCHING_ARCHIVE='+json.dumps({'path':str(dest),'sha256':checksum,'positive_and_negative_results_retained':True}),flush=True)
    return dest

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['plan','preflight','prepare','gate','develop','confirm','seal','report'])
    p.add_argument('--runtime',type=Path,default=Path('/home/wmy/sci/spra_core_exp/joint_e1'))
    p.add_argument('--dataset',type=Path,default=SOURCE/'dataset/compiled')
    p.add_argument('--prepared',type=Path,help='existing typed19 profile directory; no model refit')
    p.add_argument('--run-dir',type=Path)
    a=p.parse_args()
    if a.command=='plan':
        q=protocol();print(json.dumps({**q,'development_conditions':len(development_design(q)),
          'confirmation_max_distinct_conditions':60,'confirmation_role_aliases_not_independent_samples':True,
          'first_commands':'run_prepare.sh -> run_develop.sh -> run_confirm.sh',
          'deployment_restart_download_or_quality_probe_required':False},indent=2,ensure_ascii=False));return
    if a.command=='preflight':preflight();return
    if a.command=='prepare':freeze_inputs(a.dataset,a.prepared);return
    if a.command=='seal':seal();return
    if a.command=='report':
        if a.run_dir is None:raise ValueError('--run-dir required')
        path=a.run_dir/'batching_result.json'
        if not path.is_file():path=a.run_dir/'selection.json'
        print(path.read_text());return
    asyncio.run(live(a.command,a.runtime))
