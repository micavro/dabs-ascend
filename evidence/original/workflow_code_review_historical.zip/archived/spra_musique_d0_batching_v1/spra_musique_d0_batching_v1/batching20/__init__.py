"""MuSiQue batching interventions over a frozen, source-verified D0 scheduler."""
REVISION = 'musique-d0-batching-1'
