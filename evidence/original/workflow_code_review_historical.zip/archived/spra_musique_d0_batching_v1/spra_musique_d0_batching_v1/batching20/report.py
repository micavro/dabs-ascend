from __future__ import annotations
import csv,json,math,statistics
from collections import defaultdict
from pathlib import Path
from .protocol import key
METRICS=('mean_jct_ms','p95_jct_ms','mean_request_ttft_ms','p95_request_ttft_ms',
         'mean_node_time_to_first_content_ms','mean_client_tpot_proxy_ms','p95_client_tpot_proxy_ms',
         'cohort_tokens_s','cohort_workflows_s')

def gain(base,new,higher=False):
    if not isinstance(base,(int,float)) or not isinstance(new,(int,float)) or base<=0:return None
    return 100*(new/base-1) if higher else 100*(1-new/base)

def means(values):
    v=[x for x in values if x is not None];return statistics.mean(v) if v else None

def compare(base,new):
    q0=base.get('semantic_quality',{});q1=new.get('semantic_quality',{})
    out={'gain_pct':{f:gain(base.get(f),new.get(f),f.startswith('cohort_')) for f in METRICS},
         'quality_relative_gain_pct':{f:gain(q0.get(f),q1.get(f),True) for f in ('final_em','final_f1')},
         'quality_absolute_change_pp':{f:100*(q1[f]-q0[f]) if f in q0 and f in q1 else None for f in ('final_em','final_f1')},
         'output_tokens_reference':base.get('output_tokens'),'output_tokens_candidate':new.get('output_tokens'),
         'equal_output_count_not_equal_semantic_work':True}
    return out

def build_confirmation_report(rows,protocol,selection):
    role_rows={}
    for r in rows:
        for role in r['roles']:role_rows[(key(r['rate']),r['block'],role)]=r['summary']
    contrasts=[('D0-F4096','A-F4096'),('D0-BestFixed','D0-F4096'),('D0-Adaptive','D0-F4096'),
               ('D0-Adaptive','D0-BestFixed'),('D0-Adaptive','D0-Mix'),('D0-Adaptive','A-F4096')]
    pairs=[]
    for rate in protocol['rates']:
        for b in range(1,5):
            for new,ref in contrasts:
                one={'rate':rate,'block':b,'candidate':new,'reference':ref}
                a=role_rows[(key(rate),b,ref)];z=role_rows[(key(rate),b,new)]
                one.update(compare(a,z));pairs.append(one)
    aggregates=[]
    for rate in protocol['rates']:
        for new,ref in contrasts:
            pp=[p for p in pairs if p['rate']==rate and p['candidate']==new and p['reference']==ref]
            values=[p['gain_pct']['mean_jct_ms'] for p in pp]
            aggregates.append({'rate':rate,'candidate':new,'reference':ref,
               'mean_paired_gain_pct':{f:means([p['gain_pct'][f] for p in pp]) for f in METRICS},
               'positive_JCT_blocks':sum(x>0 for x in values),'blocks':len(values),
               'paired_JCT_gain_range_pct':[min(values),max(values)],
               'uncertainty_note':'four different question cohorts, not independent repetitions of one physical trace'})
    incremental=[r for r in aggregates if r['candidate']=='D0-Adaptive' and r['reference']=='D0-BestFixed']
    total=[r for r in aggregates if r['candidate']=='D0-Adaptive' and r['reference']=='A-F4096']
    report={'schema':'musique-d0-adaptive-confirmation-1','primary':'complete mean workflow JCT',
        'pairs':pairs,'aggregates':aggregates,'selection':selection,
        'mean_batch_increment_pct_all_rates':means([r['mean_paired_gain_pct']['mean_jct_ms'] for r in incremental]),
        'mean_total_gain_pct_all_rates':means([r['mean_paired_gain_pct']['mean_jct_ms'] for r in total]),
        'retained_all_declared_rates':True,'quality_and_TPOT_are_auxiliary_not_vetoes':True,
        'no_runtime_cost_subtracted':True,'formal_significance_established':False,
        'question_holdout_is_unseen':False,'new_execution_after_policy_freeze':True,
        'D0_policy_preservation_not_performance_guarantee':True,
        'D0_Mix_alias_of_adaptive':selection['mixed_policy']==selection['adaptive_policy'],
        'full_joint_placement_reoptimization_tested':False,
        'scope':'conditional batching increment on frozen D0; not a new simultaneous placement/batching optimizer'}
    report['adaptive_increment_observed_in_this_batch'] = report['mean_batch_increment_pct_all_rates'] > 0
    report['archive_recommendation'] = ('retain_candidate_as_development_evidence' if report['adaptive_increment_observed_in_this_batch'] else 'retain_D0_checkpoint; batching_increment_not_established')
    return report

def write_tables(folder,rows,report=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    fields=['rate','block','position','name','scheduler','policy','alias_roles','folder']+list(METRICS)+['final_em','final_f1','output_tokens','cap_binding_candidates','schedule_integrity']
    with (folder/'conditions.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fields);w.writeheader()
        for r in rows:
            s=r['summary'];q=s.get('semantic_quality',{})
            w.writerow({**{k:r.get(k) for k in fields[:7] if k!='alias_roles'},'folder':r.get('folder'),
                'alias_roles':'|'.join(r.get('roles',[])),**{k:s.get(k) for k in METRICS},
                'final_em':q.get('final_em'),'final_f1':q.get('final_f1'),'output_tokens':s.get('output_tokens'),
                'cap_binding_candidates':s.get('native_cap_binding_candidates'),
                'schedule_integrity':s.get('D0_schedule_integrity',{}).get('pass')})
    if report is not None:
        lines=['# MuSiQue: frozen D0 + adaptive batching','',
            'All waits remain in workflow JCT. Natural output lengths and quality are retained.',
            'Positive percentages denote lower JCT. Four blocks contain different question sets.',
            'Confirmation reuses previously measured questions; it is not an unseen-question holdout.','',
            '| Rate | Comparison | Mean paired JCT gain | Positive blocks |',
            '|---:|---|---:|---:|']
        for r in report['aggregates']:
            lines.append(f"| {r['rate']:g} | {r['candidate']} vs {r['reference']} | {r['mean_paired_gain_pct']['mean_jct_ms']:.3f}% | {r['positive_JCT_blocks']}/{r['blocks']} |")
        lines+=['','A-F4096 is a contemporaneous frozen reference, not a new per-rate tuned A oracle.',
          'D0-BestFixed is chosen from development runs at each rate; no confirmation result changes the policy.',
          'A method alias refers to the same executed condition; it is not an independent replicate.',
          'D0-Mix vs D0-Adaptive diagnoses the selected cap rule, not full joint placement reoptimization.',
          'No all-metric improvement, quality floor, or TPOT non-regression is assumed.']
        (folder/'REPORT.md').write_text('\n'.join(lines)+'\n')
