"""Read-only dependency loading. No in-place patch, deployment, or package install."""
from __future__ import annotations
import hashlib, importlib.util, json, os, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(os.environ.get('STAGE19_SOURCE', ROOT.parent / 'spra_stage19_musique_joint_v1')).resolve()
TYPED = Path(os.environ.get('STAGE19_TYPED_SOURCE', ROOT.parent / 'spra_stage19_typed_handoff_v1')).resolve()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def verify():
    expected = json.loads((ROOT / 'dependency_identity.json').read_text())
    found, bad = {}, {}
    for prefix, base in [('source', SOURCE), ('typed', TYPED)]:
        for rel, want in expected[prefix].items():
            path = base / rel
            got = sha(path) if path.is_file() else None
            found[prefix + '/' + rel] = got
            if got != want: bad[prefix + '/' + rel] = {'expected': want, 'actual': got}
    if bad:
        raise RuntimeError('D0/application dependency differs; no file changed. Do not edit expected hashes: ' + json.dumps(bad))
    return found

def activate():
    identity = verify(); sys.dont_write_bytecode = True
    for base in (TYPED, SOURCE):
        if str(base) not in sys.path: sys.path.insert(0, str(base))
    return identity

def typed_runner():
    activate()
    name = '_frozen_typed19_runner_for_batching20'
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, TYPED / 'tools/run_typed.py')
        module = importlib.util.module_from_spec(spec); sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name]

def own_identity():
    result = {}
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.is_symlink(): continue
        rel = path.relative_to(ROOT)
        if rel.parts[0] in ('runs','prepared','logs','archives','records','__pycache__'): continue
        if path.suffix in ('.py','.json','.sh'):
            result[str(rel)] = sha(path)
    return result
