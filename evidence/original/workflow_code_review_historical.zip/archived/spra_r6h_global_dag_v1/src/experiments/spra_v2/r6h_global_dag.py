from __future__ import annotations
import argparse,asyncio,json,math,os,random,statistics as st,tempfile,time,sys
from collections import Counter
from pathlib import Path
import httpx

ROOT=Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from src.runtime.spra_v2.global_dag_planner import GlobalDAGPlanner,CentralCoordinator,Req

RUNTIME=Path("/home/wmy/sci/spra_core_exp/joint_e1")
MODEL="Qwen2.5-1.5B-Instruct"
ENDPOINTS=[f"http://127.0.0.1:{8000+i}" for i in range(4)]
PODS=[f"spra-vllm-{i}" for i in range(4)]
RATES=(8.0,12.0);BLOCKS=(1,2,3,4);DEFAULT_N=32
OUTTOK={"root":32,"c1":160,"c2":128,"c3":96,"s1":48,"s2":48,"join":64}
SUCC={"root":["c1","s1","s2"],"c1":["c2"],"c2":["c3"],"c3":["join"],
      "s1":["join"],"s2":["join"],"join":[]}
SHARED=("Agent workflow shared context. This long context is intentionally identical across all "
        "nodes of one workflow so that vLLM automatic prefix caching can reuse previously computed "
        "KV blocks. It describes scheduling state, dependency readiness, tool outputs, observations, "
        "constraints, intermediate facts, and persistent agent memory. ")

class ConditionTransportError(RuntimeError):pass

def pct(xs,q):
    if not xs:return None
    a=sorted(xs);p=(len(a)-1)*q;lo=int(math.floor(p));hi=int(math.ceil(p))
    return a[lo] if lo==hi else a[lo]*(hi-p)+a[hi]*(p-lo)

def atomic(path,data):
    fd,tmp=tempfile.mkstemp(prefix=path.name+".",dir=str(path.parent));os.close(fd)
    Path(tmp).write_text(json.dumps(data));os.replace(tmp,path)

def status(runtime,r):
    try:return json.loads((runtime/"backend"/f"spra-vllm-{r}.status.json").read_text())
    except:return {}

def validate(runtime):
    gs=[]
    for r in range(4):
        s=status(runtime,r)
        assert s.get("hook_version")=="spra-v2-telemetry-1",s
        assert int(s.get("num_gpu_blocks") or 0)==4096,s
        assert s.get("prefix_caching") is True,s
        gs.append(s.get("nvidia_visible_devices"))
    assert len(set(gs))==4

async def endpoints_healthy(timeout_s=3):
    async with httpx.AsyncClient(timeout=httpx.Timeout(timeout_s,connect=timeout_s),
                                 limits=httpx.Limits(max_connections=8,max_keepalive_connections=0)) as c:
        out=[]
        for ep in ENDPOINTS:
            try:out.append((await c.get(ep+"/health")).status_code==200)
            except Exception:out.append(False)
        return out

async def wait_idle(runtime,timeout_s=180):
    end=time.monotonic()+timeout_s
    while True:
        z=[status(runtime,r) for r in range(4)]
        if all(int(x.get("running") or 0)==0 and int(x.get("waiting") or 0)==0 for x in z):return
        if time.monotonic()>=end:raise RuntimeError("backend did not drain")
        await asyncio.sleep(.25)

def arrival_offsets(rate,block,n,probe=False):
    if probe:
        seed=1160000+int(rate)*10000+n*100+block*131
    else:
        # exact R6D/R6G arrival seeds
        seed=int(rate)*10000+block*131
    rng=random.Random(seed);gap=1/rate;xs=[]
    for i in range(n):xs.append(max(0.0,i*gap+(rng.random()-.5)*.20*gap))
    xs.sort();xs[0]=0.0;return xs

def msgs(epoch,wid,node):
    shared=(f"CACHE_EPOCH={epoch}; WORKFLOW_PREFIX={wid};\n"+SHARED*30)
    return [{"role":"system","content":shared+f"\nCurrent node type: {node}. This is a controlled serving workload. Generate the exact bounded number of tokens requested by the API."},
            {"role":"user","content":f"workflow={wid}; node={node}. Continue deterministic synthetic agent reasoning about dependencies, scheduling, cached context, and intermediate state."}]

async def tokenize(client,m):
    r=await client.post(ENDPOINTS[0]+"/tokenize",json={"model":MODEL,"messages":m,"add_generation_prompt":True})
    r.raise_for_status();return tuple(r.json()["tokens"])

async def infer(client,r,m,out_tokens):
    payload={"model":MODEL,"messages":m,"temperature":0.0,"seed":0,
             "max_tokens":out_tokens,"min_tokens":out_tokens,"ignore_eos":True,"stream":False}
    t=time.perf_counter_ns()
    try:
        x=await client.post(ENDPOINTS[r]+"/v1/chat/completions",json=payload)
        t2=time.perf_counter_ns();x.raise_for_status();o=x.json();u=o.get("usage") or {}
        return {"latency_ms":(t2-t)/1e6,"request_id":o.get("id"),
                "prompt_tokens":u.get("prompt_tokens"),"output_tokens":u.get("completion_tokens")}
    except (httpx.ReadError,httpx.ConnectError,httpx.RemoteProtocolError,
            httpx.WriteError,httpx.PoolTimeout,httpx.ReadTimeout) as e:
        raise ConditionTransportError(f"replica={r} {type(e).__name__}:{e}") from e

async def calibrate_all(client,runtime):
    atomic(runtime/"control.json",{"case":"R6H/calibration","token_budget":2048})
    pref=[];dec=[];curves=[]
    for r in range(4):
        async def one(label,reps,out):
            m=[{"role":"system","content":f"R6H-CAL-R{r}-{label}; "+("calibration context "*reps)},
               {"role":"user","content":"Perform bounded calibration inference."}]
            tok=await tokenize(client,m);x=await infer(client,r,m,out);return len(tok),x["latency_ms"]
        a1=await one("A1",80,1);a2=await one("A2",320,1)
        b1=await one("B1",200,16);b2=await one("B2",200,128)
        pref.append(max(.001,(a2[1]-a1[1])/max(1,a2[0]-a1[0])))
        dec.append(max(.001,(b2[1]-b1[1])/112.0))
        curve={}
        for k in (1,8,16,24):
            reqs=[]
            for i in range(k):
                m=[{"role":"system","content":f"R6H-CONC-R{r}-K{k}-I{i}; "+SHARED*30},
                   {"role":"user","content":"Run fixed concurrency calibration."}]
                reqs.append(infer(client,r,m,64))
            xs=await asyncio.gather(*reqs)
            curve[k]=st.mean(x["latency_ms"] for x in xs)
            await wait_idle(runtime);await asyncio.sleep(.15)
        curves.append(curve)
    return {"prefill_ms_per_token":pref,"decode_ms_per_token":dec,"slowdown_raw_ms":curves}

def build_tail(planner,cache,i,node):
    memo={}
    def visit(n):
        if n in memo:return memo[n]
        vals=[]
        for c in SUCC[n]:
            q=Req(f"tail/{i}/{c}",f"wf{i:03d}",c,cache[(i,c)],OUTTOK[c],0)
            best=min(planner.base_service(r,q)[0] for r in range(4))
            vals.append(best+visit(c))
        memo[n]=max(vals,default=0.0);return memo[n]
    return visit(node)

async def run_req(q,ch,planner,client,message,nodes):
    planner.start(q,ch)
    try:x=await infer(client,ch["replica"],message,q.out_tokens)
    except Exception:
        planner.active.pop(q.key,None);raise
    planner.finish(q,ch["replica"])
    nodes.append({"workflow_id":q.workflow_id,"node_id":q.node,"replica":ch["replica"],
                  "latency_ms":x["latency_ms"],"prompt_tokens":x["prompt_tokens"],
                  "output_tokens":x["output_tokens"],"matched_tokens":ch["hit"],
                  "slack_ms":ch["slack_ms"],"predicted_completion_ms":ch["predicted_completion_ms"],
                  "planner_wall_ms":ch["planner_wall_ms"],"frontier_size":ch["frontier_size"],
                  "workflow_groups":ch["workflow_groups"]})
    return x

async def workflow(i,off,epoch,planner,coord,cache,client,nodes,wfs):
    await asyncio.sleep(off);wid=f"wf{i:03d}";start=time.perf_counter_ns()
    def make(name):
        return Req(f"{wid}/{name}",wid,name,cache[(i,name)],OUTTOK[name],
                   build_tail(planner,cache,i,name))
    root=make("root")
    (cr,)=await coord.submit_many([root])
    await run_req(root,cr,planner,client,msgs(epoch,wid,"root"),nodes)

    ready=[make("c1"),make("s1"),make("s2")]
    choices=await coord.submit_many(ready)
    byq={q.node:(q,ch) for q,ch in zip(ready,choices)}
    tasks={n:asyncio.create_task(run_req(*byq[n],planner,client,msgs(epoch,wid,n),nodes))
           for n in ("c1","s1","s2")}
    try:
        await tasks["c1"]
        q2=make("c2");(c2,)=await coord.submit_many([q2])
        await run_req(q2,c2,planner,client,msgs(epoch,wid,"c2"),nodes)
        q3=make("c3");(c3,)=await coord.submit_many([q3])
        await run_req(q3,c3,planner,client,msgs(epoch,wid,"c3"),nodes)
        await asyncio.gather(tasks["s1"],tasks["s2"])
        qj=make("join");(cj,)=await coord.submit_many([qj])
        await run_req(qj,cj,planner,client,msgs(epoch,wid,"join"),nodes)
    except Exception:
        for t in tasks.values():
            if not t.done():t.cancel()
        await asyncio.gather(*tasks.values(),return_exceptions=True);raise
    wfs.append({"workflow_id":wid,"jct_ms":(time.perf_counter_ns()-start)/1e6})

async def condition(rate,block,n,budget,attempt,suite,runtime,cal,probe=False):
    tag="R7B" if probe else "R6H"
    case=f"{tag}/L{rate:g}/N{n}/B{block}/T{budget}/A{attempt}"
    epoch=f"{tag}-{rate:g}-{n}-{block}-{budget}-A{attempt}"
    atomic(runtime/"control.json",{"case":case,"token_budget":budget})
    out=suite/f"L{rate:g}_N{n}_B{block}_T{budget}_A{attempt}";out.mkdir()
    nodes=[];wfs=[]
    limits=httpx.Limits(max_connections=384,max_keepalive_connections=96,keepalive_expiry=1.0)
    async with httpx.AsyncClient(timeout=httpx.Timeout(240,connect=5),limits=limits) as client:
        keys=[];reqs=[]
        for i in range(n):
            wid=f"wf{i:03d}"
            for name in OUTTOK:
                keys.append((i,name));reqs.append(tokenize(client,msgs(epoch,wid,name)))
        vals=await asyncio.gather(*reqs);cache=dict(zip(keys,vals))
        planner=GlobalDAGPlanner(cal["prefill_ms_per_token"],cal["decode_ms_per_token"],
                                 cal["slowdown_raw_ms"],lambda r:status(runtime,r))
        coord=CentralCoordinator(planner,epoch_s=.010);await coord.start()
        tasks=[asyncio.create_task(workflow(i,arrival_offsets(rate,block,n,probe)[i],
                                            epoch,planner,coord,cache,client,nodes,wfs))
               for i in range(n)]
        t0=time.perf_counter_ns()
        try:await asyncio.gather(*tasks)
        except Exception:
            for t in tasks:
                if not t.done():t.cancel()
            await asyncio.gather(*tasks,return_exceptions=True)
            await coord.close();raise
        await coord.close();t1=time.perf_counter_ns()
    if len(wfs)!=n or len(nodes)!=n*7:
        raise RuntimeError(f"incomplete condition workflows={len(wfs)}/{n} nodes={len(nodes)}/{n*7}")
    with (out/"nodes.jsonl").open("w") as f:
        for x in nodes:f.write(json.dumps(x,separators=(",",":"))+"\n")
    with (out/"workflows.jsonl").open("w") as f:
        for x in wfs:f.write(json.dumps(x,separators=(",",":"))+"\n")
    (out/"decisions.json").write_text(json.dumps(planner.decisions,indent=2)+"\n")
    (out/"plan_events.json").write_text(json.dumps(planner.plan_events,indent=2)+"\n")
    j=[x["jct_ms"] for x in wfs];ot=sum(int(x["output_tokens"] or 0) for x in nodes);dur=(t1-t0)/1e9
    reps=Counter(x["replica"] for x in nodes);events=planner.plan_events
    s={"arrival_rate":rate,"workflows":n,"block":block,"budget":budget,"attempt":attempt,
       "method":"Global-DAG","mean_jct_ms":st.mean(j),"p95_jct_ms":pct(j,.95),
       "duration_s":dur,"output_tokens":ot,"output_tokens_s":ot/dur,
       "replica_assignments":{str(r):reps.get(r,0) for r in range(4)},
       "assignment_imbalance":max(reps.get(r,0) for r in range(4))-min(reps.get(r,0) for r in range(4)),
       "mean_planner_wall_ms":st.mean(x["planner_wall_ms"] for x in events),
       "p95_planner_wall_ms":pct([x["planner_wall_ms"] for x in events],.95),
       "mean_predicted_gain_pct":st.mean(x["predicted_gain_pct"] for x in events),
       "mean_frontier_size":st.mean(x["frontier_size"] for x in events),
       "p95_frontier_size":pct([x["frontier_size"] for x in events],.95),
       "multi_workflow_events":sum(x["workflow_groups"]>1 for x in events),
       "mean_workflow_groups":st.mean(x["workflow_groups"] for x in events)}
    (out/"summary.json").write_text(json.dumps(s,indent=2)+"\n");return s

async def atomic_condition(rate,block,n,budget,suite,runtime,cal,probe=False):
    invalid=[]
    for attempt in range(1,4):
        if not all(await endpoints_healthy()):
            await wait_idle(runtime);await asyncio.sleep(.75);continue
        try:return await condition(rate,block,n,budget,attempt,suite,runtime,cal,probe)
        except Exception as e:
            rec={"attempt":attempt,"error":f"{type(e).__name__}:{e}"}
            invalid.append(rec)
            (suite/f"INVALID_L{rate:g}_N{n}_B{block}_T{budget}_A{attempt}.json").write_text(json.dumps(rec,indent=2)+"\n")
            await wait_idle(runtime);await asyncio.sleep(.75)
    raise RuntimeError(f"condition failed rate={rate} block={block} n={n} budget={budget}: {invalid}")

def frozen_baselines():
    out={}
    for name,ptr in [("R6D","r6d_confirm_latest.txt"),
                     ("Preble","r6e_preble_latest.txt"),
                     ("R6F","r6f_joint_latest.txt"),
                     ("R6G","r6g_dag_plan_latest.txt")]:
        p=ROOT/"metadata/spra_v2"/ptr
        if p.exists():
            d=Path(p.read_text().strip())/"aggregate.json"
            if d.exists():out[name]=json.loads(d.read_text())
    return out

async def main_run(args):
    runtime=args.runtime.resolve();validate(runtime)
    import fcntl
    lf=(runtime/"experiment.lock").open("a")
    try:fcntl.flock(lf,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit("runtime lock busy")
    old=json.loads((runtime/"control.json").read_text())
    stamp=time.strftime("%Y%m%dT%H%M%SZ",time.gmtime())
    suite=ROOT/"runs/spra_v2"/f"R6H_GLOBAL_DAG_{stamp}_{os.getpid()}";suite.mkdir(parents=True)
    try:
        await wait_idle(runtime)
        async with httpx.AsyncClient(timeout=httpx.Timeout(240,connect=5),
                                     limits=httpx.Limits(max_connections=128,max_keepalive_connections=32)) as c:
            cal=await calibrate_all(c,runtime)
        (suite/"calibration.json").write_text(json.dumps(cal,indent=2)+"\n")
        rows=[]
        for rate in RATES:
            for block in BLOCKS:
                print(f"CASE_START rate={rate:g} block={block} method=Global-DAG budget=2048",flush=True)
                x=await atomic_condition(rate,block,DEFAULT_N,2048,suite,runtime,cal,False);rows.append(x)
                print("CASE_DONE "+json.dumps(x,sort_keys=True),flush=True)
                atomic(runtime/"control.json",{"case":"R6H/idle-fixed","token_budget":2048});await asyncio.sleep(.4)
    finally:
        atomic(runtime/"control.json",old);fcntl.flock(lf,fcntl.LOCK_UN);lf.close()

    base=frozen_baselines();agg={}
    for rate in RATES:
        xs=[x for x in rows if x["arrival_rate"]==rate];mj=st.mean(x["mean_jct_ms"] for x in xs);k=str(rate)
        v={"repeats":4,"mean_jct_ms":mj,"mean_p95_jct_ms":st.mean(x["p95_jct_ms"] for x in xs),
           "mean_output_tokens_s":st.mean(x["output_tokens_s"] for x in xs),
           "mean_planner_wall_ms":st.mean(x["mean_planner_wall_ms"] for x in xs),
           "mean_predicted_gain_pct":st.mean(x["mean_predicted_gain_pct"] for x in xs),
           "mean_frontier_size":st.mean(x["mean_frontier_size"] for x in xs),
           "mean_multi_workflow_events":st.mean(x["multi_workflow_events"] for x in xs)}
        if "R6D" in base and k in base["R6D"]:
            for m,b in base["R6D"][k].items():v[f"gain_vs_{m}_pct"]=100*(b["mean_jct_ms"]-mj)/b["mean_jct_ms"]
        if "Preble" in base and k in base["Preble"]:
            b=base["Preble"][k]["Preble"]["mean_jct_ms"];v["gain_vs_Preble_pct"]=100*(b-mj)/b
        if "R6F" in base and k in base["R6F"]:
            b=base["R6F"][k]["DAG-Joint"]["mean_jct_ms"];v["gain_vs_R6F_pct"]=100*(b-mj)/b
        if "R6G" in base and k in base["R6G"]:
            b=base["R6G"][k]["DAG-Plan"]["mean_jct_ms"];v["gain_vs_R6G_pct"]=100*(b-mj)/b
        agg[k]={"Global-DAG":v}
    (suite/"aggregate.json").write_text(json.dumps(agg,indent=2)+"\n")
    (ROOT/"metadata/spra_v2/r6h_global_dag_latest.txt").write_text(str(suite)+"\n")
    print("RESULT="+str(suite));print("MEASURED_RUNS=8/8");print("AGGREGATE="+json.dumps(agg,sort_keys=True))

async def budget_probe(args):
    runtime=args.runtime.resolve();validate(runtime)
    import fcntl
    lf=(runtime/"experiment.lock").open("a")
    try:fcntl.flock(lf,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit("runtime lock busy")
    old=json.loads((runtime/"control.json").read_text())
    stamp=time.strftime("%Y%m%dT%H%M%SZ",time.gmtime())
    suite=ROOT/"runs/spra_v2"/f"R7B_BUDGET_MATRIX_{stamp}_{os.getpid()}";suite.mkdir(parents=True)
    p=ROOT/"metadata/spra_v2/r6h_global_dag_latest.txt";cal=None
    if p.exists():
        cp=Path(p.read_text().strip())/"calibration.json"
        if cp.exists():cal=json.loads(cp.read_text())
    if cal is None:
        async with httpx.AsyncClient(timeout=httpx.Timeout(240,connect=5)) as c:cal=await calibrate_all(c,runtime)
    rows=[]
    try:
        for rate in RATES:
            for n in (16,32):
                block=1
                for budget in (1024,2048,4096):
                    print(f"CASE_START rate={rate:g} N={n} budget={budget}",flush=True)
                    x=await atomic_condition(rate,block,n,budget,suite,runtime,cal,True);rows.append(x)
                    print("CASE_DONE "+json.dumps(x,sort_keys=True),flush=True)
                    atomic(runtime/"control.json",{"case":"R7B/idle","token_budget":2048});await asyncio.sleep(.4)
    finally:
        atomic(runtime/"control.json",old);fcntl.flock(lf,fcntl.LOCK_UN);lf.close()

    matrix={};meaningful=[]
    for rate in RATES:
        for n in (16,32):
            cell=[x for x in rows if x["arrival_rate"]==rate and x["workflows"]==n]
            vals={x["budget"]:x for x in cell}
            order=sorted((x["mean_jct_ms"],x["budget"]) for x in cell)
            best_j,best_b=order[0];second_j,_=order[1]
            margin=100*(second_j-best_j)/second_j
            key=f"L{rate:g}_N{n}"
            matrix[key]={"best_budget":best_b,"best_vs_second_pct":margin,
                         "budgets":{str(b):{"mean_jct_ms":vals[b]["mean_jct_ms"],
                                            "p95_jct_ms":vals[b]["p95_jct_ms"],
                                            "output_tokens_s":vals[b]["output_tokens_s"]} for b in sorted(vals)}}
            if margin>=3.0:meaningful.append((key,best_b,margin))
    winners={x[1] for x in meaningful}
    result={"matrix":matrix,"meaningful_cells_ge_3pct":meaningful,
            "meaningful_crossover":len(winners)>=2,
            "rule":"One-run compatibility probe only. If meaningful_crossover=true, confirm each implicated cell before building an adaptive controller. Otherwise keep R5 batching and R6H scheduling as separately validated mechanisms."}
    (suite/"budget_compat.json").write_text(json.dumps(result,indent=2)+"\n")
    (ROOT/"metadata/spra_v2/r7b_budget_matrix_latest.txt").write_text(str(suite)+"\n")
    print("RESULT="+str(suite));print("MEASURED_RUNS=12/12");print("BUDGET_COMPAT="+json.dumps(result,sort_keys=True))

def selftest():
    assert sum(OUTTOK.values())==576 and len(SUCC["root"])==3
    print("SELFTEST_OK r6h global_frontier=True epoch_ms=10 per_replica_calibration=True r6h_runs=8 r7b_runs=12 gpu_requests=0")

def plan():
    print("R6H=Global-DAG final scheduler fidelity round")
    print("GLOBAL_FRONTIER=all ready/unassigned nodes across workflows every 10ms, matching simulator recheck=0.01")
    print("GROUP_SEARCH=workflow groups; full 4^width enumeration per group against complete frontier")
    print("SERVICE_MODEL=per-replica prefill/decode calibration + per-replica concurrency curves")
    print("ROLLOUT=processor-sharing approximation of continuous batching")
    print("BATCHING=FIXED 2048 in R6H")
    print("R6H_RUNS=8 exact R6D seeds")
    print("STOP_RULE=freeze scheduler after R6H; no further scheduler tuning")
    print("R7B_AFTER_FREEZE=rates 8/12 x N 16/32 x budgets 1024/2048/4096 = 12 exploratory cells")
    print("JOINT_RULE=only pursue joint adaptive batching after a >=3% fixed-budget crossover is confirmed on this workload")

def report(kind):
    ptr=ROOT/"metadata/spra_v2"/("r6h_global_dag_latest.txt" if kind=="scheduler" else "r7b_budget_matrix_latest.txt")
    d=Path(ptr.read_text().strip());fn="aggregate.json" if kind=="scheduler" else "budget_compat.json"
    print("RESULT="+str(d));print((d/fn).read_text())

def main():
    p=argparse.ArgumentParser();sp=p.add_subparsers(dest="cmd",required=True)
    sp.add_parser("selftest");sp.add_parser("plan")
    q=sp.add_parser("run");q.add_argument("--runtime",type=Path,default=RUNTIME)
    q=sp.add_parser("budget-probe");q.add_argument("--runtime",type=Path,default=RUNTIME)
    q=sp.add_parser("report");q.add_argument("--kind",choices=("scheduler","budget"),required=True)
    a=p.parse_args()
    if a.cmd=="selftest":selftest()
    elif a.cmd=="plan":plan()
    elif a.cmd=="run":asyncio.run(main_run(a))
    elif a.cmd=="budget-probe":asyncio.run(budget_probe(a))
    else:report(a.kind)
if __name__=="__main__":main()
