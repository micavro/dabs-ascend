from __future__ import annotations
import json
import os
import time
import uuid
from pathlib import Path
from .dependency import sha

def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def atomic(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with tmp.open('x', encoding='utf-8') as f:
            json.dump(obj, f, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
            f.write('\n'); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, p)
    finally:
        if tmp.exists(): tmp.unlink()

def stamp(prefix):
    return prefix + '_' + time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()) + '_' + uuid.uuid4().hex[:8]

def files(path):
    path = Path(path)
    if not path.is_dir(): raise FileNotFoundError(path)
    result = {}
    for p in sorted(path.rglob('*')):
        if p.is_symlink(): raise ValueError('symlink not allowed in evidence: ' + str(p))
        if p.is_file(): result[str(p.relative_to(path))] = sha(p)
    return result

def verify_files(path, expected, exact=False):
    for rel, digest in expected.items():
        p = (Path(path) / rel).resolve()
        if not p.is_relative_to(Path(path).resolve()): raise ValueError('unsafe evidence path')
        if not p.is_file() or sha(p) != digest: raise ValueError('evidence changed: ' + str(p))
    if exact and files(path) != expected: raise ValueError('raw file set changed: ' + str(path))

def compact(summary):
    omit = {'workflow_rows', 'unfinished_workflow_curve', 'request_latency_rows', 'quality_rows', 'typed_response_rows'}
    return {k: v for k, v in summary.items() if k not in omit}
