"""Read-only loading of the exact original D0/Mixed1024 implementation."""
from __future__ import annotations
import hashlib
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BATCH = Path(os.environ.get('D0_BATCH_SOURCE', ROOT.parent / 'spra_musique_d0_batching_v1')).resolve()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def activate():
    sys.dont_write_bytecode = True
    expected = json.loads((ROOT / 'dependency_identity.json').read_text())
    bad = {}
    for rel, wanted in expected.items():
        p = BATCH / rel
        actual = sha(p) if p.is_file() else None
        if actual != wanted:
            bad[rel] = {'expected': wanted, 'actual': actual}
    if bad:
        raise RuntimeError('Frozen D0/batching source mismatch; no files changed: ' + json.dumps(bad))
    if str(BATCH) not in sys.path:
        sys.path.insert(0, str(BATCH))
    from batching20.dependency import activate as original_activate
    return original_activate()

def own_identity():
    paths = [ROOT / 'dependency_identity.json']
    for d in ('resume22', 'tools'):
        paths += sorted((ROOT / d).rglob('*.py'))
    paths += sorted(ROOT.glob('run_*.sh'))
    return {str(p.relative_to(ROOT)): sha(p) for p in paths if p.is_file()}
