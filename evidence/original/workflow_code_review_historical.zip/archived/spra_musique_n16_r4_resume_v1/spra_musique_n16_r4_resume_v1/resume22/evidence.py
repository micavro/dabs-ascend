"""Recover saved evidence without changing any historical performance value."""
from __future__ import annotations
import copy
import json
import math
import re
import statistics
from collections import Counter
from pathlib import Path
from . import REVISION, CHECKER_REVISION
from .common import atomic, load, files, verify_files, compact
from .dependency import activate, sha, ROOT
from .audit import condition_verdict, jsonl
from .protocol import validate_saved_input, external_hash, role
activate()
from batching20 import telemetry
from typed19.quality import evaluate as evaluate_quality
from typed19.workflow import SYSTEM, task_text
from joint18v2.common import token_hash


def cached_verdict(source, candidates):
    """Use a matching, hash-covered prior receipt, never a console success flag."""
    source = Path(source).resolve()
    checker_hash = sha(ROOT / 'resume22/batchcheck.py')
    for path in candidates:
        path = Path(path)
        try:
            doc = load(path); manifest = load(path.parent / 'manifest.json')
            if manifest.get('checker_revision') != CHECKER_REVISION: continue
            if manifest.get('files', {}).get(path.name) != sha(path): continue
            if manifest.get('adapter_identity', {}).get('joint21/batchcheck.py') != checker_hash: continue
            if Path(doc.get('old_suite', '')).resolve() != source.parent: continue
            for verdict in doc.get('conditions', []):
                if Path(verdict.get('folder', '')).resolve() != source: continue
                if not verdict.get('accepted') or not verdict.get('source_files_unchanged'): continue
                required = {'nodes.json','backend.jsonl','summary.json','manifest.json','trace_capture.json'}
                if not required.issubset(verdict.get('source_hashes', {})): continue
                verify_files(source, verdict['source_hashes'])
                return copy.deepcopy(verdict), {'kind': 'existing_hash_verified_receipt',
                    'path': str(path.resolve()), 'sha256': sha(path), 'checker_sha256': checker_hash}
        except (OSError, ValueError, KeyError, TypeError):
            continue
    return None, None


def validate_record(raw, cell, cfg, records, model, cached=None):
    raw = Path(raw)
    ident = validate_saved_input(raw, cell, cfg, records, model)
    verdict = copy.deepcopy(cached) if cached is not None else condition_verdict(raw)
    if cached is not None: verify_files(raw, verdict['source_hashes'])
    if not verdict.get('accepted'):
        return {'accepted': False, 'batch': verdict, 'input_identity': ident}
    # These files are needed for independent timing and cap-only verification.
    for f in ('controls.json','plans.jsonl','status.json'):
        if not (raw / f).is_file(): raise ValueError('missing complete execution evidence: ' + f)
    if load(raw / 'status.json').get('execution') != 'complete':
        raise ValueError('saved request execution is not complete')
    nodes = load(raw / 'nodes.json'); summary = load(raw / 'summary.json')
    if summary.get('workflows') != 16 or summary.get('requests') != len(nodes):
        raise ValueError('condition workload counts differ')
    outtokens = sum(n['stream']['usage']['completion_tokens'] for n in nodes.values())
    if outtokens != summary['output_tokens']: raise ValueError('usage/output count mismatch')
    workflows = {}
    for n in nodes.values(): workflows.setdefault(n['wid'], []).append(n)
    actual_jcts = []
    for group in workflows.values():
        arrival = group[0]['arrival']
        if any(n['arrival'] != arrival for n in group): raise ValueError('workflow arrival mismatch')
        actual_jcts.append(1000 * (max(n['finish'] for n in group) - arrival))
    if not math.isclose(statistics.mean(actual_jcts), summary['mean_jct_ms'], abs_tol=1e-5, rel_tol=1e-8):
        raise ValueError('raw node completion JCT differs from summary; never repair by retiming')
    controls = {p['plan_id']: p for p in load(raw / 'controls.json')}
    accepts = {}; iterations = []
    for event in jsonl(raw / 'backend.jsonl'):
        if event.get('event') == 'accept': accepts.setdefault(event['prompt_hash'], []).append(event)
        if event.get('event') == 'iteration' and event.get('scheduled'): iterations.append(event)
    for n in nodes.values():
        group = accepts.get(n['hash'], [])
        if len(group) != 1 or group[0]['replica'] != n['replica']:
            raise ValueError('saved request/native identity differs')
    for e in iterations:
        if e['total'] != 4096: raise ValueError('native total changed')
        if cell['policy'] == 'fixed_4096' and e.get('prefill_cap') != 4096:
            raise ValueError('fixed cap was not fixed4096')
        if e.get('plan_reason') == 'lease_ok':
            p = controls.get(e['plan_id'])
            if p is None: raise ValueError('native plan has no saved control')
            at = e.get('effective_ns', e['begin_ns'])
            active = p['not_before_ns'] <= at < p['action_expires_ns']
            cap = p['caps'][e['replica']] if active else cfg['base_cap']
            total = p['totals'][e['replica']] if active else cfg['hard_total']
            if (e['execution_phase'] == 'current_action') != active or e['prefill_cap'] != cap or e['total'] != total:
                raise ValueError('saved control effective/expiration mismatch')
    return {'accepted': True, 'batch': verdict, 'input_identity': ident,
            'JCT_recomputed_only_as_consistency_check': True, 'original_JCT_changed': False,
            'request_correlation_verified': True, 'control_time_verified': True}


async def canonical_input_check(unit, cell, packets, cfg, tokenizer):
    """Part of normal input preparation: only /tokenize and /detokenize, no generation.

The failed legacy A never wrote semantic_proof.json. Validate every saved initial
request against the same frozen native template/documents, with its OLD nonce.
This reconstructs external identity without inventing a missing old proof file.
"""
    unit = Path(unit); raw = unit / 'raw'; m = load(raw / 'manifest.json')
    ns = m['input_nodes']; first = ns[sorted(ns)[0]]
    proof_path = raw / 'semantic_proof.json'
    proof = load(proof_path) if proof_path.is_file() else {}
    nonce = proof.get('condition_namespace')
    if nonce is None:
        text = await tokenizer.decode(first['tokens'])
        match = re.search(r'Run ([0-9a-f]{32})\.\n', text)
        if match is None: raise ValueError('cannot recover saved namespace from native token readback')
        nonce = match.group(1)
    if not re.fullmatch('[0-9a-f]{32}', nonce): raise ValueError('malformed saved nonce')
    system = 'Run ' + nonce + '.\n' + SYSTEM
    ps = packets[slice(*cell['packet_slice'])]; checked = 0
    for wi, p in enumerate(ps):
        common = p['evidence_text'] + '\nCurrent task (data):\n'
        for step in p['steps']:
            k = f'w{wi:04d}/step{step["position"]+1}'; n = ns[k]
            canonical = await tokenizer.chat_tokens(system, common + task_text(step['question'], {}))
            if canonical != n['tokens'] or token_hash(canonical) != n['hash']:
                raise ValueError('saved static prompt differs from frozen application input: ' + k)
            if token_hash(canonical[:n['share']]) != n['prefix_hash']:
                raise ValueError('saved certified prefix differs')
            checked += 1
    external = external_hash(cell, packets, cfg)
    if proof:
        if proof['ids'] != [p['id'] for p in ps] or proof['static_packet_hashes'] != [p['evidence_hash'] for p in ps]:
            raise ValueError('saved semantic proof changed')
    s = load(raw / 'summary.json')
    if s.get('external_work_sha256') is not None and s['external_work_sha256'] != external:
        raise ValueError('old external-work hash differs from canonical preparation')
    tokenizer.first_blocks.add(tuple(first['tokens'][:cfg['block_size']]))
    result = {'pass': True, 'requests_checked': checked, 'external_work_sha256': external,
              'kind': 'native_tokenizer_reconstruction_of_saved_static_inputs',
              'generation_requests': 0, 'old_namespace_reused_for_token_check_only': True,
              'missing_legacy_semantic_proof_not_fabricated': not bool(proof),
              'question_ids': [p['id'] for p in ps]}
    atomic(unit / 'canonical_input_check.json', result)
    return result


def telemetry_readonly(raw, target, policy, scheduler):
    """Run original telemetry logic, redirect only its post-run JSON output."""
    target = Path(target); target.mkdir(parents=True, exist_ok=True)
    original = telemetry.atomic
    def save(path, obj):
        if Path(path).name != 'batching_evidence.json': raise ValueError('unexpected telemetry output')
        atomic(target / 'batching_evidence.json', obj)
    telemetry.atomic = save
    try: return telemetry.inspect_condition(raw, policy, scheduler)
    finally: telemetry.atomic = original


def verify_acceptance(unit):
    unit = Path(unit); a = load(unit / 'accepted.json')
    if not a.get('measurement_accepted'): raise ValueError('not an accepted condition')
    verify_files(unit / 'raw', a['raw_hashes'], exact=True)
    verify_files(unit, a['derived_hashes'])
    row = load(unit / 'row.json')
    if row['label'] != a['label']: raise ValueError('receipt label mismatch')
    return row


def finalize(unit, cell, dataset, offline):
    unit = Path(unit)
    if (unit / 'accepted.json').is_file(): return verify_acceptance(unit)
    if not offline.get('accepted'): raise ValueError('unresolved offline execution check')
    check = load(unit / 'canonical_input_check.json')
    if not check.get('pass'): raise ValueError('input identity not validated')
    raw = unit / 'raw'; before = files(raw)
    summary = load(raw / 'summary.json'); nodes = load(raw / 'nodes.json')
    post = unit / 'derived'; post.mkdir(exist_ok=True)
    stats = telemetry_readonly(raw, post, cell['policy'], cell['scheduler'])
    q = evaluate_quality(nodes, dataset, summary['cohort_duration_s'])
    atomic(post / 'quality.json', q)
    # Only supplement summary in a NEW file. Historical numbers/flags remain intact.
    summary.update(q); summary.update(stats)
    fallback = Counter()
    for p in jsonl(raw / 'plans.jsonl'):
        v = p.get('commit_fallback')
        if v:
            reason = v.get('reason', str(v)) if isinstance(v, dict) else str(v)
            fallback[reason] += 1
    summary.update(measurement_accepted=True, independent_batch_checked=offline['batch']['iterations'],
                   independent_batch_matched=offline['batch']['matches'],
                   independent_batch_check_revision=CHECKER_REVISION,
                   commit_fallback_reason_counts=dict(fallback),
                   no_performance_cost_subtracted=True)
    atomic(post / 'summary.json', summary)
    origin = load(unit / 'origin.json')
    row = {**cell, 'role': role(cell), 'accepted': True, 'unit': str(unit.resolve()),
           'folder': str(raw.resolve()), 'external_work_sha256': check['external_work_sha256'],
           'question_ids': check['question_ids'], 'summary': compact(summary),
           'source_kind': origin['kind'], 'segment': origin.get('segment', 'legacy'),
           'original_source': origin.get('source')}
    atomic(unit / 'row.json', row)
    if before != files(raw): raise ValueError('raw evidence changed during postprocessing')
    derived = {str(p.relative_to(unit)): sha(p) for p in sorted(unit.rglob('*'))
               if p.is_file() and not p.is_relative_to(raw) and p.name != 'accepted.json'}
    atomic(unit / 'accepted.json', {'measurement_accepted': True, 'label': cell['label'],
        'revision': REVISION, 'checker_revision': CHECKER_REVISION,
        'raw_hashes': before, 'derived_hashes': derived,
        'acceptance_uses_JCT_gain_or_quality': False, 'source_files_unchanged': True})
    return row
