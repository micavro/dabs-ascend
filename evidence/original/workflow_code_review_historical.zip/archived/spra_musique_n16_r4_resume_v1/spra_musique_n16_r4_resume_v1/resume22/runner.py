"""Resume ONLY the twelve frozen N16/4s conditions. Never reseed or reselect."""
from __future__ import annotations
import argparse
import asyncio
import contextlib
import copy
import fcntl
import json
import multiprocessing
import os
import shutil
import sys
import zipfile
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from . import REVISION, CHECKER_REVISION
from .dependency import ROOT, BATCH, activate, own_identity, sha
activate()
from .common import atomic, load, files, verify_files, stamp
from .protocol import target_design, cell_config, role, expected_identity, external_hash
from .evidence import cached_verdict, validate_record, canonical_input_check, finalize, verify_acceptance
from .batchcheck import compare_iteration
from . import report
from batching20 import experiment as old
from batching20.binding import bindings as original_bindings
from batching20.dependency import verify, own_identity as batch_identity
from joint18v2 import client as live_client
from joint18v2.common import digest
from typed19.workflow import ServerTokenizer, compile_packets, instantiate
from semantic19.dataset import load_public

DEFAULT_PRIOR = BATCH / 'runs/D0_BATCH_CONFIRM_20261010T123919Z_df416da6'
DEFAULT_RUNTIME = Path('/home/wmy/sci/spra_core_exp/joint_e1')

@contextlib.contextmanager
def bindings():
    # The process-plan callable is the EXACT old batching20.policy.process_plan.
    # Only the POST-execution independent checker changes in this local process.
    with original_bindings():
        saved = live_client.compare_iteration
        live_client.compare_iteration = compare_iteration
        try: yield
        finally: live_client.compare_iteration = saved


def source_state(prior):
    prior = Path(prior).resolve()
    frozen, mf, model, priors = old.load_frozen()
    development, selection = old.read_selection(frozen)
    fp = load(prior / 'frozen_protocol.json')
    if fp.get('frozen_manifest_sha256') != sha(frozen / 'manifest.json'):
        raise ValueError('old suite belongs to a different D0 freeze')
    if fp.get('code_hashes') != {**verify(), **batch_identity()}:
        raise ValueError('old suite code identities differ')
    if fp.get('config') != mf['D0_configuration'] or load(prior / 'selection.json') != selection:
        raise ValueError('old suite configuration/selection differ from original freeze')
    clean = load(prior / 'cleanup.json')
    if clean.get('backend_drained') is not True or clean.get('source_files_unchanged') is not True:
        raise ValueError('old suite has no successful drain/source cleanup evidence')
    design = target_design(fp, mf['protocol'], selection)
    records, dm = load_public(Path(mf['dataset']), 'pilot')
    if [r['id'] for r in records] != mf['validation_ids']:
        raise ValueError('old question ordering changed')
    return frozen, mf, model, priors, development, selection, fp, design, records, dm


def receipt_paths():
    base = ROOT.parent / 'spra_musique_joint_focus_v1' / 'prepared'
    return sorted(base.glob('*/prior_revalidation.json')) if base.is_dir() else []


def saved_units(out):
    return sorted([p for base in ('imported','attempts') for p in (Path(out) / base).glob('*') if p.is_dir() and (p / 'cell.json').is_file()])


def verify_unit_origin(unit):
    origin = load(unit / 'origin.json')
    if origin.get('kind') == 'legacy_reused':
        verify_files(Path(origin['source']), origin['raw_hashes'], exact=True)
        verify_files(unit / 'raw', origin['raw_hashes'], exact=True)


def prepare(prior=DEFAULT_PRIOR):
    prior = Path(prior).resolve()
    frozen, mf, model, priors, dev, selection, fp, design, records, dm = source_state(prior)
    ptr = ROOT / 'records/latest.json'
    if ptr.is_file():
        out = Path(load(ptr)['directory'])
        check_frozen(out)
        if Path(load(out/'protocol.json')['prior_suite']) != prior: raise ValueError('existing recovery targets a different suite')
        print('N16_R4_RECOVERY_REUSED=' + str(out), flush=True)
        return out
    out = ROOT / 'runs' / stamp('N16_R4_RESUME'); out.mkdir(parents=True)
    print('RESULT=' + str(out), flush=True)
    source_headers = {n: sha(prior / n) for n in ('frozen_protocol.json','selection.json','index.json','cleanup.json','environment.json','suite_status.json')}
    indexed = load(prior / 'index.json'); index_by = {r['label']: r for r in indexed}
    if len(index_by) != len(indexed): raise ValueError('duplicate old index rows')
    (out / 'frozen').mkdir()
    for name in ('model.json','priors.json'):
        (out / 'frozen' / name).write_bytes((frozen / name).read_bytes())
    atomic(out / 'frozen/original_D0_manifest.json', mf)
    atomic(out / 'frozen/original_suite_protocol.json', fp)
    atomic(out / 'frozen/selection.json', selection)
    atomic(out / 'frozen/dataset_manifest.json', dm)
    for name in source_headers:
        (out/'frozen'/('prior_'+name)).write_bytes((prior/name).read_bytes())
    excluded = []
    for c in fp['design']:
        if float(c['rate']) == 4.: continue
        p = prior / c['label']
        state = 'accepted_in_original_index' if c['label'] in index_by else 'saved_not_accepted' if p.exists() else 'not_executed'
        excluded.append({'label': c['label'], 'rate': c['rate'], 'block': c['block'], 'state': state})
    protocol = {'revision': REVISION, 'checker_revision': CHECKER_REVISION,
        'prior_suite': str(prior), 'prior_header_hashes': source_headers,
        'saved_target_source_hashes': {c['label']: files(prior/c['label']) for c in design if (prior/c['label']).is_dir()},
        'original_frozen': str(frozen.resolve()), 'original_frozen_sha256': sha(frozen/'manifest.json'),
        'development_selection_path': str((dev/'selection.json').resolve()), 'development_selection_sha256': sha(dev/'selection.json'),
        'source_hashes': verify(), 'batch_source_hashes': batch_identity(), 'adapter_hashes': own_identity(),
        'config': mf['D0_configuration'], 'dataset': mf['dataset'], 'dataset_files': mf['dataset_files'],
        'dataset_manifest_sha256': mf['dataset_manifest_sha256'], 'design': design,
        'selection': selection, 'excluded_conditions': excluded,
        'global_order_change': 'resume only 4/s, preserving original order within each block; 2/s and8/s remain pending',
        'fresh_unseen_holdout': False, 'N64_results_not_pooled': True,
        'no_new_strategy_guard_or_threshold': True}
    protocol['frozen_files'] = files(out / 'frozen')
    atomic(out / 'protocol.json', protocol)
    atomic(out / 'protocol_receipt.json', {'sha256':sha(out/'protocol.json')})
    atomic(out / 'index.json', [])
    atomic(out / 'suite_status.json', {'status': 'preparing', 'expected_conditions': 12})
    atomic(ptr, {'directory': str(out.resolve())})
    imported = []; candidates = receipt_paths()
    try:
        # Reuse all saved target cells uniformly. The failed A is NOT a special pass.
        for c in design:
            source = prior / c['label']
            if not source.exists(): continue
            if not source.is_dir(): raise ValueError('saved condition path is not a directory')
            unit = out / 'imported' / c['label']; unit.mkdir(parents=True)
            original_hashes = files(source)
            shutil.copytree(source, unit / 'raw')
            verify_files(source, original_hashes, exact=True); verify_files(unit/'raw', original_hashes, exact=True)
            atomic(unit / 'cell.json', c)
            atomic(unit / 'origin.json', {'kind':'legacy_reused','segment':'legacy', 'source':str(source.resolve()), 'raw_hashes':original_hashes,
                  'was_in_original_index':c['label'] in index_by})
            receipt, how = cached_verdict(source, candidates)
            cfg = cell_config(protocol['config'], priors, c)
            offline = validate_record(unit / 'raw', c, cfg, records, model, receipt)
            offline['readback_source'] = how or {'kind':'corrected_checker_on_existing_records', 'GPU_REQUESTS':0}
            atomic(unit / 'offline_validation.json', offline)
            if not offline['accepted']: raise ValueError('unresolved native evidence for '+c['label'])
            if c['label'] in index_by:
                r = index_by[c['label']]
                for k,v in c.items():
                    if r.get(k) != v: raise ValueError('indexed old cell differs from frozen design')
                if r['summary']['mean_jct_ms'] != load(source/'summary.json')['mean_jct_ms']:
                    raise ValueError('old index/summary JCT differs')
            imported.append(c['label'])
            print('SAVED_CONDITION_REVALIDATED=' + json.dumps({'label': c['label'],
                'source': offline['readback_source']['kind'], 'independent_match': offline['batch']['matches'],
                'independent_checked': offline['batch']['iterations'], 'performance_retimed':False,
                'canonical_input_reconstruction_in_normal_preparation':True}), flush=True)
        status = {'status':'prepared','expected_conditions':12,'saved_conditions_revalidated':len(imported),
                  'new_measured_conditions_pending':12-len(imported),'no_generation_requests':True}
        atomic(out/'suite_status.json',status)
        print('N16_R4_READY='+json.dumps(status),flush=True)
    except BaseException as exc:
        atomic(out/'suite_status.json',{'status':'blocked','error':repr(exc),'GPU_REQUESTS':0})
        print('RECOVERY_BLOCKED_EVIDENCE=' + str(out),flush=True)
        raise
    return out


def check_frozen(out):
    out = Path(out)
    if sha(out/'protocol.json') != load(out/'protocol_receipt.json')['sha256']:
        raise ValueError('recovery protocol changed after preparation')
    p = load(out / 'protocol.json')
    if p['adapter_hashes'] != own_identity() or p['source_hashes'] != verify() or p['batch_source_hashes'] != batch_identity():
        raise ValueError('runner/D0/Mixed/application source changed after recovery preparation')
    verify_files(Path(p['prior_suite']), p['prior_header_hashes'])
    verify_files(out/'frozen', p['frozen_files'], exact=True)
    mf = load(out/'frozen/original_D0_manifest.json')
    if sha(Path(p['original_frozen'])/'manifest.json') != p['original_frozen_sha256']:
        raise ValueError('original D0 manifest changed')
    if sha(Path(p['development_selection_path'])) != p['development_selection_sha256']:
        raise ValueError('original development selection changed')
    data = Path(p['dataset'])
    if sha(data/'manifest.json') != p['dataset_manifest_sha256']: raise ValueError('dataset identity changed')
    verify_files(data, p['dataset_files'])
    if load(out/'suite_status.json')['status'] == 'blocked':
        raise ValueError('recovery blocked on correctness; inspect saved evidence, do not relax checks or rerun baseline')
    for label, hashes in p.get('saved_target_source_hashes', {}).items():
        verify_files(Path(p['prior_suite'])/label, hashes, exact=True)
        unit = Path(out)/'imported'/label
        if not (unit/'origin.json').is_file():
            raise ValueError('preparation was interrupted before all saved cells were copied; no generation allowed: '+label)
    for unit in saved_units(out): verify_unit_origin(unit)
    return p, load(out/'frozen/model.json'), load(out/'frozen/priors.json')


def environment_check(current, original):
    # PIDs/launch IDs may differ across segments; runtime configuration/hardware may not.
    fields = ('pod','hook_source_sha256','scheduler_source_sha256','nvidia_visible_devices',
              'hard_total','block_size','num_gpu_blocks','max_num_seqs','max_model_len',
              'num_scheduler_steps','prefix_caching','chunked_prefill','native_cache_allocator')
    if len(current) != 4 or len(original) != 4: raise ValueError('expected four replicas')
    for now, prev in zip(current, original):
        for k in fields:
            if k not in now or k not in prev or now[k] != prev[k]:
                raise ValueError('runtime configuration changed across segments: ' + k)
        if now.get('hook_source_sha256') != old.HOOK: raise ValueError('unexpected hook')
    ident=lambda x:{k:x.get(k) for k in ('pod','pid','boot_id','launch_id')}
    return {'same_recorded_hardware_and_runtime_configuration':True,
            'old_engine_ids':[ident(x) for x in original],
            'new_engine_ids':[ident(x) for x in current],
            'server_process_restart_between_segments':[ident(a)!=ident(b) for a,b in zip(current,original)],
            'cache_state_not_assumed_identical':True}


def units_for(out, label):
    return [u for u in saved_units(out) if load(u/'cell.json')['label'] == label]


def has_complete_raw(unit):
    raw=unit/'raw'
    if not (raw/'nodes.json').is_file(): return False
    nodes=load(raw/'nodes.json')
    return bool(nodes) and all(n.get('state')=='done' for n in nodes.values())


def index_rows(out, design):
    rows=[]
    for c in design:
        good=[verify_acceptance(u) for u in units_for(out,c['label']) if (u/'accepted.json').is_file()]
        if len(good)>1: raise ValueError('more than one accepted attempt: '+c['label'])
        if good: rows.append(good[0])
    atomic(out/'index.json', rows)
    return rows


def save_archive(out):
    pointer=out/'archive_receipt.json'
    if pointer.is_file():
        x=load(pointer)
        if sha(x['path']) != x['sha256']: raise ValueError('archive changed')
        return x
    if load(out/'suite_status.json')['status']!='complete' or not load(out/'result.json')['complete']:
        raise ValueError('no final archive before completion')
    dest=ROOT/'archives'/(out.name+'.zip');dest.parent.mkdir(parents=True,exist_ok=True)
    h={}
    with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for rel,dg in files(out).items():
            z.write(out/rel,'run/'+rel);h['run/'+rel]=dg
        for rel,dg in own_identity().items():
            z.write(ROOT/rel,'code/'+rel);h['code/'+rel]=dg
        for rel in ('README.md','docs/RESUME_CONTRACT.md','TEST_RESULTS.txt','TEST_SCOPE.json'):
            if (ROOT/rel).is_file():z.write(ROOT/rel,'code/'+rel);h['code/'+rel]=sha(ROOT/rel)
        z.writestr('ARCHIVE_SHA256SUMS',''.join(v+'  '+k+'\n' for k,v in sorted(h.items())))
        z.writestr('ARCHIVE_SCOPE.json', json.dumps({'all_target_positive_and_negative_records':True,
            'original_source_directories_not_modified':True,'not_all_original_36_conditions_complete':True,
            'not_entire_server_disk_backup':True},indent=2))
    x={'path':str(dest.resolve()),'sha256':sha(dest),'no_performance_guarantee':True}
    atomic(pointer,x);dest.with_suffix('.zip.sha256').write_text(x['sha256']+'  '+dest.name+'\n')
    return x


async def run(out, runtime, retry_incomplete=False):
    import httpx
    out=Path(out).resolve();runtime=Path(runtime).resolve()
    p,model,priors=check_frozen(out); design=p['design'];dataset=Path(p['dataset'])
    rows=index_rows(out,design)
    if len(rows)==12:
        r=report.write(out,rows,design,p['excluded_conditions'],True)
        if load(out/'suite_status.json')['status']!='complete':
            if not (out/'last_cleanup.json').is_file() or not load(out/'last_cleanup.json')['backend_drained']:
                if not runtime.is_dir(): raise FileNotFoundError('runtime missing for cleanup recovery')
                with (runtime/'experiment.lock').open('a') as lk:
                    fcntl.flock(lk,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    async with httpx.AsyncClient(timeout=30,trust_env=False) as hc:
                        initial=await old.gate(hc,runtime,4)
                        environment_check(initial,load(Path(p['prior_suite'])/'environment.json'))
                        atomic(runtime/'joint18v2/control.json',{'enabled':False})
                        drained=await old.wait_drained(runtime,initial)
                        if not drained:raise RuntimeError('cleanup recovery not drained; no new generation')
                        check_frozen(out)
                        atomic(out/'last_cleanup.json',{'backend_drained':True,'source_files_unchanged':True,
                            'cleanup_recovery_only':True,'new_generation_requests':0})
            atomic(out/'suite_status.json',{'status':'complete','accepted_conditions':12,'all_signed_gains_retained':True})
        print('N16_R4_ALREADY_COMPLETE=True NEW_GENERATION_REQUESTS=0',flush=True)
        print('N16_R4_RESULT='+json.dumps(r,ensure_ascii=False),flush=True)
        print('N16_R4_ARCHIVE='+json.dumps(save_archive(out)),flush=True)
        return
    # Do not replace completed-but-invalid records. Only explicit unfinished attempts may be retried.
    for c in design:
        uu=units_for(out,c['label'])
        if any((u/'accepted.json').is_file() for u in uu):continue
        if uu:
            u=uu[-1]
            if not has_complete_raw(u) and load(u/'origin.json')['kind']!='legacy_reused' and not retry_incomplete:
                raise ValueError('unfinished attempt retained; use --retry-incomplete explicitly: '+str(u))
    if not runtime.is_dir():raise FileNotFoundError('runtime missing; do not create fake statuses')
    with (runtime/'experiment.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        with bindings():
            async with httpx.AsyncClient(timeout=httpx.Timeout(180,connect=5,pool=10),trust_env=False,
                    limits=httpx.Limits(max_connections=192,max_keepalive_connections=64,keepalive_expiry=2)) as client:
                initial=await old.gate(client,runtime,4)
                cross=environment_check(initial,load(Path(p['prior_suite'])/'environment.json'))
                segment=out/'segments'/stamp('SEGMENT');segment.mkdir(parents=True)
                atomic(segment/'environment.json',initial);atomic(segment/'continuity.json',cross)
                atomic(out/'suite_status.json',{'status':'running','accepted_conditions':len(rows),'expected_conditions':12})
                executor=None;success=False;error=None
                try:
                    records,dm=load_public(dataset,'pilot')
                    tok=ServerTokenizer(client,p['config']['model'])
                    packets,prep=await compile_packets(records,tok,p['config'])
                    atomic(segment/'packet_preparation.json',prep)
                    # Restore saved complete records before deciding how many new conditions are needed.
                    for c in design:
                        uu=units_for(out,c['label'])
                        if any((u/'accepted.json').is_file() for u in uu): continue
                        if not uu:continue
                        unit=uu[-1]
                        if not has_complete_raw(unit):
                            if load(unit/'origin.json')['kind']=='legacy_reused':
                                raise ValueError('historical incomplete evidence cannot be silently retried')
                            continue
                        cc=cell_config(p['config'],priors,c)
                        if not (unit/'offline_validation.json').is_file():
                            offline=validate_record(unit/'raw',c,cc,records,model)
                            atomic(unit/'offline_validation.json',offline)
                        offline=load(unit/'offline_validation.json')
                        if not offline['accepted']:raise ValueError('completed record still violates native checks: '+c['label'])
                        if not (unit/'canonical_input_check.json').is_file():
                            await canonical_input_check(unit,c,packets,cc,tok)
                        row=finalize(unit,c,dataset,offline)
                        print('N16_R4_CONDITION_REUSED='+json.dumps({'label':c['label'],'role':row['role'],
                             'mean_jct_ms':row['summary']['mean_jct_ms'],'original_source':row['original_source'],
                             'new_generation_requests':0}),flush=True)
                    rows=index_rows(out,design)
                    report.write(out,rows,design,p['excluded_conditions'])
                    pending=[c for c in design if c['label'] not in {r['label'] for r in rows}]
                    print('N16_R4_RUN_PLAN='+json.dumps({'total':12,'reused':len(rows),'pending':len(pending),
                        'pending_order':[c['label'] for c in pending],'no_JLight':True,
                        'original_within_block_order_preserved':True}),flush=True)
                    if pending:
                        executor=ProcessPoolExecutor(1,mp_context=multiprocessing.get_context('spawn'))
                        await asyncio.get_running_loop().run_in_executor(executor,old.worker_ready)
                        await old.warmup(client,runtime,initial,copy.deepcopy(p['config']),segment,tok)
                        print('RESUME_WARMUP_COMPLETE=True REQUESTS=12 MEASURED=False',flush=True)
                    for c in pending:
                        check_frozen(out)
                        cc=cell_config(p['config'],priors,c);ps=packets[slice(*c['packet_slice'])]
                        nodes,mat,proof=await instantiate(ps,tok,cc,c['seed'],priors)
                        external=external_hash(c,packets,cc)
                        n=len(units_for(out,c['label']))+1
                        unit=out/'attempts'/(c['label']+'__'+out.name[-8:]+'__attempt'+f'{n:03d}')
                        unit.mkdir(parents=True)
                        atomic(unit/'cell.json',c)
                        atomic(unit/'origin.json',{'kind':'new_execution','segment':segment.name,'source':None,
                            'attempt':n,'original_condition_label':c['label'],'previous_attempts_retained':True})
                        # Save before execute, whose folder must not already exist.
                        atomic(unit/'semantic_proof_preexecute.json',proof)
                        atomic(unit/'external_work.json',{'external_work_sha256':external})
                        print('N16_R4_CONDITION_START='+json.dumps({**c,'role':role(c)}),flush=True)
                        summary,events=await old.execute(client,runtime,initial,cc,nodes,unit/'raw',c['scheduler'],model,
                            executor=executor if c['scheduler']=='D' else None,materializer=mat)
                        atomic(unit/'semantic_proof_complete.json',proof)
                        offline=validate_record(unit/'raw',c,cc,records,model)
                        atomic(unit/'offline_validation.json',offline)
                        if not offline['accepted']:raise ValueError('native correctness failed: '+c['label'])
                        atomic(unit/'canonical_input_check.json',{'pass':True,'kind':'unchanged_native_instantiator_in_this_run',
                            'generation_requests':0,'external_work_sha256':external,'question_ids':proof['ids'],
                            'arrivals':proof['arrivals'],'static_packet_hashes':proof['static_packet_hashes']})
                        row=finalize(unit,c,dataset,offline)
                        rows=index_rows(out,design);report.write(out,rows,design,p['excluded_conditions'])
                        print('N16_R4_CONDITION_ACCEPTED='+json.dumps({**c,'role':row['role'],
                            'source_kind':row['source_kind'],'segment':row['segment'],**row['summary']},ensure_ascii=False),flush=True)
                    rows=index_rows(out,design)
                    result=report.write(out,rows,design,p['excluded_conditions'],True)
                    success=True
                except BaseException as exc:
                    error=repr(exc)
                    atomic(out/'suite_status.json',{'status':'interrupted_or_failed','error':error,
                        'accepted_conditions':len(index_rows(out,design)),'automatic_retry':False})
                    atomic(segment/'failure.json',{'error':error,'no_performance_based_retry':True})
                    raise
                finally:
                    if executor:executor.shutdown(wait=True,cancel_futures=True)
                    atomic(runtime/'joint18v2/control.json',{'enabled':False})
                    try:dr=await old.wait_drained(runtime,initial)
                    except BaseException as exc:dr=False;atomic(segment/'drain_error.json',{'error':repr(exc)})
                    unchanged=True
                    try:check_frozen(out)
                    except Exception as exc:unchanged=False;atomic(segment/'identity_error.json',{'error':repr(exc)})
                    cleanup={'backend_drained':bool(dr),'source_files_unchanged':unchanged,'old_results_overwritten':False,
                             'backend_code_changed':False,'segment':segment.name,'error':error}
                    atomic(segment/'cleanup.json',cleanup);atomic(out/'last_cleanup.json',cleanup)
                    print('CLEANUP='+json.dumps(cleanup),flush=True)
                    if not dr or not unchanged:raise RuntimeError('cleanup incomplete; no final archive')
                if success:
                    atomic(out/'suite_status.json',{'status':'complete','accepted_conditions':12,'all_signed_gains_retained':True,
                          'original_36_condition_suite_not_completed':True})
                    print('N16_R4_RESULT='+json.dumps(result,ensure_ascii=False),flush=True)
    print('N16_R4_ARCHIVE='+json.dumps(save_archive(out)),flush=True)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('command',choices=['plan','prepare','run','report'])
    ap.add_argument('--prior-suite',type=Path,default=DEFAULT_PRIOR)
    ap.add_argument('--resume',type=Path)
    ap.add_argument('--runtime',type=Path,default=DEFAULT_RUNTIME)
    ap.add_argument('--retry-incomplete',action='store_true',help='explicit retry of unfinished NEW attempts only; never retry accepted/invalid completed data')
    a=ap.parse_args()
    ROOT.mkdir(parents=True,exist_ok=True)
    with (ROOT/'recovery.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if a.command=='plan':
            print(json.dumps({'target':'MuSiQue N16 / original4s wave','methods':['A-F4096','D0-F4096','D0-Mixed1024'],
              'blocks':4,'total_unique_conditions':12,'expected_new_conditions_if_B1_revalidates':9,
              'original_seeds':[200201,200202,200203,200204],'new_strategy_or_model':False,
              'single_entry':'run_resume.sh; automatic reuse, no early positive stop',
              'prior_suite':str(a.prior_suite)},indent=2));return
        out=a.resume.resolve() if a.resume else prepare(a.prior_suite)
        if a.command=='prepare':return
        if a.command=='report':
            p,_,_=check_frozen(out);rr=index_rows(out,p['design'])
            print('N16_R4_RESULT='+json.dumps(report.write(out,rr,p['design'],p['excluded_conditions'],len(rr)==12),ensure_ascii=False));return
        asyncio.run(run(out,a.runtime,a.retry_incomplete))
