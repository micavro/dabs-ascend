"""All four blocks are retained. Success is not a stopping criterion."""
from __future__ import annotations
import csv
import statistics
from pathlib import Path
from .common import atomic
from .protocol import role
from .dependency import activate
activate()
from batching20.report import compare, METRICS


def describe(values):
    if not values: return {'n': 0, 'mean': None, 'min': None, 'max': None, 'sample_sd': None}
    return {'n': len(values), 'mean': statistics.mean(values), 'min': min(values), 'max': max(values),
            'sample_sd': statistics.stdev(values) if len(values) > 1 else None}


def build(rows, design, excluded, complete=False):
    expected = {c['label']: c for c in design}; seen = {}
    for row in rows:
        if row['label'] not in expected or row['label'] in seen: raise ValueError('unknown/duplicate condition')
        if not row.get('accepted'): raise ValueError('unaccepted condition cannot enter results')
        for k, value in expected[row['label']].items():
            if row.get(k) != value: raise ValueError('report row differs from original frozen cell: ' + k)
        if row['summary']['workflows'] != 16: raise ValueError('not N16')
        seen[row['label']] = row
    if complete and len(seen) != 12: raise ValueError('no final report before all 12 cells are accepted')
    blocks = []; pairs = []
    for b in range(1, 5):
        rr = [r for r in rows if r['block'] == b]
        if len(rr) != 3:
            blocks.append({'block': b, 'complete': False, 'accepted_roles': [r['role'] for r in rr]})
            continue
        if len({r['external_work_sha256'] for r in rr}) != 1 or len({tuple(r['question_ids']) for r in rr}) != 1:
            raise ValueError('external workload does not match inside block')
        x = {r['role']: r for r in rr}; s = {k: r['summary'] for k, r in x.items()}
        gains = {}; saved = {}; components = {}
        for tag, candidate, reference in [('scheduling_D_vs_A','D','A'), ('batching_C_vs_D','C','D'), ('total_C_vs_A','C','A')]:
            pair = compare(s[reference], s[candidate])
            pair.update(block=b, contrast=tag, reference=reference, candidate=candidate)
            pair['saved_jct_ms'] = s[reference]['mean_jct_ms'] - s[candidate]['mean_jct_ms']
            components[tag] = {k: s[candidate].get('mean_critical_path_components_ms', {}).get(k, 0)
                - s[reference].get('mean_critical_path_components_ms', {}).get(k, 0)
                for k in set(s[candidate].get('mean_critical_path_components_ms', {})) | set(s[reference].get('mean_critical_path_components_ms', {}))}
            pair['critical_path_difference_candidate_minus_reference_ms'] = components[tag]
            gains[tag] = pair['gain_pct']['mean_jct_ms']; saved[tag] = pair['saved_jct_ms']; pairs.append(pair)
        block = {'block': b, 'complete': True, 'JCT_ms': {k: v['mean_jct_ms'] for k, v in s.items()},
             'gain_pct': gains, 'saved_jct_ms': saved,
             'both_gains_positive': s['C']['mean_jct_ms'] < s['D']['mean_jct_ms'] < s['A']['mean_jct_ms'],
             'combined_gain_above_10pct': gains['total_C_vs_A'] > 10.,
             'segments': {k: r['segment'] for k, r in x.items()},
             'source_kind': {k: r['source_kind'] for k, r in x.items()}}
        blocks.append(block)
    aggregates = {}
    for tag in ('scheduling_D_vs_A', 'batching_C_vs_D', 'total_C_vs_A'):
        ps = [p for p in pairs if p['contrast'] == tag]
        aggregates[tag] = {'paired_JCT_gain_pct': describe([p['gain_pct']['mean_jct_ms'] for p in ps]),
            'paired_saved_JCT_ms': describe([p['saved_jct_ms'] for p in ps]),
            'positive_blocks': sum(p['gain_pct']['mean_jct_ms'] > 0 for p in ps),
            'mean_paired_auxiliary_gain_pct': {k: describe([p['gain_pct'][k] for p in ps if p['gain_pct'].get(k) is not None])['mean'] for k in METRICS},
            'blocks_2_to_4_JCT_gain_pct': describe([p['gain_pct']['mean_jct_ms'] for p in ps if p['block'] != 1])}
    finished = [b for b in blocks if b['complete']]
    report = {'schema': 'musique-n16-r4-two-stage-gains-1', 'scope': 'frozen N16, mean4/s original wave; A-F4096 reference',
        'complete': len(seen) == 12, 'accepted_conditions': len(seen), 'expected_conditions': 12,
        'blocks': blocks, 'pairs': pairs, 'aggregates': aggregates,
        'mechanism_observations': [{'label':x['label'], 'role':x['role'], 'block':x['block'],
            'route_deviations':x['summary'].get('routing_deviations_from_snapshot_affinity'),
            'D0_schedule_integrity':x['summary'].get('D0_schedule_integrity'),
            'cap_restriction_plans_committed':x['summary'].get('cap_restriction_plans_committed'),
            'opportunity_replica_decisions':x['summary'].get('opportunity_replica_decisions'),
            'cap1024':x['summary'].get('per_cap',{}).get('1024'),
            'commit_fallback_reason_counts':x['summary'].get('commit_fallback_reason_counts',{}),
            'critical_path_components_ms':x['summary'].get('mean_critical_path_components_ms',{})}
            for x in rows],
        'both_gains_positive_blocks': sum(b['both_gains_positive'] for b in finished),
        'total_above_10pct_blocks': sum(b['combined_gain_above_10pct'] for b in finished),
        'all_conditions_kept_regardless_of_performance': True, 'all_block_wins_required': False,
        'all_metrics_improve_required': False, 'no_posthoc_guard_removed': True,
        'no_JCT_cost_subtraction': True, 'no_JLight_or_new_joint_feedback_tested': True,
        'scope_is_composition_not_superiority_to_decoupled': True,
        'fresh_unseen_holdout': False, 'formal_significance_established': False,
        'block1_previously_observed_favorable_example': True,
        'cross_segment_execution_disclosed': True,
        'blocks_differ_in_question_cohort_not_four_independent_repeats_of_one_trace': True,
        'original_non4s_conditions': excluded,
        'completion_does_not_finish_original_36_condition_suite': True}
    if len(seen) == 12:
        g = {k: v['paired_JCT_gain_pct']['mean'] for k, v in aggregates.items()}
        if g['scheduling_D_vs_A'] > 0 and g['batching_C_vs_D'] > 0:
            conclusion = 'two_stage_mean_gains_observed; report recurrence_and_variation_without_universal_claim'
        elif g['total_C_vs_A'] > 0:
            conclusion = 'combined_gain_observed; separate_batching_increment_not_established_if_C_vs_D_nonpositive'
        else:
            conclusion = 'combined_gain_not_established_in_complete_batch; retain_all_results_and_checkpoint'
        report.update(conclusion=conclusion, combined_mean_above_10pct=g['total_C_vs_A'] > 10.,
                      no_further_automatic_policy_search=True)
    return report


def write(out, rows, design, excluded, complete=False):
    out = Path(out); r = build(rows, design, excluded, complete)
    atomic(out / 'result.json', r)
    flds = ['label','role','block','position','scheduler','policy','source_kind','segment'] + list(METRICS) + ['output_tokens','final_em','final_f1','route_deviations','strict_cap_binding']
    with (out / 'conditions.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, flds); w.writeheader()
        for row in rows:
            s = row['summary']; q = s.get('semantic_quality', {})
            w.writerow({**{k: row[k] for k in flds[:8]}, **{k: s.get(k) for k in METRICS},
                'output_tokens': s.get('output_tokens'), 'final_em': q.get('final_em'), 'final_f1': q.get('final_f1'),
                'route_deviations': s.get('routing_deviations_from_snapshot_affinity'),
                'strict_cap_binding': sum(x.get('strict_binding_candidates', 0) for x in s.get('per_cap', {}).values())})
    with (out / 'paired_gains.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, ['block','contrast','saved_jct_ms','JCT_gain_pct']); w.writeheader()
        for p in r['pairs']: w.writerow({'block': p['block'], 'contrast': p['contrast'], 'saved_jct_ms': p['saved_jct_ms'], 'JCT_gain_pct': p['gain_pct']['mean_jct_ms']})
    lines = ['# MuSiQue N16 / 4 workflow/s: A → D0 → D0+Mixed1024', '',
        f'Accepted: {len(rows)}/12. Original D0, model, Mixed1024, question blocks and arrival offsets unchanged.',
        'Positive percentages denote lower complete workflow JCT; no computing/wait time is subtracted.',
        'This is the 4/s slice resumed across execution segments, not a new unseen holdout or a J-Light experiment.', '',
        '| Block | A JCT ms | D JCT ms | C JCT ms | D/A gain | C/D gain | C/A gain | Both positive |',
        '|---:|---:|---:|---:|---:|---:|---:|---|']
    for b in r['blocks']:
        if not b['complete']: lines.append(f'| {b["block"]} | incomplete | | | | | | |'); continue
        j = b['JCT_ms']; g = b['gain_pct']
        lines.append(f'| {b["block"]} | {j["A"]:.3f} | {j["D"]:.3f} | {j["C"]:.3f} | {g["scheduling_D_vs_A"]:.3f}% | {g["batching_C_vs_D"]:.3f}% | {g["total_C_vs_A"]:.3f}% | {b["both_gains_positive"]} |')
    lines += ['', '## Paired aggregate (all available complete blocks)',
        '| Contrast | Mean gain % | SD % | Range % | Mean saved ms | Positive blocks |',
        '|---|---:|---:|---|---:|---:|']
    for tag, a in r['aggregates'].items():
        g=a['paired_JCT_gain_pct'];sv=a['paired_saved_JCT_ms']
        if not g['n']: continue
        sd='N/A' if g['sample_sd'] is None else f"{g['sample_sd']:.3f}"
        lines.append(f"| {tag} | {g['mean']:.3f} | {sd} | [{g['min']:.3f}, {g['max']:.3f}] | {sv['mean']:.3f} | {a['positive_blocks']}/{g['n']} |")
    lines += ['', '## Actual placement and cap activity (observational evidence)',
        '| Condition | Route deviations | Restriction plans | 1024 iterations with prefill | Strict cap-binding candidates |',
        '|---|---:|---:|---:|---:|']
    for m in r['mechanism_observations']:
        cap=m['cap1024'] or {}
        lines.append(f"| {m['label']} | {m['route_deviations']} | {m['cap_restriction_plans_committed']} | {cap.get('with_prefill',0)} | {cap.get('strict_binding_candidates',0)} |")
    lines += ['', 'Each contrast in result.json also carries complete critical-path component differences. No per-action causal attribution is inferred from this table.']
    lines += ['', '## Statistical and mechanism boundaries',
        'Each percentage is paired within one block, then averaged; average component gains are NOT multiplied to form average total gain.',
        'The main result includes all four blocks. A separate blocks2–4 sensitivity summary exposes the influence of the previously observed Block1; it does not replace the main result.',
        'Reported cap activity and critical-path differences are observational accounting, not a per-action counterfactual or GPU kernel attribution.',
        'Mean/P95 TTFT, node first-content latency, TPOT proxy, quality and natural output counts remain auxiliary outcomes. No existing safety guard is relaxed.',
        'The original 2/s, 8/s and N64 records remain untouched; unexecuted cells are marked unexecuted, not silently dropped.',
        'Completion, a positive mean, and a >10% point estimate are distinct statements. No performance guarantee or automatic follow-on tuning.']
    (out / 'REPORT.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return r
