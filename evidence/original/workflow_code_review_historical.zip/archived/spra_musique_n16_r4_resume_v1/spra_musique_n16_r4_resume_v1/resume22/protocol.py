"""Select a slice of the ORIGINAL frozen manifest, not a new random design."""
from __future__ import annotations
import copy
import math
from .dependency import activate
activate()
from batching20.protocol import confirmation_design
from semantic19.workflow import arrival_offsets
from joint18v2.common import digest

ROLE_BY_POLICY = {('A', 'fixed_4096'): 'A', ('D', 'fixed_4096'): 'D', ('D', 'mixed_1024'): 'C'}

def target_design(frozen_protocol, old_protocol, selection):
    if frozen_protocol.get('command') != 'confirm': raise ValueError('expected original confirm suite')
    if selection.get('adaptive_policy') != 'mixed_1024' or selection.get('mixed_policy') != 'mixed_1024':
        raise ValueError('original frozen selection is not Mixed1024; no reselection allowed')
    if selection.get('best_fixed_per_rate', {}).get('4') != 4096:
        raise ValueError('original 4/s D0 fixed reference differs')
    expected = confirmation_design(old_protocol, selection)
    if frozen_protocol.get('design') != expected:
        raise ValueError('original frozen design differs from original generator')
    cfg = frozen_protocol['config']
    checks = {'workflow_count': 16, 'replicas': 4, 'hard_total': 4096, 'base_cap': 4096,
              'block_size': 16, 'max_num_seqs': 64, 'max_model_len': 4096, 'epoch_s': .2,
              'arrival_shape': 'wave', 'max_output_tokens': 96}
    if any(cfg.get(k) != v for k, v in checks.items()):
        raise ValueError('N16/environment/action semantics differ from original freeze')
    out = [copy.deepcopy(c) for c in frozen_protocol['design'] if float(c['rate']) == 4.]
    if len(out) != 12: raise ValueError('expected exactly twelve distinct 4/s conditions')
    for b in range(1, 5):
        group = [c for c in out if c['block'] == b]
        if {ROLE_BY_POLICY.get((c['scheduler'], c['policy'])) for c in group} != {'A', 'D', 'C'}:
            raise ValueError('A/D/C role set differs')
        if len(group) != 3 or sorted(c['position'] for c in group) != [1, 2, 3]:
            raise ValueError('original method positions differ')
        for c in group:
            if c['packet_slice'] != [(b - 1) * 16, b * 16] or c['seed'] != 200200 + b:
                raise ValueError('original question slices/seeds changed')
    if len({c['label'] for c in out}) != 12: raise ValueError('duplicate condition label')
    return out

def role(cell):
    return ROLE_BY_POLICY[(cell['scheduler'], cell['policy'])]

def cell_config(base, priors, cell):
    cc = copy.deepcopy(base)
    cc.update(arrival_rate=cell['rate'], workflow_count=16,
              batching20_policy=cell['policy'], batching20_output_priors=priors, base_cap=4096)
    return cc

def expected_identity(cell, records, cfg):
    lo, hi = cell['packet_slice']; ps = records[lo:hi]
    if len(ps) != 16: raise ValueError('original question slice missing')
    offsets = arrival_offsets(16, cell['rate'], cell['seed'], cfg['arrival_shape'])
    return {'ids': [p['id'] for p in ps], 'arrival_offsets': offsets,
            'graphs': [p['graph'] for p in ps], 'packet_slice': cell['packet_slice'],
            'seed': cell['seed'], 'rate': cell['rate'], 'N': 16}

def validate_saved_input(folder, cell, cfg, records, model):
    """Offline input/graph/timing checks; token equality is checked during normal preparation."""
    from .common import load
    m = load(folder / 'manifest.json'); ident = expected_identity(cell, records, cfg)
    if m.get('method') != cell['scheduler'] or m.get('config') != cfg:
        raise ValueError('saved method/config differ: ' + cell['label'])
    if m.get('model_id') != model.get('model_id'):
        raise ValueError('saved model identity differs')
    ns = m['input_nodes']; live = load(folder / 'nodes.json')
    if set(ns) != set(live): raise ValueError('saved input/output node sets differ')
    subset = records[slice(*cell['packet_slice'])]
    expected_keys = set()
    for wi, p in enumerate(subset):
        keys = [f'w{wi:04d}/step{i+1}' for i in range(len(p['steps']))]
        for step in p['steps']:
            i = step['position']; k = keys[i]; expected_keys.add(k)
            n = ns[k]
            required = {'id': k, 'wid': f'w{wi:04d}', 'dataset_id': p['id'], 'step_position': i,
                'parents': [keys[j] for j in step['parents']], 'hop_count': len(keys),
                'compiled_groups': [[keys[j] for j in g] for g in p['graph']['antichains'] if len(g) > 1],
                'compiled_descendants': [keys[j] for j in p['graph']['descendants'][i]],
                'compiled_successors': [keys[j] for j in p['graph']['successors'][i]],
                'graph_shape': p['graph']['shape'], 'source_subquestion_id': step['source_subquestion_id'],
                'max_output_tokens': 96, 'semantic_mode': True, 'typed_answer_mode': True}
            for field, val in required.items():
                if n.get(field) != val or live[k].get(field) != val:
                    raise ValueError(f'saved graph/input field differs: {k}.{field}')
            if not math.isclose(n['arrival_offset'], ident['arrival_offsets'][wi], rel_tol=0, abs_tol=1e-10):
                raise ValueError('saved arrival offsets differ')
            if live[k]['arrival_offset'] != n['arrival_offset']: raise ValueError('arrival offset mutated')
            if n.get('state') != 'blocked' or n.get('prompt_materialized') is not False:
                raise ValueError('expected original pre-execution node state')
    if expected_keys != set(ns): raise ValueError('extra/missing nodes in saved workload')
    ident['input_semantics_sha256'] = digest(ident)
    return ident

def external_hash(cell, packets, cfg):
    from joint18v2.common import digest
    ps = packets[slice(*cell['packet_slice'])]
    offsets = arrival_offsets(16, cell['rate'], cell['seed'], cfg['arrival_shape'])
    return digest({'ids': [p['id'] for p in ps], 'arrival_offsets': offsets,
                   'evidence_hashes': [p['evidence_hash'] for p in ps],
                   'graphs': [p['graph'] for p in ps], 'output_protocol': 'typed_JSON_natural_EOS_max96'})
