"""Resume the frozen MuSiQue N16, 4/s A/D/C slice. No new policy."""
REVISION = 'musique-n16-r4-resume-1'
CHECKER_REVISION = 'native-tail-capacity-check-1'
