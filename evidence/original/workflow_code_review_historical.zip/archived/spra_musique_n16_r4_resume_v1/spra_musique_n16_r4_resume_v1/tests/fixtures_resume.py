from __future__ import annotations
import copy
import json
import sys
from pathlib import Path
from resume22.dependency import activate
activate()
from batching20.dependency import TYPED
sys.path.insert(0,str(TYPED/'tests'))
from test_typed_contract import fixture, FakeTokenizer
from semantic19.dataset import compile_record
from typed19.workflow import compile_packets, instantiate
from resume22.common import atomic, load
from resume22.dependency import sha
from batching20.protocol import confirmation_design
from batching20 import experiment as E
from resume22.protocol import cell_config

MODEL={'model_id':'synthetic-test-model-not-GPU','models':{str(r):{'coef':[1.,0.,0.,0.,0.,0.]} for r in range(4)}}
PRIORS={'3':{'p75':8}}
SELECTION={'best_fixed_per_rate':{'2':4096,'4':4096,'8':4096},'adaptive_policy':'mixed_1024','mixed_policy':'mixed_1024'}
CFG=load(TYPED/'configs/semantic.json');CFG.update(base_cap=4096,workflow_count=16)
P=E.protocol()
FP={'command':'confirm','config':CFG,'design':confirmation_design(P,SELECTION)}
ENV=[{'pod':f'spra-vllm-{r}','pid':100+r,'boot_id':'synthetic-boot',
       'hook_source_sha256':E.HOOK,'scheduler_source_sha256':'synthetic-scheduler',
       'nvidia_visible_devices':f'NOT-REAL-GPU-{r}','hard_total':4096,'block_size':16,
       'num_gpu_blocks':4096,'max_num_seqs':64,'max_model_len':4096,'num_scheduler_steps':1,
       'prefix_caching':True,'chunked_prefill':True,'native_cache_allocator':'v2'} for r in range(4)]

def dataset(root):
    root.mkdir(parents=True,exist_ok=True);public=[];gold=[]
    for i in range(64):
        raw=fixture();raw['id']=f'SYNTHETIC_{i:03d}';raw['paragraphs'][0]['title']=f'City_{i:03d}'
        p,g=compile_record(raw);public.append(p);gold.append(g)
    (root/'pilot.public.jsonl').write_text(''.join(json.dumps(p)+'\n' for p in public))
    (root/'evaluation_gold.jsonl').write_text(''.join(json.dumps(p)+'\n' for p in gold))
    m={'files':{p.name:sha(p) for p in root.iterdir() if p.is_file()},'counts':{'pilot':64}}
    atomic(root/'manifest.json',m)
    return public,m

async def write_record(folder,nodes,materializer,cfg,method,model=MODEL,delay=1.0):
    folder.mkdir(parents=True)
    original=copy.deepcopy(nodes)
    case=folder.parent.name+'/'+folder.name
    atomic(folder/'manifest.json',{'case':case,'method':method,'config':cfg,'input_nodes':original,
                                  'model_id':model.get('model_id'),'identities':[{'pod':x['pod'],'pid':x['pid'],'boot_id':x['boot_id']} for x in ENV]})
    ctrl={'plan_id':'synthetic-plan','not_before_ns':0,'action_expires_ns':10**12,'caps':[4096]*4,'totals':[4096]*4}
    events=[];iter_no=0
    for k,n in nodes.items():
        n['arrival']=100.+n['arrival_offset']
        await materializer(k,nodes)
        n['start']=max(n['arrival'],*(nodes[p]['finish'] for p in n['parents'])) if n['parents'] else n['arrival']
        n.update(state='done',replica=int(n['wid'][1:])%4,finish=n['start']+delay,
                 stream={'text':'{"answer":"Paris"}','finish_reason':'stop','usage':{'completion_tokens':8,'prompt_tokens':n['prompt']}})
        iter_no+=1;rid=k
        events.append({'event':'accept','prompt_hash':n['hash'],'request_id':rid,'replica':n['replica']})
        ev={'event':'iteration','replica':n['replica'],'pid':100+n['replica'],'case':case,'iteration':iter_no,
            'plan_id':'synthetic-plan','plan_reason':'lease_ok','execution_phase':'current_action',
            'begin_ns':100+iter_no,'effective_ns':100+iter_no,'total':4096,'prefill_cap':4096,
            'ordered_before':{'running':[],'waiting':[{'request_id':rid,'prefill':True,'prompt':n['prompt'],'computed':0}],'swapped':[]},
            'scheduled':[{'request_id':rid,'tokens':n['prompt'],'prefill':True}],
            'prefill_logical_tokens':n['prompt'],'decode_tokens':0,'preemptions':0,
            'remaining_prefill_in_before':n['prompt'],'order':{},'engine_host_ms':1.}
        events.append(ev)
    by={}
    for n in nodes.values():by.setdefault(n['wid'],[]).append(n)
    jcts=[1000*(max(n['finish'] for n in group)-group[0]['arrival']) for group in by.values()]
    duration=max(n['finish'] for n in nodes.values())-min(n['arrival'] for n in nodes.values())
    s={'condition_valid':True,'requests':len(nodes),'workflows':16,'output_tokens':len(nodes)*8,
       'mean_jct_ms':sum(jcts)/16,'p95_jct_ms':max(jcts),'cohort_duration_s':duration,
       'cohort_workflows_s':16/duration,'cohort_tokens_s':len(nodes)*8/duration,
       'budget_invariants':True,'control_time_match':True,'request_correlation':f'{len(nodes)}/{len(nodes)}',
       'native_next_batch_checked':len(nodes),'native_next_batch_matches':len(nodes),
       'mean_critical_path_components_ms':{'central_queue_and_admission':0.,'content_receive':sum(jcts)/16},
       'mean_request_ttft_ms':100.,'p95_request_ttft_ms':100.,'mean_client_tpot_proxy_ms':20.,
       'p95_client_tpot_proxy_ms':20.,'mean_node_time_to_first_content_ms':100.}
    atomic(folder/'nodes.json',nodes);atomic(folder/'summary.json',s)
    atomic(folder/'status.json',{'execution':'complete','error':None})
    atomic(folder/'trace_capture.json',{'partial_lines':0,'records':len(events),'condition_failed':False})
    atomic(folder/'controls.json',[ctrl]);(folder/'plans.jsonl').write_text('')
    (folder/'backend.jsonl').write_text(''.join(json.dumps(e)+'\n' for e in events))
    return s,events

async def make_record(folder,cell,public,cfg=None,tok=None,delay=1.):
    cfg=cell_config(CFG,PRIORS,cell) if cfg is None else cfg
    tok=tok or FakeTokenizer()
    pp,_=await compile_packets(public,tok,cfg)
    ns,mat,proof=await instantiate(pp[slice(*cell['packet_slice'])],tok,cfg,cell['seed'],PRIORS)
    s,e=await write_record(folder,ns,mat,cfg,cell['scheduler'],delay=delay)
    return s,ns,proof,pp,tok
