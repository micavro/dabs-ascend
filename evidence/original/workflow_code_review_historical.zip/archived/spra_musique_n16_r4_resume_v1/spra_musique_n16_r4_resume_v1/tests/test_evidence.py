import contextlib,copy,io,json,tempfile,unittest
from pathlib import Path
from resume22.common import load,atomic,files
from resume22.protocol import target_design,cell_config
from resume22.evidence import validate_record,canonical_input_check,finalize,verify_acceptance,cached_verdict
from resume22.dependency import sha,ROOT
from fixtures_resume import dataset,make_record,FP,P,SELECTION,CFG,PRIORS,MODEL,FakeTokenizer

class EvidenceTests(unittest.IsolatedAsyncioTestCase):
    async def setup_case(self,root):
        data=root/'dataset';public,dm=dataset(data)
        c=target_design(FP,P,SELECTION)[2] # original failed A
        unit=root/'unit';unit.mkdir();s,ns,proof,pp,t=await make_record(unit/'raw',c,public)
        atomic(unit/'origin.json',{'kind':'legacy_reused','source':'synthetic','segment':'legacy'})
        atomic(unit/'cell.json',c)
        return data,public,c,unit,ns,pp,t
    async def test_missing_old_semantic_proof_reconstructed_no_regeneration(self):
        with tempfile.TemporaryDirectory() as td:
            data,p,c,u,ns,pp,t=await self.setup_case(Path(td));before=files(u/'raw')
            q=await canonical_input_check(u,c,pp,cell_config(CFG,PRIORS,c),t)
            self.assertTrue(q['pass']);self.assertEqual(q['requests_checked'],48)
            self.assertTrue(q['missing_legacy_semantic_proof_not_fabricated'])
            self.assertEqual(before,files(u/'raw'))
    async def test_wrong_prompt_refused(self):
        with tempfile.TemporaryDirectory() as td:
            data,p,c,u,ns,pp,t=await self.setup_case(Path(td))
            m=load(u/'raw/manifest.json');m['input_nodes'][next(iter(ns))]['tokens'][-3]=999
            atomic(u/'raw/manifest.json',m)
            with self.assertRaises(ValueError):await canonical_input_check(u,c,pp,cell_config(CFG,PRIORS,c),t)
    async def test_wrong_question_identity_refused(self):
        with tempfile.TemporaryDirectory() as td:
            data,p,c,u,ns,pp,t=await self.setup_case(Path(td))
            m=load(u/'raw/manifest.json');m['input_nodes'][next(iter(ns))]['dataset_id']='different'
            atomic(u/'raw/manifest.json',m)
            with self.assertRaises(ValueError):validate_record(u/'raw',c,cell_config(CFG,PRIORS,c),p,MODEL)
    async def test_finalize_preserves_raw_metrics_and_all_raw_bytes(self):
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
            data,p,c,u,ns,pp,t=await self.setup_case(Path(td));before=files(u/'raw')
            v=validate_record(u/'raw',c,cell_config(CFG,PRIORS,c),p,MODEL);atomic(u/'offline_validation.json',v)
            self.assertTrue(v['accepted'])
            await canonical_input_check(u,c,pp,cell_config(CFG,PRIORS,c),t)
            r=finalize(u,c,data,v)
            self.assertEqual(r['summary']['mean_jct_ms'],load(u/'raw/summary.json')['mean_jct_ms'])
            self.assertEqual(before,files(u/'raw'));self.assertEqual(verify_acceptance(u),r)
            self.assertEqual(finalize(u,c,data,v),r)
    async def test_changed_raw_after_acceptance_fails(self):
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
            data,p,c,u,ns,pp,t=await self.setup_case(Path(td))
            v=validate_record(u/'raw',c,cell_config(CFG,PRIORS,c),p,MODEL)
            await canonical_input_check(u,c,pp,cell_config(CFG,PRIORS,c),t);finalize(u,c,data,v)
            with (u/'raw/nodes.json').open('a') as f:f.write(' ')
            with self.assertRaises(ValueError):verify_acceptance(u)
    async def test_changed_JCT_rejected_not_retimed(self):
        with tempfile.TemporaryDirectory() as td:
            data,p,c,u,ns,pp,t=await self.setup_case(Path(td))
            s=load(u/'raw/summary.json');s['mean_jct_ms']-=10;atomic(u/'raw/summary.json',s)
            with self.assertRaisesRegex(ValueError,'JCT'):validate_record(u/'raw',c,cell_config(CFG,PRIORS,c),p,MODEL)
    async def test_unresolved_actual_schedule_refused(self):
        with tempfile.TemporaryDirectory() as td:
            data,p,c,u,ns,pp,t=await self.setup_case(Path(td))
            ep=u/'raw/backend.jsonl';ev=list(map(json.loads,ep.read_text().splitlines()))
            e=next(x for x in ev if x['event']=='iteration');e['scheduled'][0]['tokens']-=1;e['prefill_logical_tokens']-=1
            ep.write_text(''.join(json.dumps(x)+'\n' for x in ev))
            v=validate_record(u/'raw',c,cell_config(CFG,PRIORS,c),p,MODEL)
            self.assertFalse(v['accepted'])
    async def test_existing_revalidation_receipt_requires_hashes_and_checker(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);data,p,c,u,ns,pp,t=await self.setup_case(root)
            v=validate_record(u/'raw',c,cell_config(CFG,PRIORS,c),p,MODEL)['batch']
            dst=root/'focus';dst.mkdir();f=dst/'prior_revalidation.json'
            atomic(f,{'old_suite':str((u/'raw').parent),'conditions':[v]})
            atomic(dst/'manifest.json',{'checker_revision':'native-tail-capacity-check-1','files':{f.name:sha(f)},
                'adapter_identity':{'joint21/batchcheck.py':sha(ROOT/'resume22/batchcheck.py')}})
            r,how=cached_verdict(u/'raw',[f]);self.assertIsNotNone(r)
            self.assertEqual(how['kind'],'existing_hash_verified_receipt')
            (u/'raw/backend.jsonl').write_text('')
            self.assertEqual(cached_verdict(u/'raw',[f]),(None,None))
    async def test_semantic_error_not_execution_veto(self):
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
            data,p,c,u,ns,pp,t=await self.setup_case(Path(td))
            v=validate_record(u/'raw',c,cell_config(CFG,PRIORS,c),p,MODEL)
            await canonical_input_check(u,c,pp,cell_config(CFG,PRIORS,c),t)
            r=finalize(u,c,data,v);self.assertTrue(r['accepted']);self.assertEqual(r['summary']['semantic_quality']['final_em'],0)
