import copy
import unittest
from resume22.protocol import target_design,role,cell_config
from resume22.report import build
from fixtures_resume import FP,P,SELECTION,CFG,PRIORS

class ProtocolTests(unittest.TestCase):
    def test_exact_twelve_original_cells(self):
        d=target_design(FP,P,SELECTION)
        self.assertEqual(len(d),12)
        self.assertEqual(d,[x for x in FP['design'] if x['rate']==4])
    def test_no_other_rate_or_N(self):
        for c in target_design(FP,P,SELECTION):
            self.assertEqual(c['rate'],4.);self.assertEqual(c['packet_slice'][1]-c['packet_slice'][0],16)
    def test_orders_preserved_not_rebalanced(self):
        d=target_design(FP,P,SELECTION)
        self.assertEqual([[role(c) for c in d if c['block']==b] for b in range(1,5)],
                         [['D','C','A'],['D','A','C'],['A','D','C'],['A','C','D']])
    def test_seed_change_fails(self):
        f=copy.deepcopy(FP);f['design'][3]['seed']+=1
        with self.assertRaises(ValueError):target_design(f,P,SELECTION)
    def test_protocol_N_change_fails(self):
        f=copy.deepcopy(FP);f['config']['workflow_count']=64
        with self.assertRaises(ValueError):target_design(f,P,SELECTION)
    def test_cannot_reselect_adaptive(self):
        s=copy.deepcopy(SELECTION);s['adaptive_policy']='completion_1024'
        with self.assertRaises(ValueError):target_design(FP,P,s)
    def test_aliases_not_extra_samples(self):
        d=target_design(FP,P,SELECTION)
        self.assertEqual(sum('D0-Adaptive' in c['roles'] for c in d),4)
        self.assertEqual(sum(role(c)=='C' for c in d),4)
    def test_config_exact_old_construction(self):
        c=target_design(FP,P,SELECTION)[1];cfg=cell_config(CFG,PRIORS,c)
        self.assertEqual({k:v for k,v in cfg.items() if not k.startswith('batching20_')},dict(CFG,arrival_rate=4.))

class ReportTests(unittest.TestCase):
    def rows(self):
        d=target_design(FP,P,SELECTION);rows=[]
        for c in d:
            r=role(c);v={'A':100.,'D':92.,'C':87.}[r]
            rows.append({**c,'role':r,'accepted':True,'external_work_sha256':str(c['block']),
                'question_ids':[str(x) for x in range(*c['packet_slice'])],
                'summary':{'workflows':16,'mean_jct_ms':v,'p95_jct_ms':v,'semantic_quality':{'final_em':0.,'final_f1':0.}},
                'segment':'legacy' if c['block']==1 else 'new','source_kind':'test'})
        return d,rows
    def test_three_contrasts(self):
        d,rs=self.rows();r=build(rs,d,[],True)
        self.assertAlmostEqual(r['aggregates']['total_C_vs_A']['paired_JCT_gain_pct']['mean'],13)
        self.assertEqual(r['both_gains_positive_blocks'],4)
    def test_no_incomplete_final_report(self):
        d,r=self.rows()
        with self.assertRaises(ValueError):build(r[:-1],d,[],True)
    def test_duplicate_alias_not_allowed(self):
        d,r=self.rows()
        with self.assertRaises(ValueError):build(r+[r[0]],d,[])
    def test_external_identity_mismatch_fails(self):
        d,r=self.rows();r[0]['external_work_sha256']='changed'
        with self.assertRaises(ValueError):build(r,d,[],True)
    def test_negative_block_retained_not_hard_failure(self):
        d,r=self.rows()
        for x in r:
            if x['block']==4 and x['role']=='C':x['summary']['mean_jct_ms']=101.
        z=build(r,d,[],True)
        self.assertEqual(z['both_gains_positive_blocks'],3);self.assertEqual(z['accepted_conditions'],12)
        self.assertEqual(z['blocks'][3]['JCT_ms']['C'],101.)
    def test_auxiliary_quality_zero_does_not_veto(self):
        d,r=self.rows();z=build(r,d,[],True)
        self.assertTrue(z['complete']);self.assertFalse(z['formal_significance_established'])
    def test_no_product_of_averaged_gains(self):
        d,r=self.rows()
        for x in r:
            if x['block']==2:x['summary']['mean_jct_ms']={'A':400.,'D':200.,'C':210.}[x['role']]
        z=build(r,d,[],True)
        avg=z['aggregates'];g1=avg['scheduling_D_vs_A']['paired_JCT_gain_pct']['mean']/100
        g2=avg['batching_C_vs_D']['paired_JCT_gain_pct']['mean']/100
        self.assertNotAlmostEqual(avg['total_C_vs_A']['paired_JCT_gain_pct']['mean'],100*(1-(1-g1)*(1-g2)))
    def test_partial_report_explicit(self):
        d,r=self.rows();z=build(r[:3],d,[])
        self.assertFalse(z['complete']);self.assertEqual(z['accepted_conditions'],3)
        self.assertFalse(z['blocks'][1]['complete'])
    def test_reused_B1_and_new_B234_reported_separately(self):
        d,r=self.rows();z=build(r,d,[],True)
        self.assertEqual(z['aggregates']['total_C_vs_A']['blocks_2_to_4_JCT_gain_pct']['n'],3)
        self.assertTrue(z['block1_previously_observed_favorable_example'])
