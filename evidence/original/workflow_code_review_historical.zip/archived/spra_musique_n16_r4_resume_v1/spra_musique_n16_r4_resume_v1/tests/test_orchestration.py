"""Real resume/report/receipt logic on synthetic disk records; no GPU experiment."""
import asyncio,contextlib,copy,io,json,shutil,tempfile,unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch
from resume22 import runner as R
from resume22.common import atomic,load,files
from resume22.dependency import ROOT as CODE,own_identity,sha
from resume22.protocol import target_design,cell_config
from batching20.dependency import verify,own_identity as batch_identity
from fixtures_resume import dataset,make_record,write_record,FP,P,SELECTION,CFG,PRIORS,MODEL,FakeTokenizer,ENV

class ResumeTests(unittest.IsolatedAsyncioTestCase):
    async def setup_all(self,root):
        new=root/'new';new.mkdir()
        for rel in own_identity():
            q=new/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(CODE/rel,q)
        data=root/'dataset';public,dm=dataset(data)
        frozen=root/'frozen';frozen.mkdir()
        atomic(frozen/'model.json',MODEL);atomic(frozen/'priors.json',PRIORS)
        mf={'D0_configuration':copy.deepcopy(CFG),'dataset':str(data),'protocol':P,
            'dataset_files':dm['files'],'dataset_manifest_sha256':sha(data/'manifest.json'),
            'validation_ids':[q['id'] for q in public],
            'files':{n:sha(frozen/n) for n in ('model.json','priors.json')}}
        atomic(frozen/'manifest.json',mf)
        dev=root/'development';dev.mkdir();atomic(dev/'selection.json',SELECTION)
        prior=root/'PRIOR';prior.mkdir()
        fp=copy.deepcopy(FP);fp.update(frozen_manifest_sha256=sha(frozen/'manifest.json'),code_hashes={**verify(),**batch_identity()})
        atomic(prior/'frozen_protocol.json',fp);atomic(prior/'selection.json',SELECTION)
        atomic(prior/'environment.json',ENV);atomic(prior/'cleanup.json',{'backend_drained':True,'source_files_unchanged':True})
        atomic(prior/'suite_status.json',{'status':'failed','error':'native batch correspondence failure'})
        d=target_design(fp,P,SELECTION);idx=[]
        for c in d[:3]:
            s,ns,proof,pp,t=await make_record(prior/c['label'],c,public,delay={'A':1.,'D':.92,'C':.87}[R.role(c)])
            if c['scheduler']=='A':
                # Old stale match flag does not change measured JCT or current evidence.
                s['native_next_batch_matches']-=1;atomic(prior/c['label']/'summary.json',s)
            else:idx.append({**c,'summary':s,'folder':str(prior/c['label'])})
        atomic(prior/'index.json',idx)
        rt=root/'runtime';(rt/'joint18v2').mkdir(parents=True)
        return new,data,public,frozen,mf,dev,prior,rt

    async def flow(self,fail_execution=False,fail_postprocess=False,negatives=False):
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
            root=Path(td);new,data,public,frozen,mf,dev,prior,rt=await self.setup_all(root)
            before=files(prior);calls=[];warm=[];failed=[False];postfailed=[False]
            async def gate(*args):return copy.deepcopy(ENV)
            async def drained(*args):return True
            async def warmup(*args):warm.append(1)
            async def execute(client,runtime,initial,cfg,nodes,folder,method,model,executor=None,materializer=None):
                calls.append((method,cfg['batching20_policy']))
                if fail_execution and len(calls)==2 and not failed[0]:
                    failed[0]=True;raise RuntimeError('synthetic transport failure')
                if method=='A':self.assertIsNone(executor)
                delay=1. if method=='A' else .92 if cfg['batching20_policy']=='fixed_4096' else (1.1 if negatives else .87)
                return await write_record(folder,nodes,materializer,cfg,method,model,delay)
            real_finalize=R.finalize
            def finalize(*args,**kwargs):
                if fail_postprocess and Path(args[0]).parent.name=='attempts' and not postfailed[0]:
                    postfailed[0]=True;raise RuntimeError('synthetic postprocessing interruption')
                return real_finalize(*args,**kwargs)
            with patch.object(R,'ROOT',new),patch.object(R.old,'load_frozen',return_value=(frozen,mf,MODEL,PRIORS)),\
                 patch.object(R.old,'read_selection',return_value=(dev,SELECTION)),\
                 patch.object(R.old,'gate',gate),patch.object(R.old,'wait_drained',drained),patch.object(R.old,'warmup',warmup),\
                 patch.object(R.old,'execute',execute),patch.object(R,'ServerTokenizer',lambda *a:FakeTokenizer()),\
                 patch.object(R,'ProcessPoolExecutor',lambda *a,**kw:ThreadPoolExecutor(1)),patch.object(R,'finalize',finalize):
                out=R.prepare(prior)
                self.assertEqual(load(out/'suite_status.json')['saved_conditions_revalidated'],3)
                self.assertEqual(files(prior),before)
                self.assertEqual(R.prepare(prior),out)
                if fail_execution:
                    with self.assertRaisesRegex(RuntimeError,'synthetic transport'):await R.run(out,rt)
                    count=len(calls)
                    with self.assertRaisesRegex(ValueError,'retry-incomplete'):await R.run(out,rt)
                    self.assertEqual(len(calls),count)
                    await R.run(out,rt,retry_incomplete=True)
                    self.assertEqual(len(calls),10)
                elif fail_postprocess:
                    with self.assertRaisesRegex(RuntimeError,'postprocessing'):await R.run(out,rt)
                    self.assertEqual(len(calls),1)
                    await R.run(out,rt)
                    self.assertEqual(len(calls),9)
                else:
                    await R.run(out,rt);self.assertEqual(len(calls),9)
                result=load(out/'result.json');self.assertTrue(result['complete'])
                self.assertEqual(result['accepted_conditions'],12)
                self.assertEqual(len(load(out/'index.json')),12)
                self.assertEqual(sum(r['source_kind']=='legacy_reused' for r in load(out/'index.json')),3)
                self.assertEqual(files(prior),before)
                self.assertEqual(load(out/'suite_status.json')['status'],'complete')
                self.assertFalse((prior/'batching_result.json').exists())
                count=len(calls);n=len(warm);await R.run(out,rt)
                self.assertEqual(len(calls),count);self.assertEqual(len(warm),n)
                import zipfile
                archive=load(out/'archive_receipt.json')
                with zipfile.ZipFile(archive['path']) as z:
                    self.assertIsNone(z.testzip());self.assertIn('run/result.json',z.namelist())
                    self.assertIn('ARCHIVE_SHA256SUMS',z.namelist())
                if negatives:self.assertLess(result['aggregates']['batching_C_vs_D']['paired_JCT_gain_pct']['mean'],0.)
    async def test_reuse_three_run_nine_and_seal_once(self):await self.flow()
    async def test_negative_results_complete_no_tuning(self):await self.flow(negatives=True)
    async def test_incomplete_attempt_requires_explicit_retry(self):await self.flow(fail_execution=True)
    async def test_complete_raw_postprocessing_recovered_without_generation(self):await self.flow(fail_postprocess=True)
    async def test_protocol_change_stops_before_network(self):
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
            new,data,public,frozen,mf,dev,prior,rt=await self.setup_all(Path(td))
            with patch.object(R,'ROOT',new),patch.object(R.old,'load_frozen',return_value=(frozen,mf,MODEL,PRIORS)),patch.object(R.old,'read_selection',return_value=(dev,SELECTION)):
                out=R.prepare(prior);x=load(prior/'frozen_protocol.json');x['config']['epoch_s']=.3;atomic(prior/'frozen_protocol.json',x)
                with self.assertRaisesRegex(ValueError,'evidence changed'):R.check_frozen(out)
    async def test_unresolved_saved_A_blocks_no_new_requests(self):
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
            new,data,public,frozen,mf,dev,prior,rt=await self.setup_all(Path(td))
            a=next(c for c in target_design(FP,P,SELECTION)[:3] if c['scheduler']=='A')
            f=prior/a['label']/'backend.jsonl';ev=list(map(json.loads,f.read_text().splitlines()))
            x=next(x for x in ev if x['event']=='iteration');x['scheduled'][0]['tokens']-=1;x['prefill_logical_tokens']-=1
            f.write_text(''.join(json.dumps(x)+'\n' for x in ev))
            with patch.object(R,'ROOT',new),patch.object(R.old,'load_frozen',return_value=(frozen,mf,MODEL,PRIORS)),patch.object(R.old,'read_selection',return_value=(dev,SELECTION)):
                with self.assertRaisesRegex(ValueError,'unresolved'):R.prepare(prior)
                out=Path(load(new/'records/latest.json')['directory'])
                self.assertEqual(load(out/'suite_status.json')['status'],'blocked')
                self.assertFalse((out/'segments').exists())
    def test_engine_process_may_change_but_hardware_cannot(self):
        e=copy.deepcopy(ENV);e[0]['pid']+=1
        self.assertTrue(R.environment_check(e,ENV)['server_process_restart_between_segments'][0])
        e[0]['nvidia_visible_devices']='new-card'
        with self.assertRaises(ValueError):R.environment_check(e,ENV)
