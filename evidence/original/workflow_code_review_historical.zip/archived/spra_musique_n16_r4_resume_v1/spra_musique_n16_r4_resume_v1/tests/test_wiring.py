import copy,multiprocessing,sys,time,unittest
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from resume22.dependency import BATCH,activate
activate();sys.path.insert(0,str(BATCH/'tests'))
from test_policy import fixture,MODEL
from batching20.policy import process_plan,scheduling_view
from resume22.runner import bindings
from resume22.batchcheck import compare_iteration
from typed19.transport import stream
import joint18v2.client as client

class WiringTests(unittest.TestCase):
    def test_exact_original_policy_binding(self):
        with bindings():
            self.assertIs(client.process_plan,process_plan)
            self.assertIs(client.stream,stream)
            self.assertIs(client.compare_iteration,compare_iteration)
    def test_binding_restores_on_error(self):
        prior=client.process_plan,client.stream,client.compare_iteration
        with self.assertRaises(RuntimeError):
            with bindings():raise RuntimeError('test')
        self.assertEqual((client.process_plan,client.stream,client.compare_iteration),prior)
    def test_real_spawn_calls_original_D0_wrapper(self):
        s,a,c=fixture();c['batching20_policy']='mixed_1024'
        with ProcessPoolExecutor(1,mp_context=multiprocessing.get_context('spawn')) as ex:
            z=ex.submit(process_plan,s,MODEL,c,'D',time.monotonic()+5).result(timeout=10)
        self.assertTrue(z['batching20']['D0_schedule_unchanged'])
        self.assertEqual(scheduling_view(z['action']),scheduling_view(z['batching20']['D0_action']))
        self.assertNotIn('joint21',z)
    def test_no_new_policy_source_in_bundle(self):
        from resume22.dependency import ROOT
        self.assertFalse((ROOT/'resume22/policy.py').exists())
        self.assertFalse((ROOT/'runtime').exists())
