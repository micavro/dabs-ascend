# Implementation and evidence contract

## Policy boundary

`resume22.runner.bindings` delegates to the original `batching20.binding.bindings`.
The worker callable remains exactly `batching20.policy.process_plan`, which calls
`semantic19.selector.choose(..., 'D', deadline)` before replacing only `caps`.
There is no policy.py in this package, no Joint feedback callable, no service model
fit, no new cap, no new admission/deadline logic, and no changes to the live hook.
A uses the original fixed/reference path without a worker.

The only changed imported client name is the independent POST-execution
`compare_iteration`. `resume22/batchcheck.py` is byte-identical to the previously
delivered `joint21/batchcheck.py` with CHECKER_REVISION `native-tail-capacity-check-1`.
Prediction does not consume actual scheduled token values; remaining unexplained
mismatches fail. The checker remains limited to its existing n=1, single-step,
non-preemption/non-swap envelope. Source code and the reference remain immutable.

## Reuse boundary

The original confirmation manifest is the source of truth for design, configuration,
method positions, seeds, aliases, public question slices and source hashes. The
original D0 freeze and original development selection are read without recomputation
of model coefficients or strategy selection. The old selection is only checked for
consistency using the already frozen development rows.

Existing prior revalidation receipts are accepted only when the receipt itself is
covered by the focus preparation manifest, the checker byte hash/revision matches,
and all covered old raw files still match. A console success flag alone is not a
receipt. Otherwise the same corrected checker reads the saved raw batches inline.
All target methods are treated alike, including the old failed A.

Raw files are copied to an independent output tree. The original summary, including
its old match count and old incomplete-suite status, is never overwritten. The new
acceptance receipt and supplemented report explain the corrected independent check.

## Input identity boundary

Offline checks compare the frozen configuration, original public question order,
DAG edges/groups, step IDs, arrival offsets, declared output limits, and saved actual
parent bindings. Raw JCT and usage counts are independently cross-checked against
node completion timestamps only to detect inconsistency; they are never retimed.

The old failed A may lack `semantic_proof.json` because the former runner stopped
before saving it. The normal token preparation step therefore verifies all saved
initial token arrays against the same canonical server template, frozen documents
and original static subquestions, using the OLD saved Run nonce. This uses only
local tokenize/detokenize endpoints, not model generation. It reconstructs external
identity; it does not pretend the missing historical proof file existed.

The previous D and C external-work hashes, when present, must equal the reconstructed
hash. For new cells the original native instantiator is used. Dynamic parent-derived
input preparation remains in the measured workflow path.

## Time and environment boundary

Each new execution segment records its gate snapshot and differences in process
identity. Recorded GPU mapping, hook and scheduler hashes, KV block limits, context,
chunked-prefill/APC and single-step settings must match the old suite. A process
restart between segments is disclosed, not used to erase old records.

The original warmup helper performs 8 ordinary requests plus 4 identical-schema JSON
requests before the resumed measured segment. No warmup is repeated based on speed.
A fully completed recovery does not regenerate warmup or measured requests.

Measurements retain all actual pre-completion costs. The cohort boundary remains
last actual request completion rather than runner exit. We do not subtract planner
costs, remove negative cases, impose a new quality floor, or retroactively disable
any existing guard.

## Recovery and reporting boundary

The target is exactly twelve independent conditions. Role aliases reuse the same
execution, never count as replicates. Final acceptance occurs only after required
native, input, dependency, control and D0-field checks. An accepted record is hash
covered; changed evidence fails rather than triggering a convenient rerun.

Completed-but-unfinalized new records can be finalized without regeneration.
Only genuinely unfinished NEW attempts can be retried using explicit
`--retry-incomplete`; all failed attempts remain. Fully executed but inconsistent
records cannot be bypassed with that flag. Accepted poor performance cannot be retried.

The original 2/s and8/s metadata is archived as outside the present slice; unfinished
cells remain explicitly unfinished. Completion of this package never marks the old
36-cell suite complete and does not merge N64 results into N16 statistics.

The output reports paired per-block differences, signed mean gains and variability,
co-positive blocks, >10% blocks, auxiliary measurements and a separate blocks2–4
sensitivity summary. Four different question blocks are not four independent
repetitions of one physical workload; this is not a new unseen-question holdout.
The protocol demonstrates composition and component increments, not superiority of
an additional simultaneous feedback optimizer over Decoupled.
