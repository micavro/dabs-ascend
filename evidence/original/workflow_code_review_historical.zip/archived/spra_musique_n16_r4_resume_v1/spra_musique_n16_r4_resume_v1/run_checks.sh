#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
export PYTHONDONTWRITEBYTECODE=1
sha256sum -c SHA256SUMS
"${PYTHON:-python}" -B -m unittest discover -s tests -v
