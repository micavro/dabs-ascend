#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
export PYTHONDONTWRITEBYTECODE=1
exec "${PYTHON:-python}" -B -u tools/run_resume.py run "$@"
