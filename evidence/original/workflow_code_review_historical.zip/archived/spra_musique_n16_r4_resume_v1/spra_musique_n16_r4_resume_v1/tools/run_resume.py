#!/usr/bin/env python3
"""Entrypoint safe for multiprocessing spawn; all remote activity is explicit."""
import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from resume22.runner import main
if __name__ == '__main__':
    main()
