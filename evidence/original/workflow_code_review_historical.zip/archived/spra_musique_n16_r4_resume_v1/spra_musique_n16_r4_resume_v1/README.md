# MuSiQue N16 / 4 workflow/s：原冻结A→D₀→C实验续跑

本包只完成已声明的4/s四个block，不建立新策略、不增加J-Light，不将N64配置改成N16后冒充原实验。

- A：原Affinity/FIFO，prefill cap4096。
- D：原D₀，prefill cap4096。
- C：同一个D₀，原Mixed1024；默认4096，在原定义竞争条件下限制为1024。
- 4个原问题block，每个16题，每block三个实际不同方法，共12格。
- 从原冻结`frozen_protocol.json`读取切片、种子、顺序、配置和模型身份。
- 完整JCT是主指标。质量、TTFT、TPOT代理、P95和吞吐继续报告；不取消原代码里的安全/状态守卫。
- 这是组合收益及其两级消融，不是“额外同步联合反馈优于Decoupled”的实验。

## 一、这次需要保留的目录

GPU39的`/home/wmy/sci/spra_paper_experiments_github/`下应保留：

```text
spra_stage19_musique_joint_v1/         # 原执行器与编译后的MuSiQue数据
spra_stage19_typed_handoff_v1/         # 已冻结的语义交接接口
spra_musique_d0_batching_v1/           # 原D₀ cap-only绑定、冻结模型、开发选择和中断suite
spra_musique_joint_focus_v1/           # 可选：读取其中已有的原记录重核收据；不运行其策略
spra_musique_n16_r4_resume_v1/          # 本次新增目录
```

不覆盖上述原包；不执行stage/run_apply/Pod restart；不再运行原54格开发扫描，不运行原`run_confirm.sh`或N64 `run_main.sh`。

默认旧suite：

```text
../spra_musique_d0_batching_v1/runs/D0_BATCH_CONFIRM_20261010T123919Z_df416da6
```

当前构建环境没有该suite的完整原生记录，因此不能替服务器预先认证旧A。程序会在服务器上完成必须的统一验收。

## 二、CPU上传

将zip放到CPU服务器`/home/wmy/paper/sci/`，上传到GPU39：

```bash
cd /home/wmy/paper/sci
scp -P 8822 -i /home/wmy/ustc87 \
  spra_musique_n16_r4_resume_v1.zip \
  wqx@10.18.2.128:/home/wmy/sci/spra_paper_experiments_github/
```

外层zip SHA256见交付消息及同名`.zip.sha256`；内部`SHA256SUMS`由`run_checks.sh`验证。

## 三、GPU39一个入口完成检查、复用、补齐与归档

确保没有其他实验运行。

```bash
conda activate spra-exp
(
  set -euo pipefail
  cd /home/wmy/sci/spra_paper_experiments_github
  unzip -n spra_musique_n16_r4_resume_v1.zip
  cd spra_musique_n16_r4_resume_v1
  mkdir -p logs
  STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
  bash run_checks.sh 2>&1 | tee "logs/checks_${STAMP}.log"
  bash run_resume.sh 2>&1 | tee "logs/resume_${STAMP}.log"
)
```

不必先运行独立审计或回传一份日志等待批准。入口内部按以下顺序推进：

1. 只读验证原D₀、Mixed1024、模型、先验、开发选择与原suite清单。
2. 查找已有且被哈希覆盖的尾块修正重核收据。匹配则复用；否则对**已有**相关原生记录执行同一个修正检查器。任何无法解释的差异仍停止。
3. 把可复用4/s原始记录复制到新suite的`imported/.../raw/`，原文件不改写。
4. 本地服务gate与当前环境检查；正常静态输入准备时，使用`/tokenize`、必要的`/detokenize`确认旧请求对应同一个原生模板及文档。它们不产生模型输出。
5. 为旧三格生成独立的接受收据；缺失的旧A语义proof不会被伪装成当时已经记录过，而是标注为基于旧token数组和冻结输入的重建。
6. 每个新增执行段先做固定8个普通服务、4个相同schema的JSON预热请求，单独保存。
7. 只执行4/s中尚未执行的条件，最后统一计算12格结果并归档。

若旧Block1三格均可复用，应看到：

```text
N16_R4_READY=... saved_conditions_revalidated:3, new_measured_conditions_pending:9
N16_R4_CONDITION_REUSED=...   # 三条；其JCT未重新测量或扣时间
N16_R4_RUN_PLAN=... reused:3, pending:9
RESUME_WARMUP_COMPLETE=True REQUESTS=12 MEASURED=False
N16_R4_CONDITION_ACCEPTED=... # 九条正式新条件
N16_R4_RESULT=...
CLEANUP=...
N16_R4_ARCHIVE=...           # 最终zip及SHA256
```

实际输出中的C仍沿用原标签`D0-Mix`；`D0-Adaptive`是同次执行的别名，不重复计数。

继承执行器会打印`CONDITION_DONE`及质量明细`TYPED_RESPONSE`；复用旧记录时也会打印事后评分。**主结果以`N16_R4_CONDITION_REUSED`、`N16_R4_CONDITION_ACCEPTED`和`N16_R4_RESULT`为准。**原始的旧`native_next_batch_matches`值保持不改，修正验收使用明确标注的`independent_batch_matched/checked`。

若默认旧suite位置不同，显式传入原目录，不重新建立实验：

```bash
bash run_resume.sh --prior-suite /实际保存的/D0_BATCH_CONFIRM_原目录
```

## 四、严格保持原顺序

| Block | 原种子 | 问题切片 | 方法顺序 |
|---:|---:|---|---|
| 1 | 200201 | 0:16 | D → C → A |
| 2 | 200202 | 16:32 | D → A → C |
| 3 | 200203 | 32:48 | A → D → C |
| 4 | 200204 | 48:64 | A → C → D |

不重新均衡这12格的顺序；本轮是对原方案的切片续跑。优先4/s改变了全局执行次序，程序明确保存这一点。原2/s和8/s条件保留已执行/未执行状态，不能声称原36格已全部完成。N64结果不进入本轮均值。

维持原wave函数、4副本、4K上下文与硬总额度、自然EOS、JSON回答协议、真实父输出传递、0.2s动作窗口和所有原守卫。实际输出不强制相同。

## 五、中断恢复

默认再次执行同一入口会使用新suite指针，不新建一套重复实验：

```bash
bash run_resume.sh
```

也可显式指定：

```bash
bash run_resume.sh --resume runs/N16_R4_RESUME_实际目录
```

- 已接受的条件只读校验，不重新生成。
- 新请求已全部完成、仅后处理没有结束：从存档补完，不重新生成。
- 新执行真正未完成：停止且保留attempt。明确需要重试时才添加：

```bash
bash run_resume.sh --resume runs/N16_R4_RESUME_实际目录 --retry-incomplete
```

此开关只允许重试本包新增、确实未完成的attempt。**完整但核对失败的条件、已接受但性能差的条件都不能用它重跑。**新的attempt保留原问题切片和种子，旧失败记录仍归档。

旧记录无法解释或冻结身份改变时，会停止并打印`RECOVERY_BLOCKED_EVIDENCE`路径，不按性能好坏处理，也不自行重跑旧A。准备期被操作系统直接杀死导致拷贝不完整时，同样拒绝发送新请求，不把漏拷贝的旧条件当作未执行条件。

## 六、结果和判断口径

每个完整block计算：

```text
调度收益       = 100*(1 - JCT_D/JCT_A)
batching增量   = 100*(1 - JCT_C/JCT_D)
完整组合收益   = 100*(1 - JCT_C/JCT_A)
```

先逐block计算，再对四个block等权平均。**不将平均调度收益与平均batching增量相乘来制造平均总收益。**绝对节省毫秒、最小/最大值、样本标准差一起给出。

记录`JCT_C < JCT_D < JCT_A`的block数，以及C对A超过10%的block数；不要求每block或每辅助指标都获胜，不因中间达到10%提前停止。

全部四块为主汇总；额外给出Block2–4的描述性汇总，展示此前已经看到的有利Block1对均值的影响。这是敏感性说明，不替代主汇总，也不是新一轮实验。

自动文件：

```text
protocol.json / protocol_receipt.json   # 恢复约定及哈希
frozen/                                # 原模型、先验、清单、选择、原suite头文件
imported/                              # 旧4/s原始记录副本、重核和接受收据
attempts/                              # 新条件，每次attempt独立保存
segments/                              # 每次恢复的环境、输入准备、固定预热、清理
index.json                             # 只包含唯一且最终接受的条件
result.json / REPORT.md                 # 完整配对结果与边界
conditions.csv / paired_gains.csv       # 数据表
archive_receipt.json                    # 最终包校验值
```

每个条件继续保留放置偏离、D₀调度字段一致性、commit回退原因、1024真实prefill/mixed迭代和严格限额候选，以及JCT路径分解。它们用于解释，不假装拥有逐动作反事实。

条件完成不是性能成功；>10%是目标和点估计，不是保证。若两级收益明确，保存C作为当前完整方案；若仅调度有效或仅旧Block1明显有利，照实归档，不自动增加策略或换seed。

## 七、测试范围

见`TEST_RESULTS.txt`及`TEST_SCOPE.json`。本地CPU/mock覆盖原策略绑定、真实spawn、继承client/hook与假引擎、存档验证、九格续跑、中断恢复及归档。没有GPU39上的新实测，也没有替用户预先认证旧A。测试夹具全是合成数据，不是新的MuSiQue性能或质量证据。
