# R5G confirmatory budget-favorable regions

R5F was an exploratory one-repeat-per-state profile. It established:
- best global fixed budget = 2048,
- best fixed budget changes across workload regimes and arrival rates,
- Profiled-Adaptive improves held-out T1 JCT by 3.64% and T2 by 1.49%.

R5G does NOT search a larger grid. It independently confirms four states
selected from the full predeclared R5F grid before R5G execution:
- LPSD λ=6, exploratory winner 4096
- LPSD λ=10, exploratory winner 2048
- LPSD λ=12, exploratory winner 4096
- LPLD λ=10, exploratory winner 1024

The choice is motivated by distinct candidate operating points and large/near-5%
exploratory effects. R5G uses fresh arrival traces, 24 workflows/run, 3 repeats,
and counterbalanced budget order.

All 4 candidate states are retained regardless of R5G outcome. A state is not
discarded because it fails to reproduce a >5% gain.

Correctness: R5G fixes the controlled-result parser to accept comma-formatted
numbers such as RESULT=11,587.2 and uses 1% relative tolerance. Historical R5F
diagnostic fields remain unchanged.

After R5G, only robustly reconfirmed states should be used to define the
heterogeneous confirmatory dynamic trace. That later trace should compare all
fixed budgets against Profiled-Adaptive on held-out arrivals.
