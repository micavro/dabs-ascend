# R6B: Four-replica real workflow scheduling

R6A established four homogeneous RTX 3080 replicas:
- distinct GPUs,
- 4096 KV blocks each,
- prefix caching enabled,
- SPRA v2 telemetry enabled.

R6B isolates scheduling:
- fixed max_num_batched_tokens = 2048 for every replica,
- same real DAGs and arrival trace within a comparison,
- fixed 64 generated tokens for every node (`min_tokens=64`, `ignore_eos=true`),
- three skewed shared-prefix clusters (8/4/4 workflows).

Controlled DAG:
    c1 -> c2 -> c3 --\
    s1 ---------------> join
    s2 --------------/

Methods:
- RR: round-robin.
- EFT: external earliest-finish proxy based on outstanding submitted work and
  measured live running/waiting state.
- Affinity: scheduler-maintained prefix affinity first, then live-load tie break.
  This is deliberately NOT called Preble.
- SPRA: critical-path remaining modulates the tradeoff between live load and
  prefix affinity. High-criticality nodes prioritize load relief more strongly;
  lower-criticality nodes can exploit locality more aggressively.

Important distinction:
`scheduler-maintained prefix_warm` is a routing signal, not an asserted KV hit.
R6B separately matches real backend request IDs and sums actual scheduled
prefill tokens. The prompt-token minus scheduled-prefill-token quantity is
reported only as an estimated prompt-compute saving signal.

Run smoke first (4 measured conditions). If all 16 workflows complete for every
method and backend request matching is good, run confirm (16 measured
conditions, 4x4 counterbalanced order).

This is a controlled systems mechanism experiment. Public workflow validation
and exact published baselines (e.g. Preble) remain separate subsequent steps.
