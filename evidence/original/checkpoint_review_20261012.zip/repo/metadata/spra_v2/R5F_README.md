# R5F: workload-state x arrival-rate profiling and profile-guided adaptive batching

Motivation from R5D/R5E:
- Adaptive was not uniformly better in the homogeneous R5D workload.
- In R5D Block 2 Adaptive had a small JCT advantage over both fixed settings,
  while Blocks 1 and 3 did not.
- R5E showed that fixed-budget preference depends on workload shape:
  long-prefill/long-decode consistently favored 1024 by ~3.7% JCT, while the
  other regimes were weaker or unstable.
- Therefore the next question is not "can one reactive controller always win?"
  but "does the best batching budget vary systematically with workload state
  and arrival rate?"

This package has two experiments.

## A. R5F-Profile
Predeclared full grid:
- regimes: short_balanced, long_prefill_short_decode, long_prefill_long_decode
- arrival rates: 4, 6, 8, 10, 12, 14 workflows/s
- fixed budgets: 1024, 2048, 4096
- 8 workflows per state
- 54 measured runs total

All three budgets at one state use the identical pre-generated jittered arrival
trace. Budget order is rotated. Every state is reported; no state is dropped
because its gain is small.

A mapping `(regime, rate) -> budget` is then selected using minimum mean workflow
JCT on the profile trace. The best global fixed budget is selected by mean
state-normalized JCT, giving each state equal weight.

## B. R5F-Dynamic held-out
Two held-out dynamic traces are generated using different arrival traces.
Each trace contains three 1-second load phases with rates 4, 10, and 14 wf/s
and changing workload regimes.

Compare:
- Best-Global-Fixed: one budget for the whole dynamic trace.
- Profiled-Adaptive: knows the current workload regime and current phase arrival
  rate and applies the profiled budget at the phase boundary.

Unknown-distribution online load inference is explicitly out of scope here.
This is profile-guided/load-aware adaptation.

## Correctness protocol fix
R5D's 108/108 failures were `missing_branch_result_marker`: the marker was at
the end and the response truncated first. R5F requires `RESULT=` and `FINAL=`
on the FIRST line, while keeping the reasoning/output workload afterwards.
Diagnostic tolerance is 1% relative error for this controlled math workload.

## Interpretation
A >5% gain is a useful target effect size, not a criterion for selecting which
states to show. The complete predeclared grid must be retained.

R5F remains a controlled-workflow development experiment. Multi-workload public
benchmarks and real request scheduling are subsequent stages.
