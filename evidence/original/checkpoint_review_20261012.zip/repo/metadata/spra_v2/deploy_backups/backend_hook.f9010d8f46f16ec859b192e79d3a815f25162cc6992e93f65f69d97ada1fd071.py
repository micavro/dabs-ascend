"""Experimental instrumentation for the *inspected* vLLM 0.6.3 scheduler.

Not a supported vLLM API. Changes only the existing total per-iteration token
budget, never above the startup allocation. Does not implement SPRA or SOTA.
All experimental policies use this same hook. Host step time is NOT GPU time.
"""
from __future__ import annotations
import functools
import hashlib
import inspect
import json
import os
from pathlib import Path
import time

ROOT = Path(os.environ.get('SPRA_E1_ROOT', '/spra-e1'))
CONTROL = ROOT / 'control.json'
POD = os.environ.get('POD_NAME', '')
ALLOWED = (512, 1024, 2048, 4096)


def atomic_json(path: Path, data: dict) -> None:
    tmp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(data, f)
    tmp.chmod(0o644)
    os.replace(tmp, path)


def install() -> None:
    from vllm.core.scheduler import Scheduler
    from vllm.engine.llm_engine import LLMEngine
    from vllm.sequence import SequenceStatus
    if getattr(Scheduler, '_spra_e1_installed', False):
        return
    if not POD.startswith('spra-vllm-'):
        raise RuntimeError('E1 requires POD_NAME from the Kubernetes Downward API.')
    chunk_src = inspect.getsource(Scheduler._schedule_chunked_prefill)
    if 'self.scheduler_config.max_num_batched_tokens' not in chunk_src:
        raise RuntimeError('Unrecognized scheduler: budget hook is not compatible.')
    # Check signatures rather than trusting an image tag that logs version=dev.
    if list(inspect.signature(Scheduler.schedule).parameters) != ['self']:
        raise RuntimeError('Unrecognized Scheduler.schedule signature.')
    src_path = Path(inspect.getfile(Scheduler))
    original_init = Scheduler.__init__
    original_schedule = Scheduler.schedule
    original_step = LLMEngine.step
    data_dir = ROOT / 'backend'
    data_dir.mkdir(exist_ok=True)

    @functools.wraps(original_init)
    def init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        cfg = self.scheduler_config
        if not cfg.chunked_prefill_enabled or cfg.is_multi_step:
            raise RuntimeError('E1 requires chunked prefill and num_scheduler_steps=1.')
        if int(cfg.max_num_batched_tokens) != 4096:
            raise RuntimeError('E1 must start with token allocation ceiling 4096.')
        if int(self.cache_config.block_size) != 16:
            raise RuntimeError('E1 configuration requires block_size=16.')
        for attr in ('get_num_free_gpu_blocks',):
            if not hasattr(self.block_manager, attr):
                raise RuntimeError('Cannot observe KV blocks: missing ' + attr)
        self._e1_ceiling = int(cfg.max_num_batched_tokens)
        self._e1_mtime = None
        self._e1_control = {'case': 'bootstrap', 'token_budget': 4096}
        self._e1_seq = 0
        self._e1_row = None
        self._e1_written = -1
        self._e1_last_write_ms = 0.0
        self._e1_f = (data_dir / f'{POD}.{os.getpid()}.jsonl').open('a', buffering=1)
        self._e1_base = {
            'pod': POD, 'pid': os.getpid(),
            'scheduler_sha256': hashlib.sha256(src_path.read_bytes()).hexdigest(),
            'scheduler_file': str(src_path),
            'hook_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'num_gpu_blocks': int(self.cache_config.num_gpu_blocks),
            'block_size': int(self.cache_config.block_size),
            'max_num_seqs': int(cfg.max_num_seqs),
            'chunked_prefill': bool(cfg.chunked_prefill_enabled),
            'prefix_caching': bool(self.cache_config.enable_prefix_caching),
            'nvidia_visible_devices': os.environ.get('NVIDIA_VISIBLE_DEVICES'),
            'cuda_visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES'),
        }
        atomic_json(data_dir / f'{POD}.status.json', dict(self._e1_base,
            case='bootstrap', token_budget=4096, iteration=0, running=0,
            waiting=0, swapped=0, last_update_unix=time.time()))
        self._e1_f.write(json.dumps(dict(self._e1_base, event='metadata')) + '\n')
        print('SPRA_E1_HOOK_READY ' + json.dumps(self._e1_base), flush=True)

    @functools.wraps(original_schedule)
    def schedule(self):
        hook_start = time.perf_counter()
        # File is atomically replaced by the client; read only when its version changes.
        stat = CONTROL.stat()
        version = (stat.st_mtime_ns, stat.st_size)
        if version != self._e1_mtime:
            ctl = json.loads(CONTROL.read_text())
            budget = ctl.get('token_budget')
            if type(budget) is not int or budget not in ALLOWED:
                raise RuntimeError(f'Invalid E1 budget: {budget!r}')
            if budget > self._e1_ceiling or budget < self.scheduler_config.max_num_seqs:
                raise RuntimeError('Budget exceeds startup limit or is below max_num_seqs.')
            if budget % self.cache_config.block_size:
                raise RuntimeError('Budget must be a multiple of KV block size.')
            case = ctl.get('case')
            if not isinstance(case, str) or not case:
                raise RuntimeError('Control file must include a nonempty case ID.')
            self._e1_control = dict(case=case, token_budget=budget)
            self._e1_mtime = version
        self.scheduler_config.max_num_batched_tokens = self._e1_control['token_budget']
        before = time.perf_counter()
        result = original_schedule(self)
        after = time.perf_counter()
        if not isinstance(result, tuple) or len(result) != 3:
            raise RuntimeError('Unrecognized Scheduler.schedule return type.')
        _, out, _ = result
        if out.num_batched_tokens > self.scheduler_config.max_num_batched_tokens:
            raise RuntimeError('Observed batch exceeds selected token budget.')
        prefill_tokens = 0
        decode_seqs = 0
        groups = []
        for scheduled in out.scheduled_seq_groups:
            g = scheduled.seq_group
            seqs = g.get_seqs(status=SequenceStatus.RUNNING)
            is_prefill = bool(g.is_prefill())
            n = int(scheduled.token_chunk_size) * len(seqs)
            if is_prefill:
                prefill_tokens += n
            else:
                decode_seqs += len(seqs)
            groups.append({'id': g.request_id, 'prefill': is_prefill,
                           'scheduled_tokens': n, 'num_sequences': len(seqs)})
        total = int(self.cache_config.num_gpu_blocks)
        free = int(self.block_manager.get_num_free_gpu_blocks())
        self._e1_seq += 1
        self._e1_row = {
            'event': 'iteration', 'pod': POD, 'pid': os.getpid(),
            'iteration': self._e1_seq, **self._e1_control,
            'scheduled_tokens': int(out.num_batched_tokens),
            'scheduled_prefill_tokens': prefill_tokens,
            'scheduled_decode_sequences': decode_seqs,
            'scheduled_prefill_groups': int(out.num_prefill_groups),
            'running_after_schedule': len(self.running),
            'waiting_after_schedule': len(self.waiting),
            # Capacity minus reclaimable/free blocks, not total persistent cache residency.
            'kv_in_use_blocks_after_schedule': total - free,
            'kv_capacity_blocks': total,
            'preempted': int(out.preempted),
            'scheduler_cpu_ms': (after - before) * 1000,
            'hook_prepare_ms': (before - hook_start) * 1000,
            'trace_write_previous_ms': self._e1_last_write_ms,
            'calls': groups,
        }
        return result

    @functools.wraps(original_step)
    def step(self, *args, **kwargs):
        t0 = time.perf_counter()
        result = original_step(self, *args, **kwargs)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        for scheduler in self.scheduler:
            row = getattr(scheduler, '_e1_row', None)
            if row is None or scheduler._e1_written == row['iteration']:
                continue
            row = dict(row)
            row['engine_step_host_wall_ms'] = elapsed_ms
            row['running_after_step'] = len(scheduler.running)
            row['waiting_after_step'] = len(scheduler.waiting)
            row['swapped_after_step'] = len(scheduler.swapped)
            t1 = time.perf_counter()
            # Synchronous logging is deliberate and identical for all E1 cells.
            # Quantify its cost; this is not assumed free.
            scheduler._e1_f.write(json.dumps(row, separators=(',', ':')) + '\n')
            atomic_json(data_dir / f'{POD}.status.json', dict(scheduler._e1_base,
                case=row['case'], token_budget=row['token_budget'],
                iteration=row['iteration'], running=row['running_after_step'],
                waiting=row['waiting_after_step'], swapped=row['swapped_after_step'],
                kv_in_use_blocks=row['kv_in_use_blocks_after_schedule'],
                engine_step_host_wall_ms=elapsed_ms,
                last_update_unix=time.time()))
            write_ms = (time.perf_counter() - t1) * 1000
            scheduler._e1_last_write_ms = write_ms
            if write_ms > 5:
                print(f'SPRA_E1_TRACE_SLOW write_ms={write_ms:.3f}', flush=True)
            scheduler._e1_written = row['iteration']
        return result

    Scheduler.__init__ = init
    Scheduler.schedule = schedule
    LLMEngine.step = step
    Scheduler._spra_e1_installed = True
