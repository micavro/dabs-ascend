# R6H Global-DAG + R7B batching compatibility

R6G fixed intra-workflow atomic ready-set release, but it still planned each
workflow independently. The simulator's `State.central()` instead exposes all
ready, unassigned calls across all workflows to one global planner. R6H makes
that final structural correction.

## R6H scheduler

- A deterministic 10 ms central scheduling epoch matches the simulator's
  `recheck=0.01`.
- All ready/unassigned requests across workflows are planned together.
- The EFT-like reference plan and every candidate are scored against the
  complete global frontier plus currently active workflows.
- Candidate groups are workflow/prefix groups; width <=3 in this controlled DAG.
- Each group is fully enumerated (4^width) while all other frontier assignments
  remain part of the complete candidate plan.
- The objective is sum of predicted remaining workflow completion times.
- Execution cost uses per-replica calibration on all four RTX 3080 GPUs:
  prefill slope, decode slope, and concurrency curves at 1/8/16/24 requests.
- Candidate evaluation uses a processor-sharing rollout to approximate vLLM
  continuous batching instead of R6F's serial-backlog sum.
- Prefix locality uses exact token longest-common-prefix over scheduler history.
- Batching is frozen at 2048 during R6H.

R6H uses the exact R6D arrival seeds at rates 8 and 12, four blocks each.
Only the new Global-DAG method is run (8 measured conditions). Existing
RR/EFT/Affinity/SPRA/Preble/R6F/R6G aggregates are read for comparison.

### Stop rule

R6H is the final scheduler fidelity round. Do not tune another affinity margin,
criticality weight, or coalescing window after seeing R6H outcomes. If a
request-locality baseline remains stronger on this homogeneous long-prefix
real workload, preserve that result and use the simulation for the broader
joint-search evidence.

## Why real Preble can outperform its simulation result

Do not force method rankings to match across experiments. The simulation and
real system have different system regimes. The real setup has four homogeneous
4096-block replicas and a controlled workload where each workflow has one root
followed by six descendants with a large shared prefix; Preble-E2 therefore
exploits six of seven nodes per workflow. The simulation includes different
replica/capacity conditions, a global central frontier, and iteration-level
rollout. Rankings are empirical outcomes, not invariants.

## R7B batching compatibility

The R5 adaptive-batching policy is not directly portable:
- R5 was a single-replica, different fan-out workload;
- R6H is a four-replica DAG system;
- routing changes each replica's local request process and prefill/decode mix.

After R6H is frozen, R7B runs an exploratory paired fixed-budget matrix:
- global arrival rate: 8, 12 workflows/s;
- burst/task count: N=16, 32;
- global budget: 1024, 2048, 4096;
- one fresh trace per (rate,N), shared across the three budgets;
- frozen Global-DAG scheduler;
- 12 measured conditions.

A cell is called `meaningful` only if its best budget beats the second-best by
at least 3%. A joint adaptive controller is considered only when meaningful
cells show different best budgets; those cells must then be confirmed with
repeats. Otherwise scheduling and adaptive batching remain separately
validated mechanisms.

Current backend control is still one global token budget shared by four pods.
A true simulator-style joint controller with beta_r per replica requires a
per-pod token-budget hook and should only be implemented if R7B justifies it.

## v2 implementation-fidelity correction

R6H-v1 exposed two implementation problems that violate the simulator's
candidate-comparison contract:

1. `evaluate()` re-read all four status JSON files for every candidate.
   Candidate A and candidate B could therefore be evaluated against different
   live states inside the same planner epoch.
2. Per-replica calibration used one sample per point, allowing transient
   calibration noise to systematically bias routing toward one nominally
   identical RTX 3080.

R6H-v2 changes no routing objective, search space, scheduling epoch, DAG,
arrival trace, or batching budget. It only:
- takes one immutable live-state snapshot per `plan()` call;
- precomputes all `(request, replica)` prefix matches and base-service costs
  once per snapshot;
- performs candidate evaluation entirely in memory;
- uses median-of-3 calibration for prefill, decode, and concurrency points;
- reports raw calibration samples and the max/min replica base-score ratio.

This is an implementation-fidelity fix, not post-hoc score tuning.
R6H-v2 is the final scheduler run. After it, freeze scheduling and only then
run the R7B batching compatibility matrix.
