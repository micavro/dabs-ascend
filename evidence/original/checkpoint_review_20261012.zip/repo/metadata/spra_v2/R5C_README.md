# R5C: audit + controlled adaptive-actuation pressure probe

Why this exists:
- R5B Fixed-4096 ran first after the pod restart and is not a fair causal
  comparison against later warm runs.
- R5B Adaptive-Budget observed only a few mixed iterations and no waiting
  backlog, so its two-consecutive-iteration hysteresis never switched.
- Client SSE chunks contained multiple completion tokens; zero single-token
  ITL samples were observed.

R5C has two parts.

1. `r5b_audit.py` is read-only. It reports workflow diagnostics, controller
   reasons, stream delta-token histogram, and server-observed per-request
   decode-step intervals from the existing backend telemetry.

2. `r5c_adaptive_pressure.py` is a mechanism probe only. It runs 12
   pre-generated branch=5 controlled workflows at 120 ms arrival gaps after one
   warmup workflow. It runs Adaptive only. It is designed to test the causal
   chain runtime state -> controller decision -> control file -> actual budget.

The controller does NOT confirm on polling repetitions. It requires two real
competition observations within 16 new scheduler iterations. Neutral decode-only
iterations do not erase recent competition evidence; stale evidence expires.

Do not use R5C as a performance comparison against fixed budgets. Once actuation
is verified, a separate counterbalanced repeated experiment should compare
Fixed-1024, Fixed-4096 and Adaptive.
