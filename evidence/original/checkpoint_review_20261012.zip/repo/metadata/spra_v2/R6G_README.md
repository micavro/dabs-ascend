# R6G DAG-Plan

R6F is preserved as a diagnostic negative result, not a paper result. Its
serial-backlog predictor produced only ~0.03% predicted Phi improvements and
large replica imbalance, while real JCT improved only ~1.5–2% vs RR.

R6G changes the execution model and release semantics rather than tuning a
score:
- dependency releases are atomic planner events;
- after root, {c1,s1,s2} are presented to the planner together;
- the planner enumerates all assignments for the ready set (max 4^3 = 64);
- candidate cost uses a measured concurrency-slowdown curve from this exact
  Qwen2.5-1.5B / RTX3080 / vLLM system;
- existing active workflows are included in the workflow-level Phi objective;
- prefix reuse comes from exact token LCP over scheduler-maintained histories;
- batching is fixed at 2048.

Calibration before measured runs:
- single-request prefill/decode slopes;
- concurrency levels 1,8,16,24 on one homogeneous replica;
- unique calibration prefixes prevent APC contamination.

R6G reuses the exact R6D arrival seeds at rates 8 and 12, four blocks each.
Only DAG-Plan is newly measured (8 runs). Frozen R6D/R6E/R6F aggregates are
read for comparison.

Stop rule:
After R6G, freeze the scheduler result. Do not tune another margin or score.
If R6G still cannot beat request-locality baselines on this real workload,
report that controlled real-system result and rely on the simulation for the
large-scale joint-search evidence.

Adaptive batching:
Do not run the old R7A probe until R6G is frozen. The R5 policy is not portable
because it was profiled on a different, single-replica workload. After R6G,
run a new fixed-budget sensitivity probe under the frozen scheduler. Only if
the best budget changes materially across real DAG load states should a joint
scheduler+batching controller be built.
