# R6F — Real DAG-Joint scheduler + R7A batching compatibility probe

## Why R6F exists

The simulator's Ours is not a per-node weighted score. It optimizes a complete
workflow-level plan:
1. build a common EFT reference plan;
2. predict completion for the visible frontier;
3. add downstream DAG tails and compute relative slack;
4. group ready calls by workflow/prefix;
5. compare incumbent, concentrated and greedy-split routing candidates;
6. evaluate every complete candidate with workflow objective Phi;
7. accept only a strict predicted Phi improvement.

The earlier real SPRA used a local weighted score. R6D confirmed that it beats
RR/EFT but loses to pure Affinity. R6F therefore changes the decision level,
rather than tuning another weight.

R6F keeps batching fixed at 2048 and reuses the exact R6D arrival seeds for
rates 8 and 12. Only DAG-Joint is newly run (8 conditions). Frozen R6D and
R6E-Preble aggregates are read for comparison.

The real planner uses a lightweight visible-state model:
- server-side vLLM tokenization before measured execution;
- locally calibrated prefill/decode ms per token;
- scheduler-maintained exact token-prefix history;
- visible active work plus measured waiting state;
- downstream tail and relative slack;
- workflow-level Phi = sum of predicted remaining workflow completion times.

No future arrivals or realized future output lengths are used.

## R7A: can R5 adaptive batching be combined directly?

No. The original R5 adaptive-batching profile was learned on:
- one replica,
- a different fan-out workload,
- different prompt/output shape,
- a different relation between workflow arrival rate and per-replica pressure.

R6 uses four replicas and routing changes each replica's local arrival process.
Therefore the old `(regime, arrival-rate) -> budget` map is not portable.

After R6F is frozen, R7A runs a small compatibility probe on the exact
four-replica DAG workload:
- rates 8,12;
- budgets 1024,2048,4096;
- two fresh arrival traces/rate;
- DAG-Joint scheduler frozen;
- 12 measured conditions.

If the best budget changes meaningfully across load states, proceed to a joint
scheduler + adaptive-batching experiment. If not, keep scheduling and adaptive
batching as two separately validated mechanisms. Do not force a joint claim.

Current backend control is global across all four replicas. A true per-replica
joint optimizer, like the simulator's per-replica beta vector, would require a
later hook extension with per-pod token budgets. Only do that if R7A shows that
budget adaptation is useful on the R6 workload.

## v2 transport robustness

R6F v1 could abort the entire suite on a transient HTTP transport ReadError
while already-issued server requests continued running. v2 makes each measured
condition atomic:

- endpoint health preflight before each attempt;
- no in-place request retry is counted as a valid measurement;
- any transport/condition failure invalidates the whole attempt;
- remaining client tasks are cancelled and awaited;
- server telemetry is polled until all four replicas return to running=0,
  waiting=0;
- the failed attempt is written as INVALID_*.json;
- a new cache epoch is used on the next attempt;
- only a complete 32-workflow / 224-node attempt is accepted into aggregate data;
- maximum three attempts per condition.

This preserves scientific validity better than per-request retries, which could
double-execute a request whose response socket failed after server acceptance.
