# R5A / R5B: ParallelQA-derived Real Adaptive Batching

This package is the first SPRA v2 real-system component experiment.

## What is public benchmark material?
Two fixed public ParallelQA examples are bundled:
- task 63, branch=4
- task 94, branch=5

They come from SqueezeAILab/LLMCompiler at the pinned commit recorded in
`UPSTREAM_SOURCES.json`.

## What is our systems adapter?
The deterministic DAG adapter is ours. It converts each public ParallelQA
question into:
- one local retrieval tool node per branch,
- one real LLM branch node per retrieved fact,
- one real LLM join node after all branches.

This is intentionally separated from the upstream LLMCompiler planner. It is
used to stress workflow serving without confounding planner-quality failures.

## Offline facts
`local_facts_trenches.json` is a frozen local snapshot. No experiment needs
Wikipedia or another international service at runtime.

## R5A
Install SPRA v2 backend telemetry on `spra-vllm-0`, restart only that pod, then
export/validate the two workflow DAGs. No performance result should be claimed
from R5A.

## R5B
Run exactly three development conditions:
1. Fixed-4096
2. Fixed-1024
3. Adaptive-Budget

Adaptive-Budget uses current scheduler iterations. It does not use a future
phase label or a pre-programmed time schedule. It uses a 2-new-iteration
hysteresis.

R5B is a component smoke, not a capacity test or the full SPRA method.
Request scheduling across replicas is intentionally deferred to R6.
