# R6C Pressure Sweep

R6B validated the real four-replica execution path but was too light for a
scheduling comparison: all methods had nearly identical JCT, every replica had
max_waiting=0, and KV occupancy was only about 3%.

R6C changes only the controlled workload pressure and real node heterogeneity.

DAG:
    root -> c1 -> c2 -> c3 --\
      |       s1 -------------> join
      \------ s2 ------------/

The root completes before descendants and establishes a long workflow-specific
shared prefix. Descendants therefore create a real locality-vs-load tradeoff.

Every method executes the identical real work:
root=32, c1=160, c2=128, c3=96, s1=48, s2=48, join=64 generated tokens.
Total = 576 generated tokens/workflow.

Sweep:
- 32 workflows/condition
- arrival rates 4, 8, 12 workflows/s
- RR, EFT, Affinity, SPRA
- 12 measured runs
- KV capacity 4096 blocks on all replicas
- fixed batching budget 2048

The server's vLLM 0.6.3 `/metrics` endpoint is sampled for
`vllm:gpu_prefix_cache_hit_rate`. It is a cumulative server-side block-hit-rate
snapshot, not a per-condition hit counter.

The old R6B `scheduled_prefill_tokens` quantity must NOT be interpreted as
actual GPU prefill compute saved: in vLLM 0.6.3 cached blocks are conveyed
through computed block metadata while logical scheduling can still account for
the prompt tokens.

After this sweep, choose a pressure regime for counterbalanced confirmation.
Do not alter methods based on single workflow outcomes.
