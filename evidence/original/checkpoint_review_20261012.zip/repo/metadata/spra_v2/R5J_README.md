# R5J: Final batching-profile round — sustained decode-heavy bursts

R5I falsified the proposed 4096 short-burst region:
- confirmed_4096_counts = []
- no tested N at lambda=6 produced a stable >=5% 4096 advantage.

Do not search further for a high-budget region.

The remaining useful question is whether the already confirmed 1024-favored
long-prefill/long-decode state becomes stronger under a longer sustained burst.

R5G established at:
- long_prefill_long_decode
- lambda=10
- N=24
that 1024 won all three repeats, but its aggregate JCT advantage over 2048 was
only 2.35% (while its advantage over 4096 was 7.52%).

R5J keeps that systems workload shape and fixes lambda=10, then changes only:
- N=24, 32, 48
- budgets 1024, 2048, 4096
- 3 fresh-trace repeats / Latin-square order
- 27 measured runs.

A strong 1024 region is predeclared as:
1. 1024 wins >=2/3 repeats, and
2. aggregate mean-JCT gain over 2048 >=5%.

This is the FINAL budget-region search round. After R5J:
- if a strong 1024 region exists, run one final held-out Adaptive experiment
  combining that region with the already robust 2048 LPSD region;
- otherwise freeze batching results (including the existing 3.64% held-out
  Adaptive gain) and move immediately to R6 real request scheduling.

Controlled-workflow semantic success is not used to filter systems timing.
Public workflow benchmarks will be used later for quality-preservation checks.
