# R5H: Task-count / burst-duration crossover at fixed arrival rate

R5F and R5G reveal that arrival rate is not sufficient to characterize the
batching operating point.

Key observation:
- R5F used 8 workflows/state.
- R5G used 24 workflows/state.
- For long-prefill/short-decode at the SAME arrival rates λ=6 and λ=12,
  exploratory R5F favored 4096, but the longer R5G cohorts no longer did.
- Thus sustained burst duration / workflow count changes the backlog and can
  change the preferred batching budget.

R5H isolates this factor.

Frozen state:
- workflow mode: long_prefill_short_decode
- arrival rate: 12 workflows/s
- workflow count: 8, 12, 16, 24, 32
- budget: 1024, 2048, 4096
- 3 fresh arrival-trace repeats
- Latin-square budget order
- 45 measured runs

The expected scientific question is:
  At a fixed instantaneous arrival rate, does the best batching budget change
  as the burst lasts longer and the system accumulates sustained backlog?

This directly supports a profile-guided adaptive policy that can condition on
known workload size / burst regime; online inference of an unknown distribution
is not required.

Correctness protocol v3:
Earlier controlled prompts used literal placeholders such as RESULT=<number>.
Qwen sometimes copied those placeholders or emitted an expression, making the
diagnostic invalid even when arithmetic appeared in the text. R5H removes
marker placeholders entirely. The first output line must be only a decimal
number; the parser accepts comma-formatted numerals and uses 1% relative error.

R5H reports every count and every budget. >5% remains an effect-size target,
not a filtering rule.

If a robust crossover is confirmed, the next held-out experiment will compare
Fixed-1024, Fixed-2048, Fixed-4096 and Profiled-Adaptive on multi-episode traces
that contain short and sustained bursts at the same arrival rate.
