# R6E — Published Preble baseline + public ParallelQA validation

R6D is frozen. Do not tune SPRA after the confirmatory results.

R6E-A adds a Preble E2 request-level reproduction on the exact R6D workload
and exact R6D arrival seeds. It implements the core published Algorithm 1/2
logic:
- longest shared-prefix match,
- exploit when matched cached tokens exceed the unmatched remainder,
- otherwise explore all replicas,
- choose using recent prompt/decode load, estimated eviction cost, and the
  current request's non-cached prefill cost.

Important naming:
The scripts print/display `Preble`, but the artifact scope is specifically the
request-level E2 policy. It does NOT claim to reproduce Preble's custom local
scheduler, autoscaling, or background rebalancing. State this limitation in the
paper/methods.

Because the original Preble implementation contains hardware/model-specific
time equations for Mistral/A6000, R6E calibrates local prefill/decode
milliseconds per token on Qwen2.5-1.5B + RTX 3080 before the replay. This keeps
the E2 cost dimensions faithful on the current platform.

R6E-A performs only 8 new measured runs: rates 8 and 12, four R6D arrival
blocks each. It compares the new Preble result against the already-frozen R6D
aggregate rather than rerunning 32 conditions.

R6E-B uses the fixed public LLMCompiler ParallelQA task IDs 63 and 94 bundled
in R5A (branch widths 4 and 5). These IDs were selected before the current
scheduling experiments. The adapter is deterministic systems orchestration
derived from public task structure, not the upstream learned planner.
Methods: RR, Preble, Affinity, SPRA.
Three fresh repeats, 16 workflows/run, 12 measured runs total.
Numeric quality is reported but never used to filter latency.

Run order:
1. r6e_preble_replay.py
2. r6e_parallelqa_public.py

## v2 tokenizer portability fix

The host does not need `/models/Qwen2.5-1.5B-Instruct`.
R6E v2 uses the running vLLM 0.6.3 `/tokenize` endpoint.

- R6E-A pre-tokenizes all deterministic controlled prompts before measured time.
- R6E-B pre-tokenizes deterministic branch prompts before measured time.
- ParallelQA join prompts depend on actual branch outputs and are tokenized exactly
  at runtime; this tokenizer-only call is identical across compared methods.
- PyTorch is not required by the client experiment environment.
