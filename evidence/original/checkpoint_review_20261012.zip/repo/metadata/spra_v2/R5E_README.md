# R5E: quality audit + fixed-budget operating-regime map

R5D result:
- online actuation is real,
- but the three methods differ by less than ~1% in aggregate JCT,
- Fixed-4096 is slightly best on this one homogeneous branch=5 pressure workload,
- Adaptive performs one 4096->1024 transition per repeat and then spends most
  iterations at 1024,
- all historical R5D semantic diagnostics are false.

Do not tune Adaptive to win this workload.

Step A: run the read-only quality audit. It reconstructs branch and join text
from existing stream events and classifies why the historical abs<=0.05
diagnostic failed. It reports alternate tolerances diagnostically but NEVER
rewrites historical results.

Step B: map fixed-budget behavior in three predeclared controlled regimes:
1. short_balanced
2. long_prefill_short_decode
3. long_prefill_long_decode

There is deliberately NO Adaptive condition in R5E. We first need evidence that
different runtime regimes prefer different fixed budgets. If 4096 dominates
across the regime map, dynamic token-cap adaptation should not be sold as the
main batching mechanism on this hardware; the next research target should be
batch admission/composition.

Each regime uses two fixed-budget repeats with reversed order:
- repeat 1: 4096 -> 1024
- repeat 2: 1024 -> 4096

Each run uses 8 branch=5 workflows. Prompt/output token usage is measured from
the real responses so the intended regimes are checked empirically rather than
assumed from prompt text.

R5E is a development operating-point map, not a final paper significance test.
