# R5I: Confirm the 4096-favored short-burst region

R5H established a robust sustained-burst regime:
- at lambda=12, N>=16, budget 2048 wins all three repeats;
- at N=16/24/32 the aggregate JCT advantage of 2048 over the next best budget
  is ~7-9% and over 4096 is ~9-11%.

However, R5H did not provide a strong 4096 state:
- N=8 and N=12 showed 4096 winning 2/3 repeats, but the aggregate margin over
  2048 was only about 1%.

R5F previously observed a large 4096 advantage at:
- workload = long_prefill_short_decode
- arrival rate = 6 workflows/s
- N = 8 workflows.

R5I independently tests the short-burst neighborhood at the SAME lambda=6:
- N = 4, 6, 8
- budgets = 1024, 2048, 4096
- 3 fresh-trace repeats
- Latin-square budget order
- 27 measured runs.

A 4096 operating point is called confirmed only if:
1. 4096 wins at least 2/3 repeats, AND
2. aggregate mean-JCT gain over 2048 is at least 5%.

All N values are retained regardless of outcome.

If a robust 4096 region is confirmed, the next experiment can build a
held-out heterogeneous dynamic trace from independently confirmed states:
- short LPSD burst -> 4096
- sustained LPSD burst -> 2048
- long-decode LPLD burst -> 1024

That final experiment will compare Fixed-1024, Fixed-2048, Fixed-4096 and
Profiled-Adaptive on the same new traces.

Controlled-task correctness remains a diagnostic rather than the main systems
metric; R5I does not use semantic success to filter workflows or timing.
