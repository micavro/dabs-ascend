# R6D confirmatory real scheduling

R6C is treated as the development pressure sweep. It established:
- real scheduling sensitivity at 4/8/12 workflows/s,
- Affinity > current SPRA > RR in the development sweep,
- a mechanism problem in the old SPRA criticality modulation.

The old SPRA made high-criticality nodes *less* locality-sensitive. R6C showed
that shared-prefix reuse is highly valuable, so the frozen confirmatory rule is
reoriented around DAG slack:

- critical-path nodes (root,c1,c2,c3,join) protect prefix locality and leave the
  warm replica only when its pressure exceeds the global-best replica by >3.0;
- off-critical side nodes (s1,s2) keep locality only within a tighter 0.75
  pressure margin and otherwise shed load.

Pressure is predeclared as:
  inflight + 0.75*running + 2*waiting + 2*KV_fraction + outstanding_work/1500.

This is frozen before R6D. No post-confirm tuning is allowed.

R6D uses fresh arrivals, two pressure regimes (8 and 12 workflows/s), four
repeats per method, and a 4x4 counterbalanced method order:
RR, EFT, Affinity, SPRA.

Total measured conditions: 32.

Primary metric: mean workflow JCT.
Secondary: P95 JCT, output throughput, critical-path affinity, side affinity,
replica imbalance, max waiting, and scheduling overhead.

After R6D, proceed to exact published Preble integration and public-workflow
validation rather than another custom-score tuning cycle.
