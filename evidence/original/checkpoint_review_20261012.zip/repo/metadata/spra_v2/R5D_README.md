# R5D counterbalanced adaptive-batching development experiment

R5C established real online actuation: the backend applied both 4096 and 1024,
with a controller-triggered transition under observed decode/prefill competition.

R5D now compares performance fairly enough for development:
- 3 blocks
- 3 methods per block
- 9 measured runs total
- one common 4096 warmup workflow before each block
- each method appears once in position 1, 2, and 3.

Orders:
1. Fixed-4096 -> Fixed-1024 -> Adaptive-Budget
2. Fixed-1024 -> Adaptive-Budget -> Fixed-4096
3. Adaptive-Budget -> Fixed-4096 -> Fixed-1024

Each measured run uses all 12 frozen controlled branch=5 workflows at a 120 ms
arrival gap. The Adaptive controller starts at 4096 every run and only uses new
scheduler events.

Metrics:
- mean / P95 workflow JCT
- closed-cohort workflow/s
- correctness-diagnostic success workflow/s
- client-observed output tokens/s
- server-observed per-request decode-step interval
- actual budget histogram / switches
- mixed / competition iterations
- controller overhead.

The server decode-step interval is NOT GPU kernel ITL. It is the interval between
engine-step completion timestamps that include decode work for the same request.

This is still a controlled-workflow development experiment, not the final
multi-workload paper result. No significance test is claimed with n=3 repeats.
