# R3 Real Request-Level Concurrency Probe

This is a small, separate **serving-request replay**, NOT a BFCL score, an
end-to-end agent workflow, a maximum-capacity benchmark, or full SPRA evaluation.
It does not repair or relabel any of the source agent failures.

## Why this limited test exists

The preceding R2PAIR completed both modes, but both applied 4096 for every
iteration, both source agents failed, max running requests was 2, and each
condition had only 11 mixed-prefill/decode iterations. Repeating the same agents
again would mostly repeat tool-error loops without testing concurrent batching.

R3 reuses canonical LLM request payloads already recorded by the fixed R2
condition. It selects 8 evenly spaced chronological indices out of 20 requests:
0, 2, 5, 8, 10, 13, 16, 19. Selection does not use latency, quality, output length,
or relative performance. A selected incomplete API call causes rejection of the
source rather than replacement. Failed AGENT quality is retained in provenance.

Each mode sends these 8 requests at 0.25-second planned intervals. These are
independent arrivals: downstream prompts are frozen recorded inputs and DO NOT
consume fresh responses. Original workflow dependencies are intentionally absent
in this separate request-level test. No tool function is called and no fake tool
timing or workflow score is produced. Generated replies remain unconstrained in
length/content within the original JSON protocol and original max_tokens; actual
outputs and token usage are recorded and compared between modes.

## Unchanged components

- Same served model/endpoint and runtime fingerprint as the successful R2 run.
- Same messages, canonical schema, generation parameters and compatibility fix.
- Same continuous batching, chunked prefill and prefix caching.
- Same fixed-4096 baseline and same original host-pressure feedback controller.
- No threshold retuning, forced switching, package installation, model download,
  server restart, new dataset, or update to prior scripts/results.

The offered workload changes from two sequential agents to up to eight
independent LLM requests. `max_running` is measured; it is NOT guaranteed to be 8.
A controller that continues to choose 4096 is a valid observed outcome, not an
experiment failure and not evidence of an adaptive speedup.

## Scope and limitations

No workflow JCT or workflow throughput is reported. Rates are finite-cohort API
completion and client-received output rates, not saturation capacity. Tool times
remain in the source R2 records; R3 has no tools. TPOT is a client proxy, not exact
ITL; GPU kernel/phase times are not invented. One repeat, fixed condition order,
and existing cache residency do not support causal performance claims. The
request traffic comes from two unsuccessful BFCL agents and is not a
representative successful-agent trace dataset. This subsystem test does not
replace planned public-workflow and full-algorithm evaluation.

## Run on GPU39 only

```bash
conda activate spra-exp
cd /home/wmy/sci/spra_paper_experiments_github
unzip -n spra_real_request_probe_v1.zip
sha256sum -c metadata/real_batching/REQUEST_PROBE_SHA256SUMS
RUN=src/experiments/real_batching/round3_request_probe.py
python "$RUN" selftest
python "$RUN" plan --source runs/real_batching/R2PAIR_20260927T142147Z_eaf9d81d
python -u "$RUN" run \
  --source runs/real_batching/R2PAIR_20260927T142147Z_eaf9d81d \
  --request-replay-only --apply-budget-control
python "$RUN" report
```

Existing R2, R1G, schema compatibility, and their pinned historical dependencies
must still be installed. The new package contains only its two new Python files
and documentation. The tests also reuse the already-installed test_round1g.py
mock fixtures. Host Python is 3.11; service Python remains unchanged.

There are 16 model calls in a successful complete probe, plus local service
health and tokenize calls. No autonomous retry loops. Individual inference
requests retain the existing 45-second safety limit; each condition has a
90-second deadline. HTTP/stream/schema/correlation/control failures stop the next
condition. Uncertain server requests write blocking markers rather than being
silently retried. The old control file is restored only when still owned and the
backend is idle.

## Output

`runs/real_batching/R3REQ_<UTC timestamp>_<id>/` has `plan.json`, the input payload
snapshot and provenance hashes, condition directories, `comparison.csv`, output
comparison and final status. Each condition retains `requests.csv`, `nodes.csv`,
`node_timing_summary.csv`, `observed_token_deltas.csv`, actual backend iterations,
control events and decisions, and both canonical and actual wire payloads. The
existing trace machinery calls its grouping field `workflow_id`; here it is a
replay-request group ID, explicitly marked in the manifest, not a executed agent.

CSV summaries are copied to `data/processed/real_batching/<R3REQ id>/`. The new
pointer is `metadata/real_batching/request_probe_latest.txt`; old R1G/R2 pointers
and source files are not modified.

The offline tests use a mocked local HTTP transport and fixtures, not real Qwen,
LMFE, a serving container, or GPU inference. Eight-request overlap is checked
with asynchronous mock responses. The unchanged pressure controller is exercised
with artificial state solely as a software unit test; this is NOT evidence of
live adaptive actuation or a performance benefit.
