# R1C: audit recorded R1B results without new inference

This add-on reads the completed R1B suite. It makes **zero inference requests**,
uses no live runtime files, does not write `control.json`, does not install
packages, and does not download data. It does not change R1A/R1B code, summaries,
timing records, model answers or scores. New output goes to a separate R1C folder
inside the existing prepared experiment project.

## Why this audit exists

R1B reports `reference_diagnostic=0/69` for every budget. The old diagnostic is
not the official BFCL checker. It compares a serialized state including the
private current directory, and it searches only the current turn's returned
values. BFCL's pinned checker compares public attributes and checks reference
responses against cumulative model responses, with multiplicity. These
differences may explain an old failure, but they do **not** establish that any
of these particular tasks actually passed.

R1C replays every recorded tool call on independently initialized copies of the
pinned official in-memory `GorillaFileSystem`. It checks that parsed LLM output,
recorded tool arguments/results, and saved tool states agree. It reports public
state matching and cumulative-response matching separately, and retains the old
diagnostic alongside the new diagnostic. A mismatch in the recording/replay is
never labelled a passing task.

This is an independently implemented **diagnostic based on documented checker
criteria**, not an execution of the official BFCL inference/evaluation pipeline.
`official_bfcl_score` remains null. No benchmark success-throughput claim is made.

## Frozen dependencies

- Adjacent original `round1_bfcl.py` must have SHA256
  `fccf5e72778d037d03f2f798f5fc6c8e2381624b6545ffaeb9b76441b5349760`.
- The already-downloaded R1A upstream files are verified against their pinned
  Git blob hashes before import. No upstream file is downloaded by R1C.
- Checker semantics were reviewed at Gorilla commit
  `6ea57973c7a6097fd7c5915698c54c17c5b1b6c8`.
- Checker Git blob `34b36715cdfaa4464ba1be137af4d30e85da8efb`.
- Reference: `berkeley-function-call-leaderboard/bfcl_eval/eval_checker/multi_turn_eval/multi_turn_checker.py`.
- Source: https://github.com/ShishirPatil/gorilla/blob/6ea57973c7a6097fd7c5915698c54c17c5b1b6c8/berkeley-function-call-leaderboard/bfcl_eval/eval_checker/multi_turn_eval/multi_turn_checker.py
- Method description: https://gorilla.cs.berkeley.edu/blogs/13_bfcl_v3_multi_turn.html

No model-generated program is passed to `eval` or `exec`. Calls are round-tripped
through the original literal-only parser and original allowlist before invoking
a pinned benchmark method. This replays a benchmark's in-memory environment,
not the host filesystem and not measured tool runtime. Diagnostic replay times
are never used to replace original measured times.

## Run

From `/home/wmy/sci/spra_paper_experiments_github` in the existing `spra-exp` environment:

```bash
unzip -n spra_real_batching_round1c.zip
sha256sum -c metadata/real_batching/ROUND1C_SHA256SUMS
python src/experiments/real_batching/round1c_audit.py selftest
python src/experiments/real_batching/round1c_audit.py analyze \
  --suite runs/real_batching/R1B_20260927T073637Z_25007d7e
python src/experiments/real_batching/round1c_audit.py report
```

Without `--suite`, `analyze` reads `metadata/real_batching/round1b_latest.txt`.
The explicit path is preferable for this result. Every audit gets a new output
folder; original results are not overwritten.

## Outputs

- `task_quality.csv`: all recorded instances, old and new diagnostic, integrity,
  first failing turn, tool-error count.
- `task_quality_summary.csv`: per budget and source task; repeated instances are
  not presented as independent benchmark tasks.
- `task_quality_details.json`: complete per-turn actual calls/answers, reference
  calls, missing response values, public-tree differences and private cwd.
- `diagnostic_examples.md`: first instance of each task at budget 4096, selected
  by instance order rather than outcome; includes all turns.
- `window_accounting.csv`: verifies
  `backlog_start + actual_arrivals - backlog_end = all_terminations`.
  Normal completions and failed terminations are separate. Plan arrivals and
  actual admission events are also separate.
- `workflow_timing_breakdown.csv` and `node_timing_summary.csv`: original
  measured client-clock node durations. Union time is used to expose overlap;
  accumulated node work is not assumed additive in general.
- `batch_execution_summary.csv`: actual batch tokens, near-cap fraction,
  mixed-iteration fraction, maximum running/waiting counts and preemptions.
  Backend records have no absolute time anchor, so these aggregates explicitly
  include warmup and drain; they are not labelled measurement-window metrics.
- `manifest.json`: hashes of consumed source files, audit status, audit program
  hash, and verification that input files did not change during the audit.
- `summary.txt`: compact report, including representative failure evidence.

R1C outputs are saved in `runs/real_batching/R1C_<timestamp>_<id>`; small plotting
files are also copied to `data/processed/real_batching/<same-id>`.

## Interpretation limits

One development repeat and two repeated source tasks do not establish maximum
capacity, a general BFCL success rate, a statistical latency advantage, or
adaptive-batching gains. All four R1B conditions were fixed-budget conditions.
In particular, a larger completion count in a finite window can reflect a
change in boundary backlog rather than a higher sustainable throughput.

The decomposition contains **client LLM request time**, not pure GPU time.
LLM queueing, transport and computation are not separable with the original
hook's available timestamps. Unknown GPU phase times stay null.

The 11 included offline tests use small synthetic in-memory fixtures. They test
replay/recording consistency, private/public state distinctions, cumulative
responses and duplicate counts, failure retention, window arithmetic, interval
unions and source-file immutability. They are not tests on the user's real logs
or the actual server, and no performance result is generated by those tests.
