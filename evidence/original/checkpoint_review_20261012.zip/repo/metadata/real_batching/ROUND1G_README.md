# R1G — exact-schema LMFE request-path repair

This is a new delivery, not an overwrite of any R1F file. R1G uses its own schema,
execution and live modules, and reuses hash-locked R1C/R1D task and audit helpers.
It does not depend on which of the earlier R1F ZIP deliveries was installed.

## Observed failure and uncertainty

The supplied R1F report shows a trivial schema probe completing, followed by two
45-second first-call timeouts and no matching backend iterations. No task tools
ran. This is consistent with preprocessing/guided-decoding preparation delays,
but without server stacks or logs it does not prove an Outlines compiler defect.
A cancelled client request is not confirmation that server preprocessing stopped.
`control_restored=True` means only that the control file was restored.

## Change

- Uses `guided_decoding_backend="lm-format-enforcer"` with the complete typed tool
  schema (all available tools and documented signatures), not a weakened schema.
- vLLM v0.6.3.post1 contains this path and lists lm-format-enforcer==0.10.6 in
  requirements-common.txt. The installed image is still checked by real requests.
- Probes EACH DISTINCT FULL TASK SCHEMA. The same schema is used in task requests.
  Probe messages use unexecuted non-task example calls. No task answers are used,
  and no tools run in probes. Empty arrays do not exercise a branch and fail probe.
- Keeps 45-second per-request timeout. Does not increase max_model_len, scheduler
  ceiling, output cap, workflow step limits, resources, or controller thresholds.
- Records HTTP header arrival, first SSE event, first visible token, full stream
  completion and whether server request lifecycle remains unverified. These are
  client observations, not server compilation time or GPU kernel time.
- First pilot execution failure stops the pilot before the second task. No silent
  decoding backend fallback, dependency install, task replacement or auto-retry.
- A request that ends without server completion acknowledgement creates
  metadata/real_batching/round1g_uncertain_requests.json and blocks a new run.
  Do not delete that marker merely to retry. Resolve/confirm backend lifecycle
  (typically a controlled dedicated-worker restart) and archive the marker as
  evidence before another experiment.

## Controlled backend cleanup before first use

Because the old requests timed out before output, use a fresh dedicated worker
before measuring. Only when no other users/experiments are using spra-vllm-0,
on the existing CPU-control terminal verify its StatefulSet owner, save/read the
old pod logs, and recreate ONLY that pod. Do not scale the StatefulSet, change its
arguments, force-kill the node, or restart all replicas. This package never does
that automatically. Wait for /health on port 8000 before invoking the runner.
Other experiments and their data must remain untouched.

## GPU39 commands (existing project and environment)

```bash
conda activate spra-exp
cd /home/wmy/sci/spra_paper_experiments_github
unzip -n spra_real_batching_round1g.zip
sha256sum -c metadata/real_batching/ROUND1G_SHA256SUMS
python src/experiments/real_batching/round1g_live.py selftest
python -u src/experiments/real_batching/round1g_live.py run --apply-budget-control
python src/experiments/real_batching/round1g_live.py report
```

The runner first validates all exact task schemas, then runs the two original
BFCL tasks. Only if execution, independent quality diagnostic, usage, backend
correlation and restoration checks pass does it run the two existing conditions
CB-Fixed4096 and CB-Feedback. This is the unchanged 69-instance open-arrival plan:
rate parameter 1.0, warmup 20 s, measurement 60 s, bounded drain, one development
repeat. These are protocol bounds, not forecasts of completion time.

No downloads or package installs are made by run/selftest. The inherited pinned
BFCL data prepared in R1A must already exist. Missing LMFE on the server causes
an explicit failure, never an unannounced switch to Outlines or plain text.

## Output

runs/real_batching/R1G_<UTC>_<id>/ contains schema_probe/full_XX, pilot, and only
actually run performance conditions. Raw node/workflow/token/control/backend
records are retained. data/processed/real_batching/<run_id>/ receives CSV copies.
Schema-probe cold client time is reported separately and excluded from task
performance; per-request decoder overhead during tasks stays in end-to-end JCT.
Both conditions use the same decoder, prompt, schemas and quality criteria.
Do NOT pool performance with prior prompt-only/Outlines runs.

CB-Feedback is an engineering feedback prototype changing a real scheduler
budget, not the full SPRA planner or workflow-aware batch admission. Staying at
4096 is permitted. Successful probe does not guarantee model task correctness.
Independent task diagnostic is not an official BFCL score. This repeated two-task
working set is not a representative BFCL evaluation or a maximum-capacity result.

## Validation performed for this delivery

47 local fixture tests and Python 3.11 syntax checks passed. Tests use mocked HTTP
streams and local in-memory tools, NOT an installed LMFE/Outlines decoder,
real Qwen model, vLLM engine or GPU. An attempted optional local installation of
LMFE was blocked by network unavailability, so no real parser-runtime validation
is claimed. The real full-schema probe is therefore required, not optional.

## Primary sources reviewed

https://github.com/vllm-project/vllm/blob/v0.6.3.post1/vllm/model_executor/guided_decoding/__init__.py
https://github.com/vllm-project/vllm/blob/v0.6.3.post1/vllm/model_executor/guided_decoding/outlines_decoding.py
https://github.com/vllm-project/vllm/blob/v0.6.3.post1/vllm/model_executor/guided_decoding/lm_format_enforcer_decoding.py
https://github.com/vllm-project/vllm/blob/v0.6.3.post1/requirements-common.txt
