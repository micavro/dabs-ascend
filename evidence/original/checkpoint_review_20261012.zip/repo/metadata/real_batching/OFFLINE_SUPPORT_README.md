# Offline preparation support v1

This is infrastructure support, not another batching algorithm or experiment version.
It does not repair port ownership, change a live server, erase uncertain-request
markers, or claim that the previous schema failure was caused by the network.

## Existing inputs

Run in `/home/wmy/sci/spra_paper_experiments_github` on GPU39.

```bash
source configs/real_batching/offline.env
python tools/real_batching/offline_bundle.py pack --hash-weights
```

The packer verifies six exact BFCL Git blob hashes and includes the existing local
BFCL files, license, Python experiment/runtime code and offline helper code.
It records full SHA256 hashes of the existing model when `--hash-weights` is used.
It makes no downloads or inference calls and does not read live runtime state.
It excludes experiment results, control files, uncertain-request markers, tokens,
SSH keys, arbitrary home-directory caches, model weights and container images.

The transfer files are under `offline_assets/R1G_LOCAL_<id>/`:
`r1g_assets.tar.gz`, `ARCHIVE_SHA256SUMS`, `manifest.json`.
Copy the first two to GPU40. Upload this support ZIP there first so that the
installer is available. In the incoming directory run `sha256sum -c ARCHIVE_SHA256SUMS`.
Then from the project root run:

```bash
python tools/real_batching/offline_bundle.py install \
  --archive offline_assets/incoming/r1g_assets.tar.gz \
  --model-dir /home/wmy/LLMServing/models/Qwen2.5-1.5B-Instruct
```

An existing different file is not overwritten. Missing/different model files are
reported; no model is downloaded. Use internal transfer of the existing complete
model directory when a node needs it. Preserve the source model and do not replace
files underneath a live server. A real model snapshot must include weight shards,
config, tokenizer and chat-template content, not Git LFS pointers.

Server environment is distinct from client conda. Reuse the installed container
image by digest; do not copy Python 3.11 site-packages into a Python 3.12 container.
The transfer archive is not an OCI-image export and not a pip wheelhouse. AFlow
artifacts remain explicitly NOT STAGED; they are not silently replaced or downloaded.

## Exact CPU-only check inside existing server containers

On CPU-control unpack this same small support ZIP. Run:

```bash
bash tools/real_batching/probe_existing_pods.sh
```

It reads pod/container identity and executes one diagnostic Python process per
existing Ready serving node. If only one serving node exists, it reports one; it
does not deploy a second server. It never creates/deletes/rolls out a Pod. Avoid
running CPU/hash diagnostics during measured performance experiments.

The Python subprocess disables visible CUDA devices, uses the actual installed
vLLM tokenizer wrapper with `local_files_only=True`, constructs the actual LMFE
logits processor for both full schemas, and tests known schema-only token paths
on CPU tensors. It does not load weights or generate model outputs. The schemas
have exactly these hashes from the failed R1G report:

- `multi_turn_base_1`: `3937d1d7f337b2d3f3c723bcb5eef0fd2f5a158e68da9f5ea7a37343f11ef6d5`
- `multi_turn_base_3`: `3bf9b8bf871819103ca1016dd62471eb9bf627b2b641f3b9d74939f8a8f8fd06`

The probe installs a Python audit hook that blocks DNS and INET socket calls in
that subprocess. This is not an OS network sandbox and does not affect the live
serving process or native-code networking. It prints the original exception at
the first failing stage. A bounded faulthandler timer exits only that subprocess.
A PASS establishes only this CPU tokenizer/processor path; it does not validate
HTTP streaming, RPC serialization, GPU execution, or task correctness. Its cache
is process-local and does not warm the live server.

## Applying offline environment to a real server

`source configs/real_batching/offline.env` changes the shell and future children,
not an already-running vLLM process. `kubectl exec ... export` does not configure
PID 1. The flags should be placed in the serving container's startup environment
before a controlled restart after port ownership is resolved. Do not run an
additional launcher on port 8000. Do not automatically `kubectl set env` an entire
StatefulSet: that can roll out multiple replicas. This bundle performs neither.

Keep internal inference endpoints accessible. These library flags are not a
network firewall. No experiment should silently download a missing dependency.

## Port collision

The supplied previous-container traceback ended at `sock.bind` with Errno 98.
That is a local listener collision, not an HTTP download timeout. Current health
200 is not proof of the earlier error cause or of the identity of the listener.
Inspect namespace, node, Pod/container identity and socket ownership; do not use
blanket `pkill`, `fuser -k`, or a second launcher. On host-network Pods, another
host process may own the listener but be invisible in the Pod PID namespace.

## Tests and limits

12 standard-library fixture tests and Python syntax checks were run locally.
The delivery environment does not contain the user's vLLM/LMFE/model runtime;
real CPU-probe execution is deliberately left to the already-installed container.
No GPU measurements have been produced by this support bundle.

Do not commit model weights, image archives, home-directory HF tokens or caches.
Consider ignoring `offline_assets/` and keeping only a reviewed small provenance
manifest in Git. Old experiment data and quality labels remain unchanged.

Sources inspected: vLLM v0.6.3 `lm_format_enforcer_decoding.py` and `tokenizer.py`,
LMFE v0.10.6 `integrations/vllm.py` and `integrations/transformers.py`, and HF
Transformers v4.45.2 offline-installation documentation.
