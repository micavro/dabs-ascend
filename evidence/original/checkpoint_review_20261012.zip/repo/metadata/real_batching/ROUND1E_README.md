# R1E: execution repair and a small real online-budget comparison

Run from `/home/wmy/sci/spra_paper_experiments_github` on GPU39 in the
existing `spra-exp` environment. No new package or model downloads are required.
The current backend must expose `/tokenize` for chat requests.

## What is repaired

The supplied R1D failure report contained two different terminal errors.
One request used 3845 prompt tokens plus a requested 384 output tokens against
an effective context limit of 4096. Another model reply contained prose followed
by a Python call list; the strict parser rejected that entire reply.

R1E uses a compact layout for every available tool's official signature and
per-tool/parameter descriptions. It removes repeated tool-family introductions,
JSON schema boilerplate, and static response-schema repetition. It does not
remove tools, alter the official implementation, hide history, supply reference
answers, change path arguments, or increase the model context limit.

Every generation is preceded by the SAME backend's chat `/tokenize`. The limit
is `min(384, served_context_limit - counted_prompt_tokens - 16)` with a minimum
usable output allowance of 64. Insufficient space stops BEFORE inference. A
truncated answer remains a failure. This output limit is separate from the
scheduler's per-iteration token budget. Tokenization overhead is timed and is
included in workflow JCT in BOTH conditions.

Prose or unsafe/nonliteral function arguments are never extracted and executed.
A strict rejection is logged, zero tools execute from it, and the model receives
at most two format retries per user turn, still within the total eight LLM
attempt limit. Tool errors receive actual error feedback. Correctness is
checked only after model execution. Format mistakes are no longer themselves
mislabeled as corrupted tool logs.

## What the default command does

1. Verify pinned local sources and backend/tokenizer/idle state.
2. Execute the same two BFCL tasks once at fixed real budget 4096.
3. Only if both tasks pass execution, independent post-run task diagnosis,
   request/log accounting and restoration gates, continue automatically.
4. Run two conditions in seeded order: CB-Fixed4096 and CB-Feedback. Each uses
   the same 20-second warmup, 60-second measurement window, rate parameter 1/s,
   seed 98200 and 69-workflow arrival plan (18 warmup, 51 measurement arrivals).
   Each condition first repeats the same two-task fixed-4096 priming operation.
5. Preserve every attempt, exception, tool return, natural output and failed
   condition. Do not silently retry a run, select successful samples, replace a
   failed task, or overwrite historical data.

## Honest controller scope

**CB-Feedback is a new engineering feedback prototype, NOT the paper's full
SPRA optimizer, NOT an Aware batch-selector, and NOT a published SOTA method.**
All batch-selection behavior remains the stock continuous batching scheduler.

The controller reads actual newly recorded backend iterations and queue/KV
status every 0.1 s. It can request 512/1024/2048/4096 by atomically updating the
same legacy control file that the live vLLM scheduler already consumes. It
starts at 4096 and has no forced budget-switch schedule.

A confirmed mixed-host-step pressure signal relative to observed decode-only
host steps, observed preemption, or high observed KV usage can reduce the budget
one step. Recovery/backlog can restore it. Constants, 3-poll confirmation,
0.5-second dwell, and thresholds are recorded in each plan. Stale observations
fall back to 4096. Waiting requests/phase labels are NOT synthesized; future
arrivals, task answers and phase labels are NOT controller inputs.

Host-step time is not GPU kernel time or token ITL. This probe establishes real
online actuation and whether it improves measurements under this working set;
it does not establish a general JCT-optimal policy or a performance claim about
full SPRA. Retaining 4096 for the entire run is legitimate and reported.

The Fixed condition uses the same monitoring/logging path but never changes
its budget. Requested and actually applied budgets are reported separately.
A requested change is not automatically treated as acknowledged/executed.

## Commands

```bash
conda activate spra-exp
cd /home/wmy/sci/spra_paper_experiments_github
unzip -n spra_real_batching_round1e.zip
sha256sum -c metadata/real_batching/ROUND1E_SHA256SUMS
python src/experiments/real_batching/round1e_live.py selftest
python -u src/experiments/real_batching/round1e_live.py run --apply-budget-control
python src/experiments/real_batching/round1e_live.py report
```

Use `--pilot-only` to explicitly stop after the two-task check. The default does
not pause for confirmation if that check passes. `--suite-wall-s` is a stop
limit, not a promised run duration. No concurrent experiments on these backends.

No Pod restart or scheduler-source change is made in this round. The legacy
runtime path is used ONLY as the existing live-control/status/log interface.
New scripts and results stay in the prepared project. A future backend batch
selection implementation must still be loaded explicitly; placing a Python
file in this repository does not install it in the running Pod.

## Files and measurement scope

`runs/real_batching/R1E_*/pilot`, `CB-Fixed4096`, and `CB-Feedback` each contain
workflow/node/payload/stream/parse/tool-state logs, exact error messages,
backend iterations, budget request/observation history, task-quality diagnosis,
CSV summaries, per-workflow timing breakdowns and trajectory signatures.

The suite contains `comparison.csv`, `trajectory_comparison.json`, `plan.json`,
`suite_status.json`, and `summary.txt`. CSV/report copies go into
`data/processed/real_batching/R1E_*/`.

Workflow JCT includes scheduled-arrival lag and context-tokenization overhead.
Window throughput counts actual normal completions, not requests merely sent.
Diagnostic-success throughput uses the post-run independent task diagnosis,
**not an official BFCL score**. Output tokens are real stream-usage increments
at client receipt times, not exact GPU emission times. TPOT is explicitly a
client/request proxy; per-token GPU ITL is unavailable. All model/token/history
changes relative to old R1B mean old and new timings must NOT be spliced.

Both tasks are repeated integration examples, not a representative BFCL sample.
Initial cache residency equality and maximum sustainable throughput are NOT
established. Natural output/trajectory differences are reported, not discarded.

If the pilot fails, the command prints terminal errors AND the first failing
turn's actual/reference evidence after execution. Do not run another large sweep
or treat failed-task latency as successful workflow JCT.

## Validation

26 local offline tests cover exact context-limit arithmetic, no-history-trimming,
strict parsing, bounded format/tool recovery, genuine tool errors, safe replay,
HTTP rejection vs missing GPU logs, token-window counting, backend-log tailing,
real-file control writes, safe restoration, and the automatic three-stage
pipeline with a mock server. These are software tests, not GPU performance data.
Live Qwen task success and live adaptive-controller gains have NOT been measured
in the assistant environment.

## Sources

- BFCL source commit `6ea57973c7a6097fd7c5915698c54c17c5b1b6c8`, same pinned
  local task/tool files used by R1A/R1D.
- vLLM 0.6.3.post1 tokenization request and response contract:
  `https://raw.githubusercontent.com/vllm-project/vllm/v0.6.3.post1/vllm/entrypoints/openai/protocol.py`
- Existing backend hook archived in `src/runtime/joint_e1/backend_hook.py`.
