# R1F — Schema-constrained tool interface and the existing live budget pair

## Scope

R1E reached the existing model and scheduler, had complete usage and intact logs,
but its two-task pilot invoked no tools. Prompt-only Python-list output and
bounded format retries did not produce a successful tool workflow. The supplied
summary does not contain the original rejected LLM text, so this release does
not assert the exact invalid syntax that the model chose.

R1F replaces prompt-only Python syntax with JSON Schema constrained generation
using the existing vLLM v0.6.3-style `guided_json` and `guided_decoding_backend`
request fields. The configured backend is `outlines`. It does NOT change the
model, model context allocation, physical tools, task questions, initial states,
correctness criteria, or batching controller.

This is a BFCL-derived systems integration workload with a modified response
protocol, not a reproduction of the official BFCL model leaderboard. The
post-run state/response check is an independent diagnostic, not the complete
BFCL scorer. Semantic success is NOT guaranteed by a schema.

## Public contract only

The schema is constructed from each task's available official tool input
schemas. It includes every allowed function, required/optional argument names,
JSON types and any explicitly documented enum. It excludes only tools already
excluded by the task. It contains no reference plan, desired next function,
file-path answers, or reference outputs. Arrays permit zero to twelve calls,
preserving the historical twelve-call upper bound. An empty array is allowed,
but does not automatically pass the task diagnostic.

The response representation is:

```json
{"calls":[{"name":"DOCUMENTED_FUNCTION","arguments":{"DOCUMENTED_ARGUMENT":"MODEL_VALUE"}}]}
```

Actual function names/values are chosen by the model under the public contract.
They are decoded with strict `json.loads`, validated without coercion, then
passed unchanged as keyword arguments to the original official Python tool.
There is no `eval`, expression extraction, class-prefix stripping, path repair,
or reference-based automatic correction. Rejected schema output executes no
tools and terminates that workflow as an interface failure.

Tool application errors retain the original bounded model recovery behavior.
Full history is retained. The exact backend `/tokenize` headroom guard remains;
output truncation and insufficient headroom are failures, not successful runs.

## Invocation

Run on GPU39 in the already prepared project and `spra-exp` environment:

```bash
cd /home/wmy/sci/spra_paper_experiments_github
(
  set -euo pipefail
  unzip -n spra_real_batching_round1f.zip
  sha256sum -c metadata/real_batching/ROUND1F_SHA256SUMS
  RUN=src/experiments/real_batching/round1f_live.py
  python "$RUN" selftest
  python -u "$RUN" run --apply-budget-control \
    2>&1 | tee metadata/real_batching/round1f_driver.log
  python "$RUN" report
)
```

The previous R1C/R1D dependencies must still be present and unmodified. Their
hashes are checked by the execution adapter. No new packages, model downloads,
Kubernetes edits or backend restarts are performed by this release.

The runtime root `/home/wmy/sci/spra_core_exp/joint_e1` remains ONLY the live
control/log interface. New code/results live under the prepared project.

## Execution sequence

1. Inspect the real OpenAPI request schema for required guided fields. This is
   a read-only check and fails explicitly if the API does not support them.
2. Under the existing experiment lock and its own fixed-4096 case ID, run one
   non-task schema canary. Its prompt requests plain text, while its schema
   permits only a fixed harmless capability object. This tests operational
   adherence; it is not a correctness benchmark. Save its input/output,
   usage, backend correlation and restoration results separately.
3. Run the same two BFCL tasks once as a fixed-4096 pilot. Require execution,
   task diagnostic, token/log integrity and safe control restoration.
4. If the pilot passes, automatically run `CB-Fixed4096` and `CB-Feedback`.
   Each uses the same two-task priming policy, same schema protocol, fixed
   paired arrival plan, 20-second warmup and 60-second measurement windows.
   There are 69 planned arrivals per condition for the default seed.
5. Keep all task, request, node, tool, schema, usage, queue, batch and controller
   records. No success-based sample replacement or silent retry is performed.

If a schema or task check fails, the pipeline stops with the original LLM
response, usage, terminal error and first failing turn printed inline. No
separate diagnostic script is required. It never feeds reference answers back
to the model to make the pilot pass.

`CB-Feedback` remains the engineering host-step/queue-pressure controller from
R1E. It is NOT the full SPRA planner or workflow-aware batch selection. It may
legitimately retain 4096 throughout the experiment. No forced switching is
introduced to manufacture an adaptive effect.

## Measurement rules and costs

- Exact context tokenization and schema-constrained decoding are applied to BOTH
  conditions. Associated observed delay is included in request/workflow JCT.
- First-use full-tool-schema compilation occurs in the logged pilot/priming
  calls; per-run warm/cache effects must be interpreted using these records.
  Exact cache state equality is not claimed.
- The capability probe has a separate case ID and is excluded from workflow
  performance comparisons. It is included in its own telemetry files.
- Output tokens/s uses real client-received usage deltas in the measurement
  window. It is not a GPU emission timestamp or a maximum capacity estimate.
- Host engine step time is NOT GPU kernel time. Request TPOT proxy is NOT
  token-level ITL. Unavailable fields remain unavailable.
- The two-task repeated working set, single endpoint and one development repeat
  remain limitations. Repeating these tasks is not a full BFCL evaluation.
- 4096 is the retained reference from earlier exploratory data, not a proven
  optimal fixed budget for this changed response protocol.
- Do not merge old Python-format timings with new structured-format timings as
  though only batching had changed. The valid pair is within this new runner.
- Local tests use mock HTTP/model outputs. They do not prove the real Qwen model
  will solve the tasks or that guided decoding improves system performance.

## Outputs

```
runs/real_batching/R1F_<timestamp>_<id>/
  schema_probe/probe_result.json
  pilot/
  CB-Fixed4096/
  CB-Feedback/
  comparison.csv
  trajectory_comparison.json
  summary.txt
```

Each task condition retains `schemas.jsonl`, `payloads.jsonl`, original LLM
`output_text` in `nodes.jsonl`, `parse_events.jsonl`, `tool_states.jsonl`,
`workflows.jsonl`, `stream_events.jsonl`, `backend_iterations.jsonl`,
`controller_decisions.jsonl`, `control_events.jsonl`, errors and quality records.
Plot-ready CSV copies are written to `data/processed/real_batching/<run>/`.

The original archived result directories are never modified. A schema or task
failure is never relabelled as successful performance. The top-level report
now lists the actual performance conditions recorded, rather than implying
that a implemented budget actuator has already been exercised experimentally.

## Upstream references

The API contract used here is the inspected version, not a newer vLLM API:
https://github.com/vllm-project/vllm/blob/v0.6.3.post1/vllm/entrypoints/openai/protocol.py

Tool definitions are pinned by the prior source loader:
https://github.com/ShishirPatil/gorilla/tree/6ea57973c7a6097fd7c5915698c54c17c5b1b6c8/berkeley-function-call-leaderboard

Do not silently translate this into newer `structured_outputs` fields or a
changed runtime without version-specific validation.
