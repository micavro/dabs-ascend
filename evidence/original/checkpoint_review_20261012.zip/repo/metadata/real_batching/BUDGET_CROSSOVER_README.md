# R4 Fixed-Budget Crossover

## Purpose and limits

R3 succeeded operationally, but both methods requested/applied only 4096. Its
latency difference is NOT an adaptive-budget effect. The original controller
requires 4 mixed samples before its latency ratio exists, then 3 qualifying
new-event polls. Starting from empty state, the latency-only path needs at least
6 mixed events under the most favorable ordering. R3 has 4. Preemption and KV
protection are distinct paths and are not ruled out by this count argument.

R4 tests a REAL fixed-budget intervention with the same R3 request content:
4096, 1024, 1024, 4096. Four finite cohorts, each 8 independent requests, at the
original 0.25-second arrival intervals. Total: 32 model requests, plus local
health/tokenization calls. There is no extra priming/warmup cohort. R3/R2 source
files are read-only and are hashed before, during and after the experiment.

This is subsystem calibration on traffic from TWO unsuccessful BFCL agents,
NOT an end-to-end agent/workflow benchmark. There are no tool executions,
no workflow JCT/throughput, no official score, no inference of maximum capacity,
and no full SPRA planner or adaptive controller. No failure is relabelled.
No prompt/decoder/model changes. Fresh natural responses and exact usage are
recorded and compared across all four cohorts.

ABBA order balances position against an approximately linear temporal drift.
It does NOT guarantee equal cache state, equal decoder initialization cost or
eliminate nonlinear carryover. The two repeats and eight request IDs are not
independent workflow trial samples. No significance or causal performance claim
is made automatically. All results, including regressions, are retained.

## Requirements

Run on GPU39 in the already working `spra-exp` Python environment and existing
project. Uses pinned `round3_request_probe.py` and all its existing dependencies.
No package install, Internet asset download, CPU-control action, GPU40 action,
container change, service restart or cache flush is needed.

## Commands

```bash
conda activate spra-exp
cd /home/wmy/sci/spra_paper_experiments_github
unzip -n spra_real_budget_crossover_v1.zip
sha256sum -c metadata/real_batching/BUDGET_CROSSOVER_SHA256SUMS
RUN=src/experiments/real_batching/round4_budget_crossover.py
SOURCE=runs/real_batching/R3REQ_20260927T144503Z_bc19c30b
python "$RUN" selftest
python "$RUN" plan --source "$SOURCE"
python -u "$RUN" run --source "$SOURCE" --request-replay-only --apply-fixed-budgets
python "$RUN" report
```

`plan` audits the previous controller records without live runtime access.
`run` repeats that audit, obtains the existing exclusive experiment lock,
checks the existing schema-compatibility proof, local service health and exact
server fingerprint, and performs the four fixed-budget cohorts.

A condition retains the original 45-second per-request safety bound and a
90-second cohort deadline. The suite stops admitting another cohort after its
360-second limit; bounded cleanup may extend beyond that limit. These are
safety limits, not completion-time promises. Unknown lifecycle/timeout flags
block further runs; HTTP, schema, control, correlation and usage failures stop
subsequent cohorts. External control writers are never overwritten on cleanup.
Never erase a blocking marker or restart automatically to bypass it.

## Outputs

`runs/real_batching/R4CAP_<timestamp>_<id>/` is NEW. Historical latest pointers
are unchanged. The new pointer is
`metadata/real_batching/budget_crossover_latest.txt`.

- `plan.json` and `r3_controller_audit.json`: exact payloads, provenance, old
  controller eligibility and stale observation counts.
- `comparison.csv`: all four cohorts and measured actual caps.
- `within_budget_repeat_summary.csv`: mean and between-repeat spread, not CIs.
- `per_request_budget_comparison.csv`: each identical request's measured
  durations averaged across the two positions per cap; positive change means
  1024 was slower. Not independent workflow replication.
- `output_comparison.json`: all four output hashes and token usages agree or
  differ; no output is substituted from a prior run.
- Each cohort keeps original request/node/wire-payload/control/backend logs.
- `host_stage_timing.csv`: prefill-only, decode-only and mixed iteration counts
  and measured HOST-step durations. Not GPU kernels or causal time allocation.
- `client_stage_timing.csv`: HTTP headers and first visible output on the SAME
  client clock. This does not separate server queue, prefill and constrained
  decoding preparation.

CSV copies go under `data/processed/real_batching/<new run id>/`.
Tokens/s are finite-cohort, client-received output rates from actual usage;
TPOT is a request proxy, not exact token ITL. Missing measurements remain null.

## Local testing

Tests execute mocked local HTTP responses and fake backend records, not real
Qwen, LMFE, GPU, or a container. See BUDGET_CROSSOVER_TEST_RESULTS.txt for actual
Python version and test output. Arrivals are accelerated ONLY in test fixtures.
No model-dependent success or performance benefit is guaranteed by those tests.
