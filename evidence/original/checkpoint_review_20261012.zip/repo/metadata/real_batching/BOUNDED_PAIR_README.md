# R2 bounded-agent budget pair

This is an explicit evaluation-protocol change, not a new semantic repair.
The previous run R1G_20260927T140017Z_6c50d3cc successfully executed both full
schema probes, then failed the first BFCL task at its existing eight-call
per-user-turn limit. The whole suite therefore stopped before measuring
CB-Fixed4096 or CB-Feedback. This extension separates task quality from serving
infrastructure validity. It does not pretend that task quality was repaired.

## Scope

- Two original BFCL tasks, each once per condition: four workflow instances total.
- In each condition their planned arrivals are 0.0 and 0.5 seconds apart.
- Same pinned R1G workflow, prompts, strict parser, canonical schemas, official
  tools and independent post-execution quality check. References are not passed
  to the online workflow function. The known wire-only LMFE fix is reused.
- Same max_steps=8 per user turn, request context guard and natural generation.
- Same existing CB-Fixed4096 and CB-Feedback policy. No forced cap changes.
- The requested methods run in a fixed-seed randomized order, one repeat only.
- No new capability probes or task priming: previous successful HTTP/GPU probes
  and the current CPU proof must match this serving fingerprint.
- No cache reset; identical residency is NOT claimed. This tiny overlapping
  cohort is NOT a saturation/capacity test or paper headline comparison.
- Each condition has a 150-second stopping cap; the suite cap is 360 seconds.
  These are safety limits, not predictions of runtime.

## Failure handling

The exact known errors `RuntimeError: StepLimit:` and
`RuntimeError: UnresolvedToolError:` are retained as bounded task failures.
They no longer abort the *other* task or condition. Normally ended but incorrect
workflows likewise retain diagnostic_pass=False. The original quality gate is
still reported and may remain false. No failed workflow is relabelled success.

All unclassified execution errors, invalid constrained output, HTTP/stream
failures, missing usage/backend correlation, changed fingerprints, external
control writers or unverified request lifecycles stop the suite. Existing
uncertain-request markers are NOT automatically removed or acknowledged.

Original raw errors may contain fatal=True because the *workflow* ended. The
new terminal_classification.jsonl records whether this is a known bounded task
outcome or a condition-level infrastructure failure; raw logs are not edited.

## Metrics and honest interpretation

- terminal_latency: arrival-to-terminal time for failures AND successes;
  this is NOT successful-workflow JCT.
- successful_jct: only workflows completing and passing the unchanged
  independent diagnostic. It is null/NA when there are none.
- diagnostic_success_workflows_s: diagnostic successes per whole-cohort time;
  it is zero for a fully observed, replay-consistent cohort with no successes.
  It is NOT an official BFCL score or official successful throughput.
- all_termination_rate_including_failures: includes failed tasks explicitly;
  it must not be relabelled completed-task throughput.
- client_received_output_tokens_s: uses measured SSE usage increments over
  the cohort. It is not GPU emission timestamps or steady-state capacity.
- TPOT_PROXY: request/client proxy, not token-level ITL or GPU-only time.
- Controller/host-step times are NOT GPU kernel times.
- Node timing and dependency records, actual batches, requested/applied caps,
  quality outcomes and cross-method trajectory signatures are retained.
- paper_performance_claim_eligible is always False for this development cohort.
  Full SPRA and workflow-aware batch selection are still not implemented here.

## Run on GPU39 only

```bash
conda activate spra-exp
cd /home/wmy/sci/spra_paper_experiments_github
unzip -n spra_real_batching_bounded_pair_v1.zip
sha256sum -c metadata/real_batching/BOUNDED_PAIR_SHA256SUMS
python src/experiments/real_batching/round2_bounded_pair.py selftest
python -u src/experiments/real_batching/round2_bounded_pair.py run --apply-budget-control
python src/experiments/real_batching/round2_bounded_pair.py report
```

The default evidence path is the successful-schema R1G run mentioned above.
Missing or stale evidence fails closed; do not fabricate the proof. Use the same
live runtime hostPath, endpoint and experimental lock as previous work. No new
package installation, restart, model download or GPU40 configuration is needed.

## Output

New runs go to runs/real_batching/R2PAIR_*/. Only the new
metadata/real_batching/bounded_pair_latest.txt pointer is written. Historical
R1G directories, source files and round1g_latest.txt remain unchanged.

Each condition stores nodes.csv, workflows.csv, quality.json/CSV,
workflow_timing_breakdown.csv, stream/backend events, canonical/wire payloads,
controller/queue records, terminal classifications, trajectories.json and the
summary. The top level contains comparison.csv, trajectory_comparison.json,
plan.json, suite_status.json and summary.txt. CSVs are mirrored under
 data/processed/real_batching/R2PAIR_*/.

## Validation performed for this delivery

18 local tests passed under Python 3.13.5, using mocked HTTP and deterministic
in-memory fixture tools. Python 3.11 grammar checks passed. Tests cover both
conditions despite incorrect tasks and step-limit loops, strict failure counts,
zero-success metrics, no prompt/answer substitution, pinned code unchanged,
control restoration, external-writer protection, timeout markers, missing
usage/correlation, no forced cap switching and prior-evidence validation.

No real Qwen, GPU, installed LMFE or user-server experiment was executed in
these tests. Local success does not establish model task correctness or any
performance advantage. test_round1g.py from the original R1G delivery supplies
shared offline fixtures; production runs do not import that test module.
