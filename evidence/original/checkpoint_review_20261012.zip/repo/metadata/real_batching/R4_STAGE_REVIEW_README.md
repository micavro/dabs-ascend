# R4 existing-record phase review

No model or API requests. No live runtime access. No package installation.
The reader needs Python 3.9+ standard library only. It does not import project
runners, update pointers, change a controller, or rewrite the R4 results.

The output directory must be NEW and outside the R4 source directory.
Use --suite for the completed R4 result and --out for a new metadata directory.

Outputs:
- client_request_phases.csv: all 32 requests, including short completions.
- client_case_phases.csv: means and nonmissing counts of client-clock intervals.
- backend_host_phases.csv: separate host-step distributions, with sample counts.
- source_sha256.json: hashes checked before and after reading inputs.
- summary.txt: console report.

The former TPOT proxy uses response-return time, not last visible content time.
Both it and a visible-span proxy are included as diagnostics, NOT token ITL.
SSE events need not each correspond to one token. EOS/special tokens may not be
visible. Unknown GPU, backend-queue, and model-stage values remain empty.
Short output <=4 is a descriptive label only: no request is removed or replaced.
Do not add backend host timings to overlapping request intervals.

Test scope: 12 standard-library unit/integration tests using synthetic fixtures,
including a full 4-condition, 32-record read-only export. No real GPU, LMFE,
remote runtime, or user's unuploaded per-request traces were tested. Current
interpreter: 3.13.5. Parsed with Python 3.9 grammar, not
executed under every supported interpreter. All fixtures are not measurements.
