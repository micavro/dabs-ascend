# R1G compatibility repair, no server package changes

## Identified failure

The supplied offline container trace reaches JsonSchemaParser after constructing
its local tokenizer data, then fails because a Pydantic `mode=before` validator
in LMFE 0.10.6 invokes `values.get(...)` on a boolean. The canonical R1G schemas
contain 34 `additionalProperties: false` entries each. This is not a download
failure, token-budget failure or proof of a model tool-reasoning failure.

## What changes

Original R1G source, prompts, allowed tools, parameter schemas and strict client
validation remain untouched. The wrapper supplies a separate wire schema to the
old LMFE decoder. Only `additionalProperties: false` on objects with explicit
`properties` is omitted. Unsupported additional-properties forms fail closed.

THIS IS NOT A GENERAL JSON SCHEMA EQUIVALENCE CLAIM. Removing that keyword would
allow extra keys for a generic standards-compliant validator. The compatibility
path relies on this particular LMFE parser already enumerating keys from its
explicit properties. The CPU check must confirm this with the actual installed
parser. Regardless of generation behaviour, the original canonical schema still
rejects unknown tools/arguments and missing/wrong-type parameters before any
model-specified tool executes. Bool-valued tool arguments such as `ls(a=False)`
are never converted or removed.

## CPU-control

Upload/extract this same zip in:
`/home/wmy/sci/spra_paper_experiments_github`

```
sha256sum -c metadata/real_batching/LMFE_SCHEMA_COMPAT_SHA256SUMS
bash tools/real_batching/probe_lmfe_compat.sh
```

The check uses the existing spra-vllm-0 container, local tokenizer and CPU tensors.
It reproduces the old failure, checks every tool's legal shapes and selected
invalid shapes, and exercises two non-task token-mask paths including EOS.
It blocks Python DNS/INET in that diagnostic process, hides CUDA devices, does
not load weights and does not issue inference requests. This is not kernel-level
network isolation and does not configure the running server's environment.

A small proof file is written to `/spra-e1/lmfe_schema_compat_cpu_proof_v1.json`.
This is the ONLY new file written through the old runtime mount; no control or
source file is changed. On GPU39 it is visible in the existing `joint_e1` host
path. The client copies it into the new project's metadata automatically.
The proof includes the compatibility script hash, schemas, library versions,
model metadata hashes, and the running server fingerprint. A new failed CPU
check replaces any older PASS proof with a failure record.

## GPU39 after CPU PASS

Extract this same zip in the existing project. Do not extract a different build.

```
python tools/real_batching/lmfe_schema_compat.py selftest
python -u tools/real_batching/lmfe_schema_compat.py run \
  --apply-budget-control --acknowledge-known-schema-error
python tools/real_batching/lmfe_schema_compat.py report
```

The last flag is explicit operator acknowledgement of the old R1G pre-stream
schema failure. It accepts ONLY a recorded full-schema RemoteProtocolError with
zero backend iterations and matching canonical schema, after the new CPU proof
and serving-idle checks. The old marker is archived, not deleted; an
acknowledgement record is written. Historical server completion is NOT claimed
or relabelled. Any other timeout/failure marker is left in place and blocks run.

The existing R1G lock and error handling then apply normally. The same full HTTP
schema probes, two-task pilot, CB-Fixed4096 and CB-Feedback run in that order.
No extra budget sweep, benchmark selection, answer substitution or controller
retuning is added. `--pilot-only` is available but is not the default.

This fixes schema construction compatibility; it does NOT guarantee task
correctness, HTTP/GPU compatibility, or an improvement from feedback control.
CB-Feedback is still an engineering feedback prototype, NOT full SPRA or
workflow-aware batch admission. False/nonpositive results remain valid outputs.

## Output and provenance

New runs still use the original R1G timestamped layout and latest pointer:
`runs/real_batching/R1G_...`. Existing run directories are not overwritten.

Each new sub-run contains `schema_compatibility.json` and
`wire_payloads.jsonl`, including the ACTUAL transmitted payload, canonical/wire
hashes, and changed field paths. The older `payloads.jsonl` remains the original
canonical request BEFORE the transport adaptation. Never treat it as the final
wire request without checking the companion log.

All ordinary workflow/node/throughput/backend/controller outputs remain from
the same R1G runner. Within this new comparison both methods use the same
compatibility adapter; do not splice timings with older protocols.

## Tests and limits

Local tests exercise the Python compatibility shim and fixture HTTP pipeline.
The local development environment does not have the user's vLLM/LMFE installed.
No actual model inference was performed here. The compulsory CPU check runs
those installed components on the user container. Its PASS still does not prove
full HTTP/multiprocessing/GPU compatibility; the existing full-schema probes
remain compulsory.

## Primary implementation references

https://github.com/noamgat/lm-format-enforcer/blob/v0.10.6/lmformatenforcer/external/jsonschemaobject.py
https://github.com/noamgat/lm-format-enforcer/blob/v0.10.6/lmformatenforcer/jsonschemaparser.py

No library code, fonts, model weights or credentials are bundled.
