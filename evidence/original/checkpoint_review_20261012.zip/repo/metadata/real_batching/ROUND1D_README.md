# R1D: tool-contract recovery and existing batching-cost diagnostics

## Scope

This package adds three files under `src/experiments/real_batching/`. It does not
change or replace R1A, R1B, R1C, historical data, the serving model, official
GorillaFileSystem implementation, or the backend scheduler.

The R1C report reproduced the logged tool calls without replay mismatches, but
all recorded instances failed the independent public-state/cumulative-response
diagnostic. The shown failures pass nested paths to `mv`/`cp`, whose documented
arguments are bare names in the current directory. This is an agent/tool-contract
failure, not a Python crash in the audit program.

## What changes in the two-task pilot

* Keep the official complete function descriptions and append a generic reminder
  of current-directory semantics. No task-specific filenames, reference actions
  or expected outputs are supplied to the model by this reminder.
* Give explicit failed-tool feedback, continuing in the same user turn.
* Permit one reminder after a model tries to end a turn immediately after a failed
  tool group. The reminder consumes the existing eight-LLM-steps-per-turn limit;
  it does not grant unlimited retries. A second such early termination fails.
* Execute the original model calls against the original tool implementation.
  No invalid path is automatically rewritten and no success result is fabricated.
* Evaluate recorded actions only after all real model calls have finished. Separate
  execution completion, diagnostic task success and log integrity in the summary.

This is an adapted prompted integration harness, NOT BFCL's official inference
handler/scorer. `official_bfcl_score` stays null. Generic prompt/recovery changes
may change token work and must be used identically in every later comparison.
Do not compare the new pilot's latency to R1B as a batching-policy improvement.

## Install in the existing project

```bash
conda activate spra-exp
cd /home/wmy/sci/spra_paper_experiments_github
unzip -n spra_real_batching_round1d.zip
sha256sum -c metadata/real_batching/ROUND1D_SHA256SUMS
python src/experiments/real_batching/round1d_tool_contract.py selftest
```

Requires the unmodified adjacent `round1c_audit.py` and the already-downloaded
pinned BFCL source files prepared by R1A. No new download or package installation.
The offline tests use fixture tools and HTTP responses, not real GPU inference.

## A. Read-only cost extraction, zero GPU requests

```bash
python -u src/experiments/real_batching/round1d_costs.py \
  --suite runs/real_batching/R1B_20260927T073637Z_25007d7e \
  2>&1 | tee metadata/real_batching/round1d_costs.log
```

New output: `runs/real_batching/R1D_COST_<timestamp>_<id>/`, with CSV copies under
`data/processed/real_batching/<same id>/`.

* `budget_cost_summary.csv`: mixed/prefill-only/decode-only iteration counts and
  host engine-step durations, legacy KV-block occupancy, recorded preemptions,
  per-request client decoding-duration proxy.
* `request_decode_observations.csv`: every observed request retained, including
  status, actual output tokens and clearly labeled client timing proxies.

The host step duration is NOT a GPU kernel duration. The per-request proxy is
`(client end - first visible text)/(actual output tokens - 1)` and includes client
and stream effects. Its P95 is the P95 across request averages, NOT token ITL P95.
SSE observation gaps are NOT expanded/interpolated into per-token timestamps.
Missing GPU metrics remain null. Legacy backend records lack absolute timestamps,
so their statistics include warmup and drain, unlike window throughput.
These diagnostics do not retroactively make failed R1B tasks successful.

## B. Only two actual workflows, one fixed-budget condition

```bash
(
  set -euo pipefail
  python -u src/experiments/real_batching/round1d_tool_contract.py run \
    --apply-fixed-budget --wall-limit-s 180 \
    2>&1 | tee metadata/real_batching/round1d_driver.log
  python src/experiments/real_batching/round1d_tool_contract.py report
)
```

The runtime interface remains the current live hook at
`/home/wmy/sci/spra_core_exp/joint_e1`. Only its existing control file is temporarily
set to fixed 4096 while holding the legacy experiment lock. The script first checks
idle state and serving model, then verifies new backend iterations and request-ID
correlation, drains the engine, and restores the previous control bytes. No pod
restart or backend patch is attempted. Do not run other experiments concurrently.
If the engine is busy or control is externally changed, restore is not forced;
inspect the manifest warning instead of starting another run.

Exactly the same two pilot task IDs are used: `multi_turn_base_1` and
`multi_turn_base_3`. No success-based task replacement or repeated automatic trials.
The 180-second wall setting is a stop bound, not a completion-time estimate.

Outputs remain below the prepared project:

```
runs/real_batching/R1D_<timestamp>_<id>/
  manifest.json
  nodes.jsonl / nodes.csv
  workflows.jsonl / workflows.csv
  payloads.jsonl / tool_states.jsonl / stream_events.jsonl
  recovery_events.jsonl  (only when a recovery reminder was needed)
  backend_iterations.jsonl / backend_correlation.json
  quality.json / quality.csv / quality_examples.md
  errors.jsonl / summary.json / summary.csv / summary.txt
```

The post-run evaluator checks public state and a cumulative multiset of reference
responses after each turn and verifies replay against the recorded tool outputs
and states. It does not require the model's exact reference call ordering. Reference
answers are used only offline, never to drive online corrections or stopping.

The pilot may still fail because the model may not comply with tool semantics.
A successful mock test does not establish model task success. Do not run a new
throughput scan until the real pilot's task-quality result has been reviewed.

## Sources

Pinned BFCL source commit:
`6ea57973c7a6097fd7c5915698c54c17c5b1b6c8` in `ShishirPatil/gorilla`.
Original function documentation and tool code are loaded from the immutable
local files prepared by R1A. R1C helper SHA256 is checked before live control.

The cost interpretation uses vLLM 0.6.3.post1 documentation, not assumptions about
modern V1 defaults:
https://docs.vllm.ai/en/v0.6.3.post1/models/performance.html

Related primary research:
https://www.usenix.org/conference/osdi24/presentation/agrawal
