# SPRA real batching Round 1A

## Scope

This is a two-task integration pilot on the existing real vLLM service. It is not
an adaptive-batching implementation, BFCL leaderboard reproduction, throughput
capacity benchmark, or an AFlow reproduction.

Fixed tasks are `multi_turn_base_1` and `multi_turn_base_3` from the official
`BFCL_v4_multi_turn_base.json` at Gorilla commit
`6ea57973c7a6097fd7c5915698c54c17c5b1b6c8`. These are the first two file-system-only
entries in source order, chosen before observing inference performance. Their
original user messages, initial state, and allowed/excluded tool definitions are
preserved. Tool code is downloaded unchanged and verified by Git blob SHA.

The official GorillaFileSystem is an in-memory benchmark environment. The pilot
really executes its Python functions; it does not touch the host's files through
model-generated calls, invent tool observations, call a real Twitter service, or
replace tools with sleeps. Literal-only parsing forbids eval, exec, arbitrary
attribute lookup, imports, and nested executable call arguments.

AFlow–MBPP is not included in this micro-batch. The official AFlow README places
paper workflows/prompts in a separate results archive. Its source commit and
archive identifier are recorded for subsequent integration. No handwritten
Generate/Test/Revise graph is substituted under the AFlow name.

## Placement

Extract the delivery archive at the root of the existing prepared project:

`/home/wmy/sci/spra_paper_experiments_github`

No historical experiment source or result is overwritten. All new source,
downloaded benchmark files, manifests, and run results live in this project.

The one exception is the *existing live runtime control interface*:
`/home/wmy/sci/spra_core_exp/joint_e1/control.json`.
That is where the already-running backend reads its cap. This pilot does NOT
pretend that changing a file in the new repository changes the code loaded by a
running pod. It uses the legacy `experiment.lock`, verifies idle state, temporarily
sets 2048, checks acknowledgement after real requests, and restores the exact
previous control file after drain. It does not modify scheduler source or restart
pods. Because this control file is shared, run only when the existing experiment
service is dedicated and idle. Other clients must not submit concurrent work.

If an engine remains busy, or another process changes control.json, restoration
is not forced; the original is saved and a warning is written. Do not run another
experiment in that case. SIGKILL/power loss cannot guarantee restoration.

## Commands

```bash
cd /home/wmy/sci/spra_paper_experiments_github
conda activate spra-exp
R1=src/experiments/real_batching/round1_bfcl.py
python "$R1" selftest
python "$R1" prepare
python "$R1" run --apply-fixed-budget --wall-limit-s 180
python "$R1" report
```

Run uses httpx from the existing environment; no packages are auto-installed.
Source preparation uses Python's standard library. No OpenAI/Anthropic API key is
used. Endpoint defaults to the project's existing local service at port 8000;
`--endpoint`, `--runtime-root`, `--pod`, and `--model` can specify an existing
endpoint explicitly. This does not establish a tunnel or deploy a service.

The run includes its own source/reference-tool/health/idle checks. A standalone
read-only `check` command is also provided; it makes health/model GET requests,
not inference requests. Do not continue after a failed check.

Limits: exactly two task IDs; at most 8 LLM steps per user turn; at most 384 output
tokens per call; 45 seconds per API request; a 180-second cohort ceiling by default.
The latter is a stopping bound, not a claimed runtime estimate. There is no
minimum generation length, forced ignore-EOS, success-based retry, or task
replacement. BFCL's official maximum is 20 steps; the smaller pilot limit and
prompt-feedback adaptation are explicitly recorded and limit comparability.

## Outputs

Under `runs/real_batching/R1A_<timestamp>_<id>/`:

- `manifest.json`: source/model/configuration, status, budget acknowledgement and restoration.
- `workflows.jsonl` and `workflows.csv`: all two planned task statuses, JCT and call counts.
- `nodes.jsonl` and `nodes.csv`: LLM, tool, and orchestration spans and parent IDs.
- `payloads.jsonl`: actual prompts sent to the model, without API secrets.
- `tool_states.jsonl`: actual official-tool state after each execution.
- `stream_events.jsonl`: client SSE receipt timestamps and reported cumulative usage.
- `backend_iterations.jsonl`: actual iterations emitted by the existing hook for this run.
- `backend_correlation.json`: request-ID coverage, not fabricated stage durations.
- `control_events.jsonl`: requested fixed control and restoration status.
- `errors.jsonl`: all observed errors, including truncation and step limits.
- `summary.csv`, `summary.json`, `summary.txt`: diagnostic counts and cohort rates.

Plot-ready CSV copies go to `data/processed/real_batching/<run_id>/`.
The latest result pointer is `metadata/real_batching/round1a_latest.txt`.

## Measurement boundaries

- This run is deliberately sequential and tiny. Measured completion rate and output
  token rate are **closed-cohort diagnostic rates**, not steady-state throughput or
  capacity. No performance conclusion should be drawn from two workflows.
- Output-token counts come from actual API usage, not max_tokens or text-length estimates.
  If usage is missing, token throughput is null.
- Client SSE chunks are not individual GPU token-generation events. First visible
  token latency is named `ttft_client_visible_ms`; it is not GPU prefill time.
- Backend per-request receive/schedule timestamps and exclusive GPU prefill/decode
  times are unavailable with the current hook and left null. Shared batch duration
  is not divided equally among requests.
- Reference-state and reference-observation comparisons are diagnostics, not BFCL's
  official grader. `official_bfcl_score` and successful-workflow throughput remain
  null. Normal termination is not proof of task correctness.
- Instrumentation is synchronous and its cost is included in the pilot. Controller
  or kernel overhead claims require later dedicated measurements.

## Offline verification performed for this delivery

Three offline tests passed: parser/SSE/clock logic; complete mocked two-workflow
execution with backend ID correlation and exact control restoration; truncation
recorded as failure rather than success. Mock fixtures are confined to
`test_round1a.py`. They are not a runtime fallback and are not experiment data.

The assistant has not run inference on the user's GPU service or executed the
pinned BFCL module in that environment. The `prepare` and preflight steps perform
source integrity and official-tool checks there before inference starts.

## Source references

- https://github.com/ShishirPatil/gorilla/tree/6ea57973c7a6097fd7c5915698c54c17c5b1b6c8/berkeley-function-call-leaderboard
- https://github.com/FoundationAgents/AFlow/tree/3f457218fc716093fe53f6df8a5d5e6379d66346
- https://github.com/wmy903/SPRA/blob/main/src/runtime/joint_e1/backend_hook.py
