# R1B real fixed-budget/open-arrival probe

This extension adds `round1b_budget_probe.py` and offline tests. It imports the
unchanged adjacent `round1_bfcl.py` delivered in R1A and checks its SHA-256.
It does not install a new scheduler, change the model, or claim to implement
adaptive batching. Historical results are not modified.

## Purpose and scope

Run the two already-tested official BFCL tasks against the existing vLLM
endpoint with four actual per-iteration budgets. Change the live budget through
the already-loaded hook, not a simulator. Record what the backend schedules.

This is one development repeat, one endpoint, and a repeated two-task working
set. It is NOT a full BFCL evaluation or a maximum/steady-state capacity claim.
AFlow-MBPP remains pending, and is not replaced by a hand-written workflow.

## Default protocol

- Endpoint: `http://127.0.0.1:8000`; pod: `spra-vllm-0`.
- Model: the already-served `Qwen2.5-1.5B-Instruct`.
- Source: the R1A BFCL commit and source hashes; no new download is needed.
- Task IDs: `multi_turn_base_1`, `multi_turn_base_3`.
- Per-instance official tool state is isolated. Original task questions and tool
  documents are unchanged. Instance IDs appear only in logs, not in prompts.
- Poisson rate parameter: 1 workflow/s, fixed seed 98200, independent of response
  time. Actual counts and realized arrival rate are reported.
- Warmup: 20 seconds; measurement window: 60 seconds; drain limit: 30 seconds.
- Frozen plan: 69 arrivals, including 18 warmup and 51 measurement arrivals.
  The realized measurement arrival rate is 0.85 workflows/s, not exactly 1.
- Each condition additionally primes the same two tasks at 2048 before the
  open-arrival warmup. There is no unverified cache-reset call. Exact starting
  cache equality is NOT asserted; this is a warm-working-set diagnostic.
- Four conditions: 512, 1024, 2048, 4096. Predeclared shuffled run order:
  4096, 1024, 512, 2048. Do not run these cases concurrently on the same backend.
- All conditions use the same arrival/task plan. No semaphore slows arrivals to
  match completions. At most 16 outstanding workflows; exceeding this safety
  limit stops the condition and retains unadmitted/cancelled rows.
- Model stopping: same as R1A, natural stopping, output maximum 384, no forced
  minimum or `ignore_eos`. Eight LLM steps per user turn at most. Truncation and
  timeouts are failures; no automatic retries/replacement of benchmark tasks.
- Launch lag above 1 second stops the probe rather than hiding client overload.
- Condition wall limit: 150 seconds. Suite wall limit: 600 seconds. These are
  stopping limits, not expected completion-time claims.

## Install and run on GPU39

Upload the ZIP into the existing prepared project and run:

```bash
conda activate spra-exp
cd /home/wmy/sci/spra_paper_experiments_github
unzip -n spra_real_batching_round1b.zip
sha256sum -c metadata/real_batching/ROUND1B_SHA256SUMS
(
  set -euo pipefail
  R1B=src/experiments/real_batching/round1b_budget_probe.py
  python "$R1B" selftest
  python "$R1B" plan
  python -u "$R1B" run --apply-fixed-budget \
    2>&1 | tee metadata/real_batching/round1b_driver.log
  python "$R1B" report
)
```

No `prepare` or package installation is required after a successful R1A run.
Read-only health/source verification is integrated. A busy backend or source
mismatch fails before inference starts. The run uses the existing runtime lock
and requires exclusive use of the shared live control file. Do not launch other
experiments concurrently.

## What is changed in the live runtime

Only `/home/wmy/sci/spra_core_exp/joint_e1/control.json` is temporarily written.
This is the already-running hook's control channel, not a location for new code
or data. The existing `experiment.lock` is acquired for the entire suite. Before
each condition the original control bytes/mode are saved; after draining they
are restored only if no external process changed the file. Source code, pods,
models, startup allocation ceilings, and runtime Python are not replaced.

If `control_restored=False`, stop. The original bytes are saved with that case.
The script does not overwrite an external control update or reset a busy engine.

## Output

```
runs/real_batching/R1B_<UTC>_<id>/
  plan.json
  suite_status.json
  budget_comparison.csv
  trajectory_comparison.json
  summary.txt
  B512/ (and B1024, B2048, B4096)
    arrival_plan.json
    manifest.json
    window.json
    summary.json / summary.csv / summary.txt
    workflows.jsonl / workflows.csv
    nodes.jsonl / nodes.csv
    node_timing_by_type.csv
    payloads.jsonl
    tool_states.jsonl
    stream_events.jsonl
    observed_token_deltas.csv
    backend_iterations.jsonl
    backend_correlation.json
    queue_samples.jsonl
    control_events.jsonl
    trajectories.json / trajectories.csv
    errors.jsonl
    priming/ (excluded from measured traffic)
```

CSV and concise report copies are under `data/processed/real_batching/`.
Latest pointer: `metadata/real_batching/round1b_latest.txt`.

## Metric semantics

`window_workflow_throughput` is normally completed workflows whose completion
falls inside the fixed measurement window divided by the window length. It can
include warmup arrivals completing in the window. It is measured normal
completion throughput, NOT quality-filtered throughput or a maximum capacity.

`output_tokens_per_s_client_received` uses differences in actual cumulative
`usage.completion_tokens` at the timestamps of streamed client receipts. Tokens
outside the measurement window are not attributed to it; duplicate final usage
is not double-counted. Missing/non-monotone usage produces an unavailable value.
It is real client-observed output throughput, not exact GPU emission timing.
`gpu_output_tokens_per_second` stays null with the current hook.

JCT is from PLANNED workflow arrival to completion, including launch lag. Mean
and P95 JCT use measurement-arrival workflows completed by the drain limit;
failed/censored counts are reported alongside them. An early-stopped measurement
window never receives a full-window throughput number.

Node durations use one client monotonic clock. Each original tool call runs the
reviewed official in-memory BFCL tool implementation with literal allowlisted
arguments. No generated Python is evaluated or executed on the host. Tool time
is not host filesystem/disk I/O performance. Node elapsed times and sums are
client-observed work, not additive end-to-end JCT under concurrency. Missing GPU
prefill/decode timing remains null. Client TPOT is end-minus-first-visible-output
per remaining output token, not per-token GPU timing or an ITL distribution.

Batch diagnostics include requested/applied budget, scheduled tokens, mixed
prefill/decode iterations, budget-binding iterations, and running/waiting counts.
They cover the whole open-arrival condition including its warmup/drain, because
the existing backend log has no per-iteration aligned monotonic timestamps.
`scheduled_prefill_tokens` is the scheduler's logged quantity, not a proof of
uncached GPU-computed token work. The scheduler CPU metric is the existing vLLM
scheduler timer, not a new SPRA controller timer.

`official_bfcl_score` and `successful_workflow_throughput` remain null. Reference
state/observation diagnostics are reported separately, and are NOT the official
BFCL scorer. A normally ended task may still be incorrect.

The suite reports prompt/output/tool-trajectory differences for matched task
instances across budgets. Natural generation is preserved. Equal arrival plans
do not prove identical generated requests/tokens; differences are not deleted.

## Offline validation

Eight local tests exercise frozen plans, planned-arrival latency, streamed usage
window accounting, unknown backend requests, external-control preservation,
safety-cap handling without backpressure, a mocked four-condition suite, and
truncation failure retention/restoration. These tests use fake fixtures. They
are not GPU benchmark measurements and are not included in experiment data.
